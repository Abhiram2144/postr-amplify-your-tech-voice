export declare const VERSION = "2.32.0";
//# sourceMappingURL=version.d.mts.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.LedgerEntries = void 0;
const resource_1 = require("../../../core/resource.js");
const pagination_1 = require("../../../core/pagination.js");
const path_1 = require("../../../internal/utils/path.js");
class LedgerEntries extends resource_1.APIResource {
    create(customerID, body, options) {
        return this._client.post((0, path_1.path) `/customers/${customerID}/wallets/ledger-entries`, { body, ...options });
    }
    list(customerID, query = {}, options) {
        return this._client.getAPIList((0, path_1.path) `/customers/${customerID}/wallets/ledger-entries`, (pagination_1.DefaultPageNumberPagination), { query, ...options });
    }
}
exports.LedgerEntries = LedgerEntries;
//# sourceMappingURL=ledger-entries.js.map
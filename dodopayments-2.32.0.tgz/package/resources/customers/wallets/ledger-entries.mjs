// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../../../core/pagination.mjs";
import { path } from "../../../internal/utils/path.mjs";
export class LedgerEntries extends APIResource {
    create(customerID, body, options) {
        return this._client.post(path `/customers/${customerID}/wallets/ledger-entries`, { body, ...options });
    }
    list(customerID, query = {}, options) {
        return this._client.getAPIList(path `/customers/${customerID}/wallets/ledger-entries`, (DefaultPageNumberPagination), { query, ...options });
    }
}
//# sourceMappingURL=ledger-entries.mjs.map
import { APIResource } from "../../../core/resource.js";
import * as MiscAPI from "../../misc.js";
import * as LedgerEntriesAPI from "./ledger-entries.js";
import { CustomerWalletTransaction, CustomerWalletTransactionsDefaultPageNumberPagination, LedgerEntries, LedgerEntryCreateParams, LedgerEntryListParams } from "./ledger-entries.js";
import { APIPromise } from "../../../core/api-promise.js";
import { RequestOptions } from "../../../internal/request-options.js";
export declare class Wallets extends APIResource {
    ledgerEntries: LedgerEntriesAPI.LedgerEntries;
    list(customerID: string, options?: RequestOptions): APIPromise<WalletListResponse>;
}
export interface CustomerWallet {
    balance: number;
    created_at: string;
    currency: MiscAPI.Currency;
    customer_id: string;
    updated_at: string;
}
export interface WalletListResponse {
    items: Array<CustomerWallet>;
    /**
     * Sum of all wallet balances converted to USD (in smallest unit)
     */
    total_balance_usd: number;
}
export declare namespace Wallets {
    export { type CustomerWallet as CustomerWallet, type WalletListResponse as WalletListResponse };
    export { LedgerEntries as LedgerEntries, type CustomerWalletTransaction as CustomerWalletTransaction, type CustomerWalletTransactionsDefaultPageNumberPagination as CustomerWalletTransactionsDefaultPageNumberPagination, type LedgerEntryCreateParams as LedgerEntryCreateParams, type LedgerEntryListParams as LedgerEntryListParams, };
}
//# sourceMappingURL=wallets.d.ts.map
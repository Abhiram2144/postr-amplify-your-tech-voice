// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../core/resource.mjs";
import * as LedgerEntriesAPI from "./ledger-entries.mjs";
import { LedgerEntries, } from "./ledger-entries.mjs";
import { path } from "../../../internal/utils/path.mjs";
export class Wallets extends APIResource {
    constructor() {
        super(...arguments);
        this.ledgerEntries = new LedgerEntriesAPI.LedgerEntries(this._client);
    }
    list(customerID, options) {
        return this._client.get(path `/customers/${customerID}/wallets`, options);
    }
}
Wallets.LedgerEntries = LedgerEntries;
//# sourceMappingURL=wallets.mjs.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Wallets = void 0;
const tslib_1 = require("../../../internal/tslib.js");
const resource_1 = require("../../../core/resource.js");
const LedgerEntriesAPI = tslib_1.__importStar(require("./ledger-entries.js"));
const ledger_entries_1 = require("./ledger-entries.js");
const path_1 = require("../../../internal/utils/path.js");
class Wallets extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.ledgerEntries = new LedgerEntriesAPI.LedgerEntries(this._client);
    }
    list(customerID, options) {
        return this._client.get((0, path_1.path) `/customers/${customerID}/wallets`, options);
    }
}
exports.Wallets = Wallets;
Wallets.LedgerEntries = ledger_entries_1.LedgerEntries;
//# sourceMappingURL=wallets.js.map
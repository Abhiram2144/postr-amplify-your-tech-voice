import { APIResource } from "../../core/resource.mjs";
import * as CustomersAPI from "./customers.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class CustomerPortal extends APIResource {
    create(customerID: string, params?: CustomerPortalCreateParams | null | undefined, options?: RequestOptions): APIPromise<CustomersAPI.CustomerPortalSession>;
}
export interface CustomerPortalCreateParams {
    /**
     * Optional return URL for this session. Overrides the business-level default. This
     * URL will be shown as a "Return to {business}" back button in the portal.
     */
    return_url?: string;
    /**
     * If true, will send link to user.
     */
    send_email?: boolean;
}
export declare namespace CustomerPortal {
    export { type CustomerPortalCreateParams as CustomerPortalCreateParams };
}
//# sourceMappingURL=customer-portal.d.mts.map
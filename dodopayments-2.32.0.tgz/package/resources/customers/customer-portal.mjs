// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { path } from "../../internal/utils/path.mjs";
export class CustomerPortal extends APIResource {
    create(customerID, params = {}, options) {
        const { return_url, send_email } = params ?? {};
        return this._client.post(path `/customers/${customerID}/customer-portal/session`, {
            query: { return_url, send_email },
            ...options,
        });
    }
}
//# sourceMappingURL=customer-portal.mjs.map
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as CustomerPortalAPI from "./customer-portal.mjs";
import { CustomerPortal } from "./customer-portal.mjs";
import * as WalletsAPI from "./wallets/wallets.mjs";
import { Wallets } from "./wallets/wallets.mjs";
import { DefaultPageNumberPagination, } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Customers extends APIResource {
    constructor() {
        super(...arguments);
        this.customerPortal = new CustomerPortalAPI.CustomerPortal(this._client);
        this.wallets = new WalletsAPI.Wallets(this._client);
    }
    create(body, options) {
        return this._client.post('/customers', { body, ...options });
    }
    retrieve(customerID, options) {
        return this._client.get(path `/customers/${customerID}`, options);
    }
    update(customerID, body, options) {
        return this._client.patch(path `/customers/${customerID}`, { body, ...options });
    }
    list(query = {}, options) {
        return this._client.getAPIList('/customers', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    deletePaymentMethod(paymentMethodID, params, options) {
        const { customer_id } = params;
        return this._client.delete(path `/customers/${customer_id}/payment-methods/${paymentMethodID}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * List all credit entitlements for a customer with their current balances
     */
    listCreditEntitlements(customerID, options) {
        return this._client.get(path `/customers/${customerID}/credit-entitlements`, options);
    }
    /**
     * List all entitlement grants delivered (or in flight) to a customer.
     */
    listEntitlements(customerID, options) {
        return this._client.get(path `/customers/${customerID}/entitlements`, options);
    }
    retrievePaymentMethods(customerID, options) {
        return this._client.get(path `/customers/${customerID}/payment-methods`, options);
    }
}
Customers.CustomerPortal = CustomerPortal;
Customers.Wallets = Wallets;
//# sourceMappingURL=customers.mjs.map
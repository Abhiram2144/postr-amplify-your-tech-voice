import { APIResource } from "../../core/resource.js";
import * as MiscAPI from "../misc.js";
import * as PaymentsAPI from "../payments.js";
import * as CustomerPortalAPI from "./customer-portal.js";
import { CustomerPortal, CustomerPortalCreateParams } from "./customer-portal.js";
import * as EntitlementsAPI from "../entitlements/entitlements.js";
import * as WalletsAPI from "./wallets/wallets.js";
import { CustomerWallet, WalletListResponse, Wallets } from "./wallets/wallets.js";
import { APIPromise } from "../../core/api-promise.js";
import { DefaultPageNumberPagination, type DefaultPageNumberPaginationParams, PagePromise } from "../../core/pagination.js";
import { RequestOptions } from "../../internal/request-options.js";
export declare class Customers extends APIResource {
    customerPortal: CustomerPortalAPI.CustomerPortal;
    wallets: WalletsAPI.Wallets;
    create(body: CustomerCreateParams, options?: RequestOptions): APIPromise<Customer>;
    retrieve(customerID: string, options?: RequestOptions): APIPromise<Customer>;
    update(customerID: string, body: CustomerUpdateParams, options?: RequestOptions): APIPromise<Customer>;
    list(query?: CustomerListParams | null | undefined, options?: RequestOptions): PagePromise<CustomersDefaultPageNumberPagination, Customer>;
    deletePaymentMethod(paymentMethodID: string, params: CustomerDeletePaymentMethodParams, options?: RequestOptions): APIPromise<void>;
    /**
     * List all credit entitlements for a customer with their current balances
     */
    listCreditEntitlements(customerID: string, options?: RequestOptions): APIPromise<CustomerListCreditEntitlementsResponse>;
    /**
     * List all entitlement grants delivered (or in flight) to a customer.
     */
    listEntitlements(customerID: string, options?: RequestOptions): APIPromise<CustomerListEntitlementsResponse>;
    retrievePaymentMethods(customerID: string, options?: RequestOptions): APIPromise<CustomerRetrievePaymentMethodsResponse>;
}
export type CustomersDefaultPageNumberPagination = DefaultPageNumberPagination<Customer>;
export interface Customer {
    business_id: string;
    created_at: string;
    customer_id: string;
    email: string;
    name: string;
    /**
     * Additional metadata for the customer
     */
    metadata?: {
        [key: string]: string;
    };
    phone_number?: string | null;
}
export interface CustomerPortalSession {
    link: string;
}
export interface CustomerListCreditEntitlementsResponse {
    items: Array<CustomerListCreditEntitlementsResponse.Item>;
}
export declare namespace CustomerListCreditEntitlementsResponse {
    /**
     * A credit entitlement with the customer's current balance
     */
    interface Item {
        /**
         * Customer's current remaining credit balance
         */
        balance: string;
        /**
         * Credit entitlement ID
         */
        credit_entitlement_id: string;
        /**
         * Name of the credit entitlement
         */
        name: string;
        /**
         * Customer's current overage balance
         */
        overage: string;
        /**
         * Unit label (e.g. "API Calls", "Tokens")
         */
        unit: string;
        /**
         * Description of the credit entitlement
         */
        description?: string | null;
    }
}
export interface CustomerListEntitlementsResponse {
    items: Array<CustomerListEntitlementsResponse.Item>;
}
export declare namespace CustomerListEntitlementsResponse {
    interface Item {
        created_at: string;
        /**
         * The entitlement this grant belongs to.
         */
        entitlement_id: string;
        entitlement_name: string;
        /**
         * Grant id (the per-customer row in `entitlement_grants`).
         */
        grant_id: string;
        integration_type: EntitlementsAPI.EntitlementIntegrationType;
        status: 'pending' | 'delivered' | 'failed' | 'revoked';
        updated_at: string;
        delivered_at?: string | null;
        entitlement_description?: string | null;
        revoked_at?: string | null;
    }
}
export interface CustomerRetrievePaymentMethodsResponse {
    items: Array<CustomerRetrievePaymentMethodsResponse.Item>;
}
export declare namespace CustomerRetrievePaymentMethodsResponse {
    interface Item {
        payment_method: 'card' | 'card_redirect' | 'pay_later' | 'wallet' | 'bank_redirect' | 'bank_transfer' | 'crypto' | 'bank_debit' | 'reward' | 'real_time_payment' | 'upi' | 'voucher' | 'gift_card' | 'open_banking' | 'mobile_payment';
        payment_method_id: string;
        card?: Item.Card | null;
        last_used_at?: string | null;
        /**
         * All supported payment method types (from Hyperswitch).
         *
         * Used for disabled-payment-methods filtering and validation.
         */
        payment_method_type?: PaymentsAPI.PaymentMethodTypes | null;
        recurring_enabled?: boolean | null;
    }
    namespace Item {
        interface Card {
            card_holder_name?: string | null;
            /**
             * ISO country code alpha2 variant
             */
            card_issuing_country?: MiscAPI.CountryCode | null;
            card_network?: string | null;
            card_type?: string | null;
            expiry_month?: string | null;
            expiry_year?: string | null;
            last4_digits?: string | null;
        }
    }
}
export interface CustomerCreateParams {
    email: string;
    name: string;
    /**
     * Additional metadata for the customer
     */
    metadata?: {
        [key: string]: string;
    };
    phone_number?: string | null;
}
export interface CustomerUpdateParams {
    email?: string | null;
    /**
     * Additional metadata for the customer
     */
    metadata?: {
        [key: string]: string;
    } | null;
    name?: string | null;
    phone_number?: string | null;
}
export interface CustomerListParams extends DefaultPageNumberPaginationParams {
    /**
     * Filter customers created on or after this timestamp
     */
    created_at_gte?: string;
    /**
     * Filter customers created on or before this timestamp
     */
    created_at_lte?: string;
    /**
     * Filter by customer email
     */
    email?: string;
    /**
     * Filter by customer name (partial match, case-insensitive)
     */
    name?: string;
}
export interface CustomerDeletePaymentMethodParams {
    /**
     * Customer Id
     */
    customer_id: string;
}
export declare namespace Customers {
    export { type Customer as Customer, type CustomerPortalSession as CustomerPortalSession, type CustomerListCreditEntitlementsResponse as CustomerListCreditEntitlementsResponse, type CustomerListEntitlementsResponse as CustomerListEntitlementsResponse, type CustomerRetrievePaymentMethodsResponse as CustomerRetrievePaymentMethodsResponse, type CustomersDefaultPageNumberPagination as CustomersDefaultPageNumberPagination, type CustomerCreateParams as CustomerCreateParams, type CustomerUpdateParams as CustomerUpdateParams, type CustomerListParams as CustomerListParams, type CustomerDeletePaymentMethodParams as CustomerDeletePaymentMethodParams, };
    export { CustomerPortal as CustomerPortal, type CustomerPortalCreateParams as CustomerPortalCreateParams };
    export { Wallets as Wallets, type CustomerWallet as CustomerWallet, type WalletListResponse as WalletListResponse, };
}
//# sourceMappingURL=customers.d.ts.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Customers = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const CustomerPortalAPI = tslib_1.__importStar(require("./customer-portal.js"));
const customer_portal_1 = require("./customer-portal.js");
const WalletsAPI = tslib_1.__importStar(require("./wallets/wallets.js"));
const wallets_1 = require("./wallets/wallets.js");
const pagination_1 = require("../../core/pagination.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Customers extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.customerPortal = new CustomerPortalAPI.CustomerPortal(this._client);
        this.wallets = new WalletsAPI.Wallets(this._client);
    }
    create(body, options) {
        return this._client.post('/customers', { body, ...options });
    }
    retrieve(customerID, options) {
        return this._client.get((0, path_1.path) `/customers/${customerID}`, options);
    }
    update(customerID, body, options) {
        return this._client.patch((0, path_1.path) `/customers/${customerID}`, { body, ...options });
    }
    list(query = {}, options) {
        return this._client.getAPIList('/customers', (pagination_1.DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    deletePaymentMethod(paymentMethodID, params, options) {
        const { customer_id } = params;
        return this._client.delete((0, path_1.path) `/customers/${customer_id}/payment-methods/${paymentMethodID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * List all credit entitlements for a customer with their current balances
     */
    listCreditEntitlements(customerID, options) {
        return this._client.get((0, path_1.path) `/customers/${customerID}/credit-entitlements`, options);
    }
    /**
     * List all entitlement grants delivered (or in flight) to a customer.
     */
    listEntitlements(customerID, options) {
        return this._client.get((0, path_1.path) `/customers/${customerID}/entitlements`, options);
    }
    retrievePaymentMethods(customerID, options) {
        return this._client.get((0, path_1.path) `/customers/${customerID}/payment-methods`, options);
    }
}
exports.Customers = Customers;
Customers.CustomerPortal = customer_portal_1.CustomerPortal;
Customers.Wallets = wallets_1.Wallets;
//# sourceMappingURL=customers.js.map
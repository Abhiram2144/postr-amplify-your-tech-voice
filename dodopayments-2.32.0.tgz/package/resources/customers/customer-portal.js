"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomerPortal = void 0;
const resource_1 = require("../../core/resource.js");
const path_1 = require("../../internal/utils/path.js");
class CustomerPortal extends resource_1.APIResource {
    create(customerID, params = {}, options) {
        const { return_url, send_email } = params ?? {};
        return this._client.post((0, path_1.path) `/customers/${customerID}/customer-portal/session`, {
            query: { return_url, send_email },
            ...options,
        });
    }
}
exports.CustomerPortal = CustomerPortal;
//# sourceMappingURL=customer-portal.js.map
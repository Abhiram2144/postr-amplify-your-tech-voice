import { APIResource } from "../core/resource.mjs";
import { APIPromise } from "../core/api-promise.mjs";
import { DefaultPageNumberPagination, type DefaultPageNumberPaginationParams, PagePromise } from "../core/pagination.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
export declare class LicenseKeyInstances extends APIResource {
    /**
     * @example
     * ```ts
     * const licenseKeyInstance =
     *   await client.licenseKeyInstances.retrieve('lki_123');
     * ```
     */
    retrieve(id: string, options?: RequestOptions): APIPromise<LicenseKeyInstance>;
    /**
     * @example
     * ```ts
     * const licenseKeyInstance =
     *   await client.licenseKeyInstances.update('lki_123', {
     *     name: 'name',
     *   });
     * ```
     */
    update(id: string, body: LicenseKeyInstanceUpdateParams, options?: RequestOptions): APIPromise<LicenseKeyInstance>;
    /**
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const licenseKeyInstance of client.licenseKeyInstances.list()) {
     *   // ...
     * }
     * ```
     */
    list(query?: LicenseKeyInstanceListParams | null | undefined, options?: RequestOptions): PagePromise<LicenseKeyInstancesDefaultPageNumberPagination, LicenseKeyInstance>;
}
export type LicenseKeyInstancesDefaultPageNumberPagination = DefaultPageNumberPagination<LicenseKeyInstance>;
export interface LicenseKeyInstance {
    id: string;
    business_id: string;
    created_at: string;
    license_key_id: string;
    name: string;
}
export interface LicenseKeyInstanceUpdateParams {
    name: string;
}
export interface LicenseKeyInstanceListParams extends DefaultPageNumberPaginationParams {
    /**
     * Filter instances by entitlement grant ID
     */
    grant_id?: string | null;
    /**
     * Filter by license key ID
     */
    license_key_id?: string | null;
}
export declare namespace LicenseKeyInstances {
    export { type LicenseKeyInstance as LicenseKeyInstance, type LicenseKeyInstancesDefaultPageNumberPagination as LicenseKeyInstancesDefaultPageNumberPagination, type LicenseKeyInstanceUpdateParams as LicenseKeyInstanceUpdateParams, type LicenseKeyInstanceListParams as LicenseKeyInstanceListParams, };
}
//# sourceMappingURL=license-key-instances.d.mts.map
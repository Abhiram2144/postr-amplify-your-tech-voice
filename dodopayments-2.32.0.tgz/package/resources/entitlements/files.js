"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Files = void 0;
const resource_1 = require("../../core/resource.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Files extends resource_1.APIResource {
    /**
     * Detach a previously-attached file from a `digital_files` entitlement.
     */
    delete(fileID, params, options) {
        const { id } = params;
        return this._client.delete((0, path_1.path) `/entitlements/${id}/files/${fileID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Attach a file to a `digital_files` entitlement. Per-file size cap: 500 MiB.
     */
    upload(id, options) {
        return this._client.post((0, path_1.path) `/entitlements/${id}/files`, options);
    }
}
exports.Files = Files;
//# sourceMappingURL=files.js.map
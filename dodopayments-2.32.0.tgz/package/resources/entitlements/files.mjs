// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Files extends APIResource {
    /**
     * Detach a previously-attached file from a `digital_files` entitlement.
     */
    delete(fileID, params, options) {
        const { id } = params;
        return this._client.delete(path `/entitlements/${id}/files/${fileID}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Attach a file to a `digital_files` entitlement. Per-file size cap: 500 MiB.
     */
    upload(id, options) {
        return this._client.post(path `/entitlements/${id}/files`, options);
    }
}
//# sourceMappingURL=files.mjs.map
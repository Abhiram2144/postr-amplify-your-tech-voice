import { APIResource } from "../../core/resource.js";
import { APIPromise } from "../../core/api-promise.js";
import { RequestOptions } from "../../internal/request-options.js";
export declare class Files extends APIResource {
    /**
     * Detach a previously-attached file from a `digital_files` entitlement.
     */
    delete(fileID: string, params: FileDeleteParams, options?: RequestOptions): APIPromise<void>;
    /**
     * Attach a file to a `digital_files` entitlement. Per-file size cap: 500 MiB.
     */
    upload(id: string, options?: RequestOptions): APIPromise<FileUploadResponse>;
}
export interface FileUploadResponse {
    /**
     * Identifier of the attached file. Pass it to
     * `DELETE /entitlements/{id}/files/{file_id}` to detach the file later.
     */
    file_id: string;
}
export interface FileDeleteParams {
    /**
     * Entitlement Id
     */
    id: string;
}
export declare namespace Files {
    export { type FileUploadResponse as FileUploadResponse, type FileDeleteParams as FileDeleteParams };
}
//# sourceMappingURL=files.d.ts.map
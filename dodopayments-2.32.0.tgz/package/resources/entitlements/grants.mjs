// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../../core/pagination.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Grants extends APIResource {
    /**
     * GET /entitlements/{id}/grants (public API)
     */
    list(id, query = {}, options) {
        return this._client.getAPIList(path `/entitlements/${id}/grants`, (DefaultPageNumberPagination), { query, ...options });
    }
    /**
     * Revoke a single grant. Idempotent: re-revoking an already-revoked grant returns
     * the grant in its current state.
     */
    revoke(grantID, params, options) {
        const { id } = params;
        return this._client.delete(path `/entitlements/${id}/grants/${grantID}`, options);
    }
}
//# sourceMappingURL=grants.mjs.map
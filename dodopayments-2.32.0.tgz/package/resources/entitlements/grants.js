"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Grants = void 0;
const resource_1 = require("../../core/resource.js");
const pagination_1 = require("../../core/pagination.js");
const path_1 = require("../../internal/utils/path.js");
class Grants extends resource_1.APIResource {
    /**
     * GET /entitlements/{id}/grants (public API)
     */
    list(id, query = {}, options) {
        return this._client.getAPIList((0, path_1.path) `/entitlements/${id}/grants`, (pagination_1.DefaultPageNumberPagination), { query, ...options });
    }
    /**
     * Revoke a single grant. Idempotent: re-revoking an already-revoked grant returns
     * the grant in its current state.
     */
    revoke(grantID, params, options) {
        const { id } = params;
        return this._client.delete((0, path_1.path) `/entitlements/${id}/grants/${grantID}`, options);
    }
}
exports.Grants = Grants;
//# sourceMappingURL=grants.js.map
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as FilesAPI from "./files.mjs";
import { Files } from "./files.mjs";
import * as GrantsAPI from "./grants.mjs";
import { Grants, } from "./grants.mjs";
import { DefaultPageNumberPagination, } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Entitlements extends APIResource {
    constructor() {
        super(...arguments);
        this.files = new FilesAPI.Files(this._client);
        this.grants = new GrantsAPI.Grants(this._client);
    }
    /**
     * POST /entitlements
     */
    create(body, options) {
        return this._client.post('/entitlements', { body, ...options });
    }
    /**
     * GET /entitlements/{id}
     */
    retrieve(id, options) {
        return this._client.get(path `/entitlements/${id}`, options);
    }
    /**
     * PATCH /entitlements/{id}
     */
    update(id, body, options) {
        return this._client.patch(path `/entitlements/${id}`, { body, ...options });
    }
    /**
     * GET /entitlements
     */
    list(query = {}, options) {
        return this._client.getAPIList('/entitlements', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    /**
     * DELETE /entitlements/{id} (soft-delete)
     */
    delete(id, options) {
        return this._client.delete(path `/entitlements/${id}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
Entitlements.Files = Files;
Entitlements.Grants = Grants;
//# sourceMappingURL=entitlements.mjs.map
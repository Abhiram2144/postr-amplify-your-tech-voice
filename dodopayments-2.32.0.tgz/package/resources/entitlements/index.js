"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Grants = exports.Files = exports.Entitlements = void 0;
var entitlements_1 = require("./entitlements.js");
Object.defineProperty(exports, "Entitlements", { enumerable: true, get: function () { return entitlements_1.Entitlements; } });
var files_1 = require("./files.js");
Object.defineProperty(exports, "Files", { enumerable: true, get: function () { return files_1.Files; } });
var grants_1 = require("./grants.js");
Object.defineProperty(exports, "Grants", { enumerable: true, get: function () { return grants_1.Grants; } });
//# sourceMappingURL=index.js.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Entitlements = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const FilesAPI = tslib_1.__importStar(require("./files.js"));
const files_1 = require("./files.js");
const GrantsAPI = tslib_1.__importStar(require("./grants.js"));
const grants_1 = require("./grants.js");
const pagination_1 = require("../../core/pagination.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Entitlements extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.files = new FilesAPI.Files(this._client);
        this.grants = new GrantsAPI.Grants(this._client);
    }
    /**
     * POST /entitlements
     */
    create(body, options) {
        return this._client.post('/entitlements', { body, ...options });
    }
    /**
     * GET /entitlements/{id}
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/entitlements/${id}`, options);
    }
    /**
     * PATCH /entitlements/{id}
     */
    update(id, body, options) {
        return this._client.patch((0, path_1.path) `/entitlements/${id}`, { body, ...options });
    }
    /**
     * GET /entitlements
     */
    list(query = {}, options) {
        return this._client.getAPIList('/entitlements', (pagination_1.DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    /**
     * DELETE /entitlements/{id} (soft-delete)
     */
    delete(id, options) {
        return this._client.delete((0, path_1.path) `/entitlements/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Entitlements = Entitlements;
Entitlements.Files = files_1.Files;
Entitlements.Grants = grants_1.Grants;
//# sourceMappingURL=entitlements.js.map
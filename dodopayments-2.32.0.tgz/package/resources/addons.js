"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Addons = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const path_1 = require("../internal/utils/path.js");
class Addons extends resource_1.APIResource {
    create(body, options) {
        return this._client.post('/addons', { body, ...options });
    }
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/addons/${id}`, options);
    }
    update(id, body, options) {
        return this._client.patch((0, path_1.path) `/addons/${id}`, { body, ...options });
    }
    list(query = {}, options) {
        return this._client.getAPIList('/addons', (pagination_1.DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    updateImages(id, options) {
        return this._client.put((0, path_1.path) `/addons/${id}/images`, options);
    }
}
exports.Addons = Addons;
//# sourceMappingURL=addons.js.map
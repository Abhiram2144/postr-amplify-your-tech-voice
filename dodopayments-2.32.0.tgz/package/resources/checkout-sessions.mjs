// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { path } from "../internal/utils/path.mjs";
export class CheckoutSessions extends APIResource {
    create(body, options) {
        return this._client.post('/checkouts', { body, ...options });
    }
    retrieve(id, options) {
        return this._client.get(path `/checkouts/${id}`, options);
    }
    preview(body, options) {
        return this._client.post('/checkouts/preview', { body, ...options });
    }
}
//# sourceMappingURL=checkout-sessions.mjs.map
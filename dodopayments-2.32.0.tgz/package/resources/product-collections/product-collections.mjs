// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as GroupsAPI from "./groups/groups.mjs";
import { Groups, } from "./groups/groups.mjs";
import { DefaultPageNumberPagination, } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class ProductCollections extends APIResource {
    constructor() {
        super(...arguments);
        this.groups = new GroupsAPI.Groups(this._client);
    }
    create(body, options) {
        return this._client.post('/product-collections', { body, ...options });
    }
    retrieve(id, options) {
        return this._client.get(path `/product-collections/${id}`, options);
    }
    update(id, body, options) {
        return this._client.patch(path `/product-collections/${id}`, {
            body,
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    list(query = {}, options) {
        return this._client.getAPIList('/product-collections', (DefaultPageNumberPagination), { query, ...options });
    }
    delete(id, options) {
        return this._client.delete(path `/product-collections/${id}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    unarchive(id, options) {
        return this._client.post(path `/product-collections/${id}/unarchive`, options);
    }
    updateImages(id, params = {}, options) {
        const { force_update } = params ?? {};
        return this._client.put(path `/product-collections/${id}/images`, { query: { force_update }, ...options });
    }
}
ProductCollections.Groups = Groups;
//# sourceMappingURL=product-collections.mjs.map
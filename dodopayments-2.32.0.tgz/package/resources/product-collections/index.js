"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductCollections = exports.Groups = void 0;
var index_1 = require("./groups/index.js");
Object.defineProperty(exports, "Groups", { enumerable: true, get: function () { return index_1.Groups; } });
var product_collections_1 = require("./product-collections.js");
Object.defineProperty(exports, "ProductCollections", { enumerable: true, get: function () { return product_collections_1.ProductCollections; } });
//# sourceMappingURL=index.js.map
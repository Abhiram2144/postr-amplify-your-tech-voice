"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Items = void 0;
const resource_1 = require("../../../core/resource.js");
const headers_1 = require("../../../internal/headers.js");
const path_1 = require("../../../internal/utils/path.js");
class Items extends resource_1.APIResource {
    create(groupID, params, options) {
        const { id, ...body } = params;
        return this._client.post((0, path_1.path) `/product-collections/${id}/groups/${groupID}/items`, { body, ...options });
    }
    update(itemID, params, options) {
        const { id, group_id, ...body } = params;
        return this._client.patch((0, path_1.path) `/product-collections/${id}/groups/${group_id}/items/${itemID}`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    delete(itemID, params, options) {
        const { id, group_id } = params;
        return this._client.delete((0, path_1.path) `/product-collections/${id}/groups/${group_id}/items/${itemID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Items = Items;
//# sourceMappingURL=items.js.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Groups = void 0;
const tslib_1 = require("../../../internal/tslib.js");
const resource_1 = require("../../../core/resource.js");
const ItemsAPI = tslib_1.__importStar(require("./items.js"));
const items_1 = require("./items.js");
const headers_1 = require("../../../internal/headers.js");
const path_1 = require("../../../internal/utils/path.js");
class Groups extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.items = new ItemsAPI.Items(this._client);
    }
    create(id, body, options) {
        return this._client.post((0, path_1.path) `/product-collections/${id}/groups`, { body, ...options });
    }
    update(groupID, params, options) {
        const { id, ...body } = params;
        return this._client.patch((0, path_1.path) `/product-collections/${id}/groups/${groupID}`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    delete(groupID, params, options) {
        const { id } = params;
        return this._client.delete((0, path_1.path) `/product-collections/${id}/groups/${groupID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Groups = Groups;
Groups.Items = items_1.Items;
//# sourceMappingURL=groups.js.map
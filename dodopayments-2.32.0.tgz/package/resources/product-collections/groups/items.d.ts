import { APIResource } from "../../../core/resource.js";
import * as MiscAPI from "../../misc.js";
import * as ProductsAPI from "../../products/products.js";
import * as GroupsAPI from "./groups.js";
import { APIPromise } from "../../../core/api-promise.js";
import { RequestOptions } from "../../../internal/request-options.js";
export declare class Items extends APIResource {
    create(groupID: string, params: ItemCreateParams, options?: RequestOptions): APIPromise<ItemCreateResponse>;
    update(itemID: string, params: ItemUpdateParams, options?: RequestOptions): APIPromise<void>;
    delete(itemID: string, params: ItemDeleteParams, options?: RequestOptions): APIPromise<void>;
}
export interface ProductCollectionProduct {
    id: string;
    addons_count: number;
    files_count: number;
    /**
     * Whether this product has any credit entitlements attached
     */
    has_credit_entitlements: boolean;
    is_recurring: boolean;
    license_key_enabled: boolean;
    meters_count: number;
    product_id: string;
    status: boolean;
    currency?: MiscAPI.Currency | null;
    description?: string | null;
    name?: string | null;
    price?: number | null;
    /**
     * One-time price details.
     */
    price_detail?: ProductsAPI.Price | null;
    /**
     * Represents the different categories of taxation applicable to various products
     * and services.
     */
    tax_category?: MiscAPI.TaxCategory | null;
    tax_inclusive?: boolean | null;
}
export type ItemCreateResponse = Array<ProductCollectionProduct>;
export interface ItemCreateParams {
    /**
     * Path param: Product Collection Id
     */
    id: string;
    /**
     * Body param: Products to add to the group
     */
    products: Array<GroupsAPI.GroupProduct>;
}
export interface ItemUpdateParams {
    /**
     * Path param: Product Collection Id
     */
    id: string;
    /**
     * Path param: Product Collection Group Id
     */
    group_id: string;
    /**
     * Body param: Status of the product in the group
     */
    status: boolean;
}
export interface ItemDeleteParams {
    /**
     * Product Collection Id
     */
    id: string;
    /**
     * Product Collection Group Id
     */
    group_id: string;
}
export declare namespace Items {
    export { type ProductCollectionProduct as ProductCollectionProduct, type ItemCreateResponse as ItemCreateResponse, type ItemCreateParams as ItemCreateParams, type ItemUpdateParams as ItemUpdateParams, type ItemDeleteParams as ItemDeleteParams, };
}
//# sourceMappingURL=items.d.ts.map
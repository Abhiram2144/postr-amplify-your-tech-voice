// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../core/resource.mjs";
import * as ItemsAPI from "./items.mjs";
import { Items, } from "./items.mjs";
import { buildHeaders } from "../../../internal/headers.mjs";
import { path } from "../../../internal/utils/path.mjs";
export class Groups extends APIResource {
    constructor() {
        super(...arguments);
        this.items = new ItemsAPI.Items(this._client);
    }
    create(id, body, options) {
        return this._client.post(path `/product-collections/${id}/groups`, { body, ...options });
    }
    update(groupID, params, options) {
        const { id, ...body } = params;
        return this._client.patch(path `/product-collections/${id}/groups/${groupID}`, {
            body,
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    delete(groupID, params, options) {
        const { id } = params;
        return this._client.delete(path `/product-collections/${id}/groups/${groupID}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
Groups.Items = Items;
//# sourceMappingURL=groups.mjs.map
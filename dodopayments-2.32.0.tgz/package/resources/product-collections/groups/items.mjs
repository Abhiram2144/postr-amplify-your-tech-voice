// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../core/resource.mjs";
import { buildHeaders } from "../../../internal/headers.mjs";
import { path } from "../../../internal/utils/path.mjs";
export class Items extends APIResource {
    create(groupID, params, options) {
        const { id, ...body } = params;
        return this._client.post(path `/product-collections/${id}/groups/${groupID}/items`, { body, ...options });
    }
    update(itemID, params, options) {
        const { id, group_id, ...body } = params;
        return this._client.patch(path `/product-collections/${id}/groups/${group_id}/items/${itemID}`, {
            body,
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    delete(itemID, params, options) {
        const { id, group_id } = params;
        return this._client.delete(path `/product-collections/${id}/groups/${group_id}/items/${itemID}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=items.mjs.map
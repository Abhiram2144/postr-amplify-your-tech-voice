"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductCollections = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const GroupsAPI = tslib_1.__importStar(require("./groups/groups.js"));
const groups_1 = require("./groups/groups.js");
const pagination_1 = require("../../core/pagination.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class ProductCollections extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.groups = new GroupsAPI.Groups(this._client);
    }
    create(body, options) {
        return this._client.post('/product-collections', { body, ...options });
    }
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/product-collections/${id}`, options);
    }
    update(id, body, options) {
        return this._client.patch((0, path_1.path) `/product-collections/${id}`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    list(query = {}, options) {
        return this._client.getAPIList('/product-collections', (pagination_1.DefaultPageNumberPagination), { query, ...options });
    }
    delete(id, options) {
        return this._client.delete((0, path_1.path) `/product-collections/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    unarchive(id, options) {
        return this._client.post((0, path_1.path) `/product-collections/${id}/unarchive`, options);
    }
    updateImages(id, params = {}, options) {
        const { force_update } = params ?? {};
        return this._client.put((0, path_1.path) `/product-collections/${id}/images`, { query: { force_update }, ...options });
    }
}
exports.ProductCollections = ProductCollections;
ProductCollections.Groups = groups_1.Groups;
//# sourceMappingURL=product-collections.js.map
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../core/pagination.mjs";
import { path } from "../internal/utils/path.mjs";
export class LicenseKeys extends APIResource {
    /**
     * @example
     * ```ts
     * const licenseKey = await client.licenseKeys.create({
     *   customer_id: 'customer_id',
     *   key: 'key',
     *   product_id: 'product_id',
     * });
     * ```
     */
    create(body, options) {
        return this._client.post('/license_keys', { body, ...options });
    }
    /**
     * @deprecated
     */
    retrieve(id, options) {
        return this._client.get(path `/license_keys/${id}`, options);
    }
    /**
     * @deprecated
     */
    update(id, body, options) {
        return this._client.patch(path `/license_keys/${id}`, { body, ...options });
    }
    /**
     * @deprecated
     */
    list(query = {}, options) {
        return this._client.getAPIList('/license_keys', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
}
//# sourceMappingURL=license-keys.mjs.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Misc = void 0;
const resource_1 = require("../core/resource.js");
class Misc extends resource_1.APIResource {
    listSupportedCountries(options) {
        return this._client.get('/checkout/supported_countries', options);
    }
}
exports.Misc = Misc;
//# sourceMappingURL=misc.js.map
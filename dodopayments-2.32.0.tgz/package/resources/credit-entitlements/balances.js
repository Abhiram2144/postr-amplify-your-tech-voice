"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Balances = void 0;
const resource_1 = require("../../core/resource.js");
const pagination_1 = require("../../core/pagination.js");
const path_1 = require("../../internal/utils/path.js");
class Balances extends resource_1.APIResource {
    /**
     * Returns the credit balance details for a specific customer and credit
     * entitlement.
     *
     * # Authentication
     *
     * Requires an API key with `Viewer` role or higher.
     *
     * # Path Parameters
     *
     * - `credit_entitlement_id` - The unique identifier of the credit entitlement
     * - `customer_id` - The unique identifier of the customer
     *
     * # Responses
     *
     * - `200 OK` - Returns the customer's balance
     * - `404 Not Found` - Credit entitlement or customer balance not found
     * - `500 Internal Server Error` - Database or server error
     */
    retrieve(customerID, params, options) {
        const { credit_entitlement_id } = params;
        return this._client.get((0, path_1.path) `/credit-entitlements/${credit_entitlement_id}/balances/${customerID}`, options);
    }
    /**
     * Returns a paginated list of customer credit balances for the given credit
     * entitlement.
     *
     * # Authentication
     *
     * Requires an API key with `Viewer` role or higher.
     *
     * # Path Parameters
     *
     * - `credit_entitlement_id` - The unique identifier of the credit entitlement
     *
     * # Query Parameters
     *
     * - `page_size` - Number of items per page (default: 10, max: 100)
     * - `page_number` - Zero-based page number (default: 0)
     * - `customer_id` - Optional filter by specific customer
     *
     * # Responses
     *
     * - `200 OK` - Returns list of customer balances
     * - `404 Not Found` - Credit entitlement not found
     * - `500 Internal Server Error` - Database or server error
     */
    list(creditEntitlementID, query = {}, options) {
        return this._client.getAPIList((0, path_1.path) `/credit-entitlements/${creditEntitlementID}/balances`, (pagination_1.DefaultPageNumberPagination), { query, ...options });
    }
    /**
     * For credit entries, a new grant is created. For debit entries, credits are
     * deducted from existing grants using FIFO (oldest first).
     *
     * # Authentication
     *
     * Requires an API key with `Editor` role.
     *
     * # Path Parameters
     *
     * - `credit_entitlement_id` - The unique identifier of the credit entitlement
     * - `customer_id` - The unique identifier of the customer
     *
     * # Request Body
     *
     * - `entry_type` - "credit" or "debit"
     * - `amount` - Amount to credit or debit
     * - `reason` - Optional human-readable reason
     * - `expires_at` - Optional expiration for credited amount (only for credit type)
     * - `idempotency_key` - Optional key to prevent duplicate entries
     *
     * # Responses
     *
     * - `201 Created` - Ledger entry created successfully
     * - `400 Bad Request` - Invalid request (e.g., debit with insufficient balance)
     * - `404 Not Found` - Credit entitlement or customer not found
     * - `409 Conflict` - Idempotency key already exists
     * - `500 Internal Server Error` - Database or server error
     */
    createLedgerEntry(customerID, params, options) {
        const { credit_entitlement_id, ...body } = params;
        return this._client.post((0, path_1.path) `/credit-entitlements/${credit_entitlement_id}/balances/${customerID}/ledger-entries`, { body, ...options });
    }
    /**
     * Returns a paginated list of credit grants with optional filtering by status.
     *
     * # Authentication
     *
     * Requires an API key with `Viewer` role or higher.
     *
     * # Path Parameters
     *
     * - `credit_entitlement_id` - The unique identifier of the credit entitlement
     * - `customer_id` - The unique identifier of the customer
     *
     * # Query Parameters
     *
     * - `page_size` - Number of items per page (default: 10, max: 100)
     * - `page_number` - Zero-based page number (default: 0)
     * - `status` - Filter by status: active, expired, depleted
     *
     * # Responses
     *
     * - `200 OK` - Returns list of grants
     * - `404 Not Found` - Credit entitlement not found
     * - `500 Internal Server Error` - Database or server error
     */
    listGrants(customerID, params, options) {
        const { credit_entitlement_id, ...query } = params;
        return this._client.getAPIList((0, path_1.path) `/credit-entitlements/${credit_entitlement_id}/balances/${customerID}/grants`, (pagination_1.DefaultPageNumberPagination), { query, ...options });
    }
    /**
     * Returns a paginated list of credit transaction history with optional filtering.
     *
     * # Authentication
     *
     * Requires an API key with `Viewer` role or higher.
     *
     * # Path Parameters
     *
     * - `credit_entitlement_id` - The unique identifier of the credit entitlement
     * - `customer_id` - The unique identifier of the customer
     *
     * # Query Parameters
     *
     * - `page_size` - Number of items per page (default: 10, max: 100)
     * - `page_number` - Zero-based page number (default: 0)
     * - `transaction_type` - Filter by transaction type
     * - `start_date` - Filter entries from this date
     * - `end_date` - Filter entries until this date
     *
     * # Responses
     *
     * - `200 OK` - Returns list of ledger entries
     * - `404 Not Found` - Credit entitlement not found
     * - `500 Internal Server Error` - Database or server error
     */
    listLedger(customerID, params, options) {
        const { credit_entitlement_id, ...query } = params;
        return this._client.getAPIList((0, path_1.path) `/credit-entitlements/${credit_entitlement_id}/balances/${customerID}/ledger`, (pagination_1.DefaultPageNumberPagination), { query, ...options });
    }
}
exports.Balances = Balances;
//# sourceMappingURL=balances.js.map
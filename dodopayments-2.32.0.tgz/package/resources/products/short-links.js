"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShortLinks = void 0;
const resource_1 = require("../../core/resource.js");
const pagination_1 = require("../../core/pagination.js");
const path_1 = require("../../internal/utils/path.js");
class ShortLinks extends resource_1.APIResource {
    /**
     * Gives a Short Checkout URL with custom slug for a product. Uses a Static
     * Checkout URL under the hood.
     */
    create(id, body, options) {
        return this._client.post((0, path_1.path) `/products/${id}/short_links`, { body, ...options });
    }
    /**
     * Lists all short links created by the business.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/products/short_links', (pagination_1.DefaultPageNumberPagination), { query, ...options });
    }
}
exports.ShortLinks = ShortLinks;
//# sourceMappingURL=short-links.js.map
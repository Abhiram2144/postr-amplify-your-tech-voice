import { APIResource } from "../../core/resource.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Images extends APIResource {
    update(id: string, params?: ImageUpdateParams | null | undefined, options?: RequestOptions): APIPromise<ImageUpdateResponse>;
}
export interface ImageUpdateResponse {
    url: string;
    image_id?: string | null;
}
export interface ImageUpdateParams {
    force_update?: boolean;
}
export declare namespace Images {
    export { type ImageUpdateResponse as ImageUpdateResponse, type ImageUpdateParams as ImageUpdateParams };
}
//# sourceMappingURL=images.d.mts.map
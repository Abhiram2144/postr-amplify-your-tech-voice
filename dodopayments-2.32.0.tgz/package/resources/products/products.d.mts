import { APIResource } from "../../core/resource.mjs";
import * as ProductsAPI from "./products.mjs";
import * as MiscAPI from "../misc.mjs";
import * as SubscriptionsAPI from "../subscriptions.mjs";
import * as CreditEntitlementsAPI from "../credit-entitlements/credit-entitlements.mjs";
import * as EntitlementsAPI from "../entitlements/entitlements.mjs";
import * as ImagesAPI from "./images.mjs";
import { ImageUpdateParams, ImageUpdateResponse, Images } from "./images.mjs";
import * as ShortLinksAPI from "./short-links.mjs";
import { ShortLinkCreateParams, ShortLinkCreateResponse, ShortLinkListParams, ShortLinkListResponse, ShortLinkListResponsesDefaultPageNumberPagination, ShortLinks } from "./short-links.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { DefaultPageNumberPagination, type DefaultPageNumberPaginationParams, PagePromise } from "../../core/pagination.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Products extends APIResource {
    images: ImagesAPI.Images;
    shortLinks: ShortLinksAPI.ShortLinks;
    create(body: ProductCreateParams, options?: RequestOptions): APIPromise<Product>;
    retrieve(id: string, options?: RequestOptions): APIPromise<Product>;
    update(id: string, body: ProductUpdateParams, options?: RequestOptions): APIPromise<void>;
    list(query?: ProductListParams | null | undefined, options?: RequestOptions): PagePromise<ProductListResponsesDefaultPageNumberPagination, ProductListResponse>;
    archive(id: string, options?: RequestOptions): APIPromise<void>;
    unarchive(id: string, options?: RequestOptions): APIPromise<void>;
    updateFiles(id: string, body: ProductUpdateFilesParams, options?: RequestOptions): APIPromise<ProductUpdateFilesResponse>;
}
export type ProductListResponsesDefaultPageNumberPagination = DefaultPageNumberPagination<ProductListResponse>;
export interface AddMeterToPrice {
    meter_id: string;
    /**
     * Optional credit entitlement ID to link this meter to for credit-based billing
     */
    credit_entitlement_id?: string | null;
    /**
     * Meter description. Will ignored on Request, but will be shown in response
     */
    description?: string | null;
    free_threshold?: number | null;
    /**
     * Meter measurement unit. Will ignored on Request, but will be shown in response
     */
    measurement_unit?: string | null;
    /**
     * Number of meter units that equal one credit. Required when credit_entitlement_id
     * is set.
     */
    meter_units_per_credit?: string | null;
    /**
     * Meter name. Will ignored on Request, but will be shown in response
     */
    name?: string | null;
    /**
     * The price per unit in lowest denomination. Must be greater than zero. Supports
     * up to 5 digits before decimal point and 12 decimal places.
     */
    price_per_unit?: string | null;
}
/**
 * Request struct for attaching a credit entitlement to a product
 */
export interface AttachCreditEntitlement {
    /**
     * ID of the credit entitlement to attach
     */
    credit_entitlement_id: string;
    /**
     * Number of credits to grant when this product is purchased
     */
    credits_amount: string;
    /**
     * Currency for credit-related pricing
     */
    currency?: MiscAPI.Currency | null;
    /**
     * Number of days after which credits expire
     */
    expires_after_days?: number | null;
    /**
     * Balance threshold percentage for low balance notifications (0-100)
     */
    low_balance_threshold_percent?: number | null;
    /**
     * Maximum number of rollover cycles allowed
     */
    max_rollover_count?: number | null;
    /**
     * Controls how overage is handled at billing cycle end.
     */
    overage_behavior?: CreditEntitlementsAPI.CbbOverageBehavior | null;
    /**
     * Whether overage usage is allowed beyond credit balance
     */
    overage_enabled?: boolean | null;
    /**
     * Maximum amount of overage allowed
     */
    overage_limit?: string | null;
    /**
     * Price per credit unit for purchasing additional credits
     */
    price_per_unit?: string | null;
    /**
     * Proration behavior for credit grants during plan changes
     */
    proration_behavior?: CbbProrationBehavior | null;
    /**
     * Whether unused credits can roll over to the next billing period
     */
    rollover_enabled?: boolean | null;
    /**
     * Percentage of unused credits that can roll over (0-100)
     */
    rollover_percentage?: number | null;
    /**
     * Number of timeframe units for rollover window
     */
    rollover_timeframe_count?: number | null;
    /**
     * Time interval for rollover window (day, week, month, year)
     */
    rollover_timeframe_interval?: SubscriptionsAPI.TimeInterval | null;
    /**
     * Credits granted during trial period
     */
    trial_credits?: string | null;
    /**
     * Whether trial credits expire when trial ends
     */
    trial_credits_expire_after_trial?: boolean | null;
}
/**
 * Request struct for attaching an entitlement to a product.
 *
 * Mirrors the `credit_entitlements` attach shape — every "attach something to a
 * product" array takes objects, not bare IDs. Uniform shape leaves room for
 * per-attachment settings later without another API break.
 */
export interface AttachProductEntitlement {
    /**
     * ID of the entitlement to attach to the product
     */
    entitlement_id: string;
}
export type CbbProrationBehavior = 'prorate' | 'no_prorate';
/**
 * Response struct for credit entitlement mapping
 */
export interface CreditEntitlementMappingResponse {
    /**
     * Unique ID of this mapping
     */
    id: string;
    /**
     * ID of the credit entitlement
     */
    credit_entitlement_id: string;
    /**
     * Name of the credit entitlement
     */
    credit_entitlement_name: string;
    /**
     * Unit label for the credit entitlement
     */
    credit_entitlement_unit: string;
    /**
     * Number of credits granted
     */
    credits_amount: string;
    /**
     * Controls how overage is handled at billing cycle end.
     */
    overage_behavior: CreditEntitlementsAPI.CbbOverageBehavior;
    /**
     * Whether overage is enabled
     */
    overage_enabled: boolean;
    /**
     * Proration behavior for credit grants during plan changes
     */
    proration_behavior: CbbProrationBehavior;
    /**
     * Whether rollover is enabled
     */
    rollover_enabled: boolean;
    /**
     * Whether trial credits expire after trial
     */
    trial_credits_expire_after_trial: boolean;
    /**
     * Currency
     */
    currency?: MiscAPI.Currency | null;
    /**
     * Days until credits expire
     */
    expires_after_days?: number | null;
    /**
     * Low balance threshold percentage
     */
    low_balance_threshold_percent?: number | null;
    /**
     * Maximum rollover cycles
     */
    max_rollover_count?: number | null;
    /**
     * Overage limit
     */
    overage_limit?: string | null;
    /**
     * Price per unit
     */
    price_per_unit?: string | null;
    /**
     * Rollover percentage
     */
    rollover_percentage?: number | null;
    /**
     * Rollover timeframe count
     */
    rollover_timeframe_count?: number | null;
    /**
     * Rollover timeframe interval
     */
    rollover_timeframe_interval?: SubscriptionsAPI.TimeInterval | null;
    /**
     * Trial credits
     */
    trial_credits?: string | null;
}
/**
 * Digital-product-delivery payload, present on grants for `digital_files`
 * entitlements. Each file carries a short-lived presigned download URL.
 */
export interface DigitalProductDelivery {
    /**
     * One entry per attached file.
     */
    files: Array<DigitalProductDeliveryFile>;
    /**
     * Optional external URL, passed through from the entitlement configuration.
     */
    external_url?: string | null;
    /**
     * Optional human-readable delivery instructions, passed through from the
     * entitlement configuration.
     */
    instructions?: string | null;
}
/**
 * One file in a digital-product delivery payload.
 */
export interface DigitalProductDeliveryFile {
    /**
     * Short-lived presigned URL for downloading the file.
     */
    download_url: string;
    /**
     * Seconds until `download_url` expires.
     */
    expires_in: number;
    /**
     * Identifier of the attached file.
     */
    file_id: string;
    /**
     * Original filename of the attached file.
     */
    filename: string;
    /**
     * Optional content-type declared at upload.
     */
    content_type?: string | null;
    /**
     * Optional size of the file in bytes.
     */
    file_size?: number | null;
}
export interface LicenseKeyDuration {
    count: number;
    interval: SubscriptionsAPI.TimeInterval;
}
/**
 * One-time price details.
 */
export type Price = Price.OneTimePrice | Price.RecurringPrice | Price.UsageBasedPrice;
export declare namespace Price {
    /**
     * One-time price details.
     */
    interface OneTimePrice {
        /**
         * The currency in which the payment is made.
         */
        currency: MiscAPI.Currency;
        /**
         * Discount applied to the price, represented as a percentage (0 to 100).
         */
        discount: number;
        /**
         * The payment amount, in the smallest denomination of the currency (e.g., cents
         * for USD). For example, to charge $1.00, pass `100`.
         *
         * If [`pay_what_you_want`](Self::pay_what_you_want) is set to `true`, this field
         * represents the **minimum** amount the customer must pay.
         */
        price: number;
        /**
         * Indicates if purchasing power parity adjustments are applied to the price.
         * Purchasing power parity feature is not available as of now.
         */
        purchasing_power_parity: boolean;
        type: 'one_time_price';
        /**
         * Indicates whether the customer can pay any amount they choose. If set to `true`,
         * the [`price`](Self::price) field is the minimum amount.
         */
        pay_what_you_want?: boolean;
        /**
         * A suggested price for the user to pay. This value is only considered if
         * [`pay_what_you_want`](Self::pay_what_you_want) is `true`. Otherwise, it is
         * ignored.
         */
        suggested_price?: number | null;
        /**
         * Indicates if the price is tax inclusive.
         */
        tax_inclusive?: boolean | null;
    }
    /**
     * Recurring price details.
     */
    interface RecurringPrice {
        /**
         * The currency in which the payment is made.
         */
        currency: MiscAPI.Currency;
        /**
         * Discount applied to the price, represented as a percentage (0 to 100).
         */
        discount: number;
        /**
         * Number of units for the payment frequency. For example, a value of `1` with a
         * `payment_frequency_interval` of `month` represents monthly payments.
         */
        payment_frequency_count: number;
        /**
         * The time interval for the payment frequency (e.g., day, month, year).
         */
        payment_frequency_interval: SubscriptionsAPI.TimeInterval;
        /**
         * The payment amount. Represented in the lowest denomination of the currency
         * (e.g., cents for USD). For example, to charge $1.00, pass `100`.
         */
        price: number;
        /**
         * Indicates if purchasing power parity adjustments are applied to the price.
         * Purchasing power parity feature is not available as of now
         */
        purchasing_power_parity: boolean;
        /**
         * Number of units for the subscription period. For example, a value of `12` with a
         * `subscription_period_interval` of `month` represents a one-year subscription.
         */
        subscription_period_count: number;
        /**
         * The time interval for the subscription period (e.g., day, month, year).
         */
        subscription_period_interval: SubscriptionsAPI.TimeInterval;
        type: 'recurring_price';
        /**
         * Indicates if the price is tax inclusive
         */
        tax_inclusive?: boolean | null;
        /**
         * Number of days for the trial period. A value of `0` indicates no trial period.
         */
        trial_period_days?: number;
    }
    /**
     * Usage Based price details.
     */
    interface UsageBasedPrice {
        /**
         * The currency in which the payment is made.
         */
        currency: MiscAPI.Currency;
        /**
         * Discount applied to the price, represented as a percentage (0 to 100).
         */
        discount: number;
        /**
         * The fixed payment amount. Represented in the lowest denomination of the currency
         * (e.g., cents for USD). For example, to charge $1.00, pass `100`.
         */
        fixed_price: number;
        /**
         * Number of units for the payment frequency. For example, a value of `1` with a
         * `payment_frequency_interval` of `month` represents monthly payments.
         */
        payment_frequency_count: number;
        /**
         * The time interval for the payment frequency (e.g., day, month, year).
         */
        payment_frequency_interval: SubscriptionsAPI.TimeInterval;
        /**
         * Indicates if purchasing power parity adjustments are applied to the price.
         * Purchasing power parity feature is not available as of now
         */
        purchasing_power_parity: boolean;
        /**
         * Number of units for the subscription period. For example, a value of `12` with a
         * `subscription_period_interval` of `month` represents a one-year subscription.
         */
        subscription_period_count: number;
        /**
         * The time interval for the subscription period (e.g., day, month, year).
         */
        subscription_period_interval: SubscriptionsAPI.TimeInterval;
        type: 'usage_based_price';
        meters?: Array<ProductsAPI.AddMeterToPrice> | null;
        /**
         * Indicates if the price is tax inclusive
         */
        tax_inclusive?: boolean | null;
    }
}
export interface Product {
    brand_id: string;
    /**
     * Unique identifier for the business to which the product belongs.
     */
    business_id: string;
    /**
     * Timestamp when the product was created.
     */
    created_at: string;
    /**
     * Attached credit entitlements with settings
     */
    credit_entitlements: Array<CreditEntitlementMappingResponse>;
    /**
     * Attached entitlements (integration-based access grants)
     */
    entitlements: Array<ProductEntitlementSummary>;
    /**
     * Indicates if the product is recurring (e.g., subscriptions).
     */
    is_recurring: boolean;
    /**
     * @deprecated Use the dedicated entitlements API to configure license-key
     * delivery.
     */
    license_key_enabled: boolean;
    /**
     * Additional custom data associated with the product
     */
    metadata: {
        [key: string]: string;
    };
    /**
     * Pricing information for the product.
     */
    price: Price;
    /**
     * Unique identifier for the product.
     */
    product_id: string;
    /**
     * Tax category associated with the product.
     */
    tax_category: MiscAPI.TaxCategory;
    /**
     * Timestamp when the product was last updated.
     */
    updated_at: string;
    /**
     * Available Addons for subscription products
     */
    addons?: Array<string> | null;
    /**
     * Description of the product, optional.
     */
    description?: string | null;
    /**
     * Digital-product-delivery payload, present on grants for `digital_files`
     * entitlements. Each file carries a short-lived presigned download URL.
     */
    digital_product_delivery?: DigitalProductDelivery | null;
    /**
     * URL of the product image, optional.
     */
    image?: string | null;
    /**
     * @deprecated Use the dedicated entitlements API to configure license-key
     * delivery.
     */
    license_key_activation_message?: string | null;
    /**
     * @deprecated Use the dedicated entitlements API to configure license-key
     * delivery.
     */
    license_key_activations_limit?: number | null;
    /**
     * Duration of the license key validity, if enabled.
     */
    license_key_duration?: LicenseKeyDuration | null;
    /**
     * Name of the product, optional.
     */
    name?: string | null;
    /**
     * The product collection ID this product belongs to, if any
     */
    product_collection_id?: string | null;
}
/**
 * Summary of an entitlement attached to a product.
 *
 * `integration_config` uses [`IntegrationConfigResponse`] (NOT the persisted
 * [`IntegrationConfig`]) so digital_files entitlements embed the resolved
 * `digital_files` object — matching what `GET /entitlements/{id}` returns. All
 * other variants pass through unchanged via `#[serde(untagged)]`.
 */
export interface ProductEntitlementSummary {
    id: string;
    /**
     * Integration-specific configuration on an entitlement read response.
     *
     * For `digital_files` entitlements the response includes presigned download URLs
     * for each attached file; other integrations match the shape supplied at creation.
     */
    integration_config: EntitlementsAPI.IntegrationConfigResponse;
    integration_type: EntitlementsAPI.EntitlementIntegrationType;
    name: string;
    description?: string | null;
}
export interface ProductListResponse {
    /**
     * Unique identifier for the business to which the product belongs.
     */
    business_id: string;
    /**
     * Timestamp when the product was created.
     */
    created_at: string;
    /**
     * Entitlements linked to this product
     */
    entitlements: Array<ProductEntitlementSummary>;
    /**
     * Indicates if the product is recurring (e.g., subscriptions).
     */
    is_recurring: boolean;
    /**
     * Additional custom data associated with the product
     */
    metadata: {
        [key: string]: string;
    };
    /**
     * Unique identifier for the product.
     */
    product_id: string;
    /**
     * Tax category associated with the product.
     */
    tax_category: MiscAPI.TaxCategory;
    /**
     * Timestamp when the product was last updated.
     */
    updated_at: string;
    /**
     * Currency of the price
     */
    currency?: MiscAPI.Currency | null;
    /**
     * Description of the product, optional.
     */
    description?: string | null;
    /**
     * URL of the product image, optional.
     */
    image?: string | null;
    /**
     * Name of the product, optional.
     */
    name?: string | null;
    /**
     * Price of the product, optional.
     *
     * The price is represented in the lowest denomination of the currency. For
     * example:
     *
     * - In USD, a price of `$12.34` would be represented as `1234` (cents).
     * - In JPY, a price of `¥1500` would be represented as `1500` (yen).
     * - In INR, a price of `₹1234.56` would be represented as `123456` (paise).
     *
     * This ensures precision and avoids floating-point rounding errors.
     */
    price?: number | null;
    /**
     * Details of the price
     */
    price_detail?: Price | null;
    /**
     * Indicates if the price is tax inclusive
     */
    tax_inclusive?: boolean | null;
}
export interface ProductUpdateFilesResponse {
    file_id: string;
    url: string;
}
export interface ProductCreateParams {
    /**
     * Name of the product
     */
    name: string;
    /**
     * Price configuration for the product
     */
    price: Price;
    /**
     * Tax category applied to this product
     */
    tax_category: MiscAPI.TaxCategory;
    /**
     * Addons available for subscription product
     */
    addons?: Array<string> | null;
    /**
     * Brand id for the product, if not provided will default to primary brand
     */
    brand_id?: string | null;
    /**
     * Optional credit entitlements to attach (max 3)
     */
    credit_entitlements?: Array<AttachCreditEntitlement> | null;
    /**
     * Optional description of the product
     */
    description?: string | null;
    /**
     * Choose how you would like you digital product delivered
     *
     * deprecated: use entitlements instead
     */
    digital_product_delivery?: ProductCreateParams.DigitalProductDelivery | null;
    /**
     * Optional entitlements to attach to this product (max 20)
     */
    entitlements?: Array<AttachProductEntitlement> | null;
    /**
     * @deprecated Use the dedicated entitlements API to configure license-key
     * delivery.
     */
    license_key_activation_message?: string | null;
    /**
     * @deprecated Use the dedicated entitlements API to configure license-key
     * delivery.
     */
    license_key_activations_limit?: number | null;
    /**
     * Duration configuration for the license key. Set to null if you don't want the
     * license key to expire. For subscriptions, the lifetime of the license key is
     * tied to the subscription period
     *
     * deprecated: use entitlements instead. Ignored when a `license_key` entitlement
     * is attached via the `entitlements` field.
     */
    license_key_duration?: LicenseKeyDuration | null;
    /**
     * @deprecated Use the dedicated entitlements API to configure license-key
     * delivery.
     */
    license_key_enabled?: boolean | null;
    /**
     * Additional metadata for the product
     */
    metadata?: {
        [key: string]: string;
    };
}
export declare namespace ProductCreateParams {
    /**
     * Choose how you would like you digital product delivered
     *
     * deprecated: use entitlements instead
     */
    interface DigitalProductDelivery {
        /**
         * External URL to digital product
         */
        external_url?: string | null;
        /**
         * Instructions to download and use the digital product
         */
        instructions?: string | null;
    }
}
export interface ProductUpdateParams {
    /**
     * Available Addons for subscription products
     */
    addons?: Array<string> | null;
    brand_id?: string | null;
    /**
     * Credit entitlements to update (replaces all existing when present) Send empty
     * array to remove all, omit field to leave unchanged
     */
    credit_entitlements?: Array<AttachCreditEntitlement> | null;
    /**
     * Description of the product, optional and must be at most 1000 characters.
     */
    description?: string | null;
    /**
     * Choose how you would like you digital product delivered
     *
     * deprecated: use entitlements instead
     */
    digital_product_delivery?: ProductUpdateParams.DigitalProductDelivery | null;
    /**
     * Entitlements to attach (replaces all existing when present) Send empty array to
     * remove all, omit field to leave unchanged
     */
    entitlements?: Array<AttachProductEntitlement> | null;
    /**
     * Product image id after its uploaded to S3
     */
    image_id?: string | null;
    /**
     * @deprecated Use the dedicated entitlements API to configure license-key
     * delivery.
     */
    license_key_activation_message?: string | null;
    /**
     * @deprecated Use the dedicated entitlements API to configure license-key
     * delivery.
     */
    license_key_activations_limit?: number | null;
    /**
     * Duration of the license key if enabled.
     *
     * Only applicable if `license_key_enabled` is `true`. Represents the duration in
     * days for which the license key is valid.
     *
     * deprecated: use entitlements instead
     */
    license_key_duration?: LicenseKeyDuration | null;
    /**
     * @deprecated Use the dedicated entitlements API to configure license-key
     * delivery.
     */
    license_key_enabled?: boolean | null;
    /**
     * Additional metadata for the product
     */
    metadata?: {
        [key: string]: string;
    } | null;
    /**
     * Name of the product, optional and must be at most 100 characters.
     */
    name?: string | null;
    /**
     * Price details of the product.
     */
    price?: Price | null;
    /**
     * Tax category of the product.
     */
    tax_category?: MiscAPI.TaxCategory | null;
}
export declare namespace ProductUpdateParams {
    /**
     * Choose how you would like you digital product delivered
     *
     * deprecated: use entitlements instead
     */
    interface DigitalProductDelivery {
        /**
         * External URL to digital product
         */
        external_url?: string | null;
        /**
         * Uploaded files ids of digital product
         */
        files?: Array<string> | null;
        /**
         * Instructions to download and use the digital product
         */
        instructions?: string | null;
    }
}
export interface ProductListParams extends DefaultPageNumberPaginationParams {
    /**
     * List archived products
     */
    archived?: boolean;
    /**
     * filter by Brand id
     */
    brand_id?: string;
    /**
     * Filter products by pricing type:
     *
     * - `true`: Show only recurring pricing products (e.g. subscriptions)
     * - `false`: Show only one-time price products
     * - `null` or absent: Show both types of products
     */
    recurring?: boolean;
}
export interface ProductUpdateFilesParams {
    file_name: string;
}
export declare namespace Products {
    export { type AddMeterToPrice as AddMeterToPrice, type AttachCreditEntitlement as AttachCreditEntitlement, type AttachProductEntitlement as AttachProductEntitlement, type CbbProrationBehavior as CbbProrationBehavior, type CreditEntitlementMappingResponse as CreditEntitlementMappingResponse, type DigitalProductDelivery as DigitalProductDelivery, type DigitalProductDeliveryFile as DigitalProductDeliveryFile, type LicenseKeyDuration as LicenseKeyDuration, type Price as Price, type Product as Product, type ProductEntitlementSummary as ProductEntitlementSummary, type ProductListResponse as ProductListResponse, type ProductUpdateFilesResponse as ProductUpdateFilesResponse, type ProductListResponsesDefaultPageNumberPagination as ProductListResponsesDefaultPageNumberPagination, type ProductCreateParams as ProductCreateParams, type ProductUpdateParams as ProductUpdateParams, type ProductListParams as ProductListParams, type ProductUpdateFilesParams as ProductUpdateFilesParams, };
    export { Images as Images, type ImageUpdateResponse as ImageUpdateResponse, type ImageUpdateParams as ImageUpdateParams, };
    export { ShortLinks as ShortLinks, type ShortLinkCreateResponse as ShortLinkCreateResponse, type ShortLinkListResponse as ShortLinkListResponse, type ShortLinkListResponsesDefaultPageNumberPagination as ShortLinkListResponsesDefaultPageNumberPagination, type ShortLinkCreateParams as ShortLinkCreateParams, type ShortLinkListParams as ShortLinkListParams, };
}
//# sourceMappingURL=products.d.mts.map
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../../core/pagination.mjs";
import { path } from "../../internal/utils/path.mjs";
export class ShortLinks extends APIResource {
    /**
     * Gives a Short Checkout URL with custom slug for a product. Uses a Static
     * Checkout URL under the hood.
     */
    create(id, body, options) {
        return this._client.post(path `/products/${id}/short_links`, { body, ...options });
    }
    /**
     * Lists all short links created by the business.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/products/short_links', (DefaultPageNumberPagination), { query, ...options });
    }
}
//# sourceMappingURL=short-links.mjs.map
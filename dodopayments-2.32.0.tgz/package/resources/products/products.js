"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Products = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const ImagesAPI = tslib_1.__importStar(require("./images.js"));
const images_1 = require("./images.js");
const ShortLinksAPI = tslib_1.__importStar(require("./short-links.js"));
const short_links_1 = require("./short-links.js");
const pagination_1 = require("../../core/pagination.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Products extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.images = new ImagesAPI.Images(this._client);
        this.shortLinks = new ShortLinksAPI.ShortLinks(this._client);
    }
    create(body, options) {
        return this._client.post('/products', { body, ...options });
    }
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/products/${id}`, options);
    }
    update(id, body, options) {
        return this._client.patch((0, path_1.path) `/products/${id}`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    list(query = {}, options) {
        return this._client.getAPIList('/products', (pagination_1.DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    archive(id, options) {
        return this._client.delete((0, path_1.path) `/products/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    unarchive(id, options) {
        return this._client.post((0, path_1.path) `/products/${id}/unarchive`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    updateFiles(id, body, options) {
        return this._client.put((0, path_1.path) `/products/${id}/files`, { body, ...options });
    }
}
exports.Products = Products;
Products.Images = images_1.Images;
Products.ShortLinks = short_links_1.ShortLinks;
//# sourceMappingURL=products.js.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Images = void 0;
const resource_1 = require("../../core/resource.js");
const path_1 = require("../../internal/utils/path.js");
class Images extends resource_1.APIResource {
    update(id, params = {}, options) {
        const { force_update } = params ?? {};
        return this._client.put((0, path_1.path) `/products/${id}/images`, { query: { force_update }, ...options });
    }
}
exports.Images = Images;
//# sourceMappingURL=images.js.map
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Images extends APIResource {
    update(id, params = {}, options) {
        const { force_update } = params ?? {};
        return this._client.put(path `/products/${id}/images`, { query: { force_update }, ...options });
    }
}
//# sourceMappingURL=images.mjs.map
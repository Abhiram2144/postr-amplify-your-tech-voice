// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as ImagesAPI from "./images.mjs";
import { Images } from "./images.mjs";
import * as ShortLinksAPI from "./short-links.mjs";
import { ShortLinks, } from "./short-links.mjs";
import { DefaultPageNumberPagination, } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Products extends APIResource {
    constructor() {
        super(...arguments);
        this.images = new ImagesAPI.Images(this._client);
        this.shortLinks = new ShortLinksAPI.ShortLinks(this._client);
    }
    create(body, options) {
        return this._client.post('/products', { body, ...options });
    }
    retrieve(id, options) {
        return this._client.get(path `/products/${id}`, options);
    }
    update(id, body, options) {
        return this._client.patch(path `/products/${id}`, {
            body,
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    list(query = {}, options) {
        return this._client.getAPIList('/products', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    archive(id, options) {
        return this._client.delete(path `/products/${id}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    unarchive(id, options) {
        return this._client.post(path `/products/${id}/unarchive`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    updateFiles(id, body, options) {
        return this._client.put(path `/products/${id}/files`, { body, ...options });
    }
}
Products.Images = Images;
Products.ShortLinks = ShortLinks;
//# sourceMappingURL=products.mjs.map
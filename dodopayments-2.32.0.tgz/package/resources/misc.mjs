// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
export class Misc extends APIResource {
    listSupportedCountries(options) {
        return this._client.get('/checkout/supported_countries', options);
    }
}
//# sourceMappingURL=misc.mjs.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookEvents = void 0;
const resource_1 = require("../core/resource.js");
class WebhookEvents extends resource_1.APIResource {
}
exports.WebhookEvents = WebhookEvents;
//# sourceMappingURL=webhook-events.js.map
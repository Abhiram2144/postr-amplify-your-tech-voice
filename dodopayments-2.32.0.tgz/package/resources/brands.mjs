// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { path } from "../internal/utils/path.mjs";
export class Brands extends APIResource {
    create(body, options) {
        return this._client.post('/brands', { body, ...options });
    }
    /**
     * Thin handler just calls `get_brand` and wraps in `Json(...)`
     */
    retrieve(id, options) {
        return this._client.get(path `/brands/${id}`, options);
    }
    update(id, body, options) {
        return this._client.patch(path `/brands/${id}`, { body, ...options });
    }
    list(options) {
        return this._client.get('/brands', options);
    }
    updateImages(id, options) {
        return this._client.put(path `/brands/${id}/images`, options);
    }
}
//# sourceMappingURL=brands.mjs.map
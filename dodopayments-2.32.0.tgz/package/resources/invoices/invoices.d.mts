import { APIResource } from "../../core/resource.mjs";
import * as PaymentsAPI from "./payments.mjs";
import { Payments } from "./payments.mjs";
export declare class Invoices extends APIResource {
    payments: PaymentsAPI.Payments;
}
export declare namespace Invoices {
    export { Payments as Payments };
}
//# sourceMappingURL=invoices.d.mts.map
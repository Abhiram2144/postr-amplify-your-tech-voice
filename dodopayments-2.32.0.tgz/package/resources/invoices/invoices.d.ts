import { APIResource } from "../../core/resource.js";
import * as PaymentsAPI from "./payments.js";
import { Payments } from "./payments.js";
export declare class Invoices extends APIResource {
    payments: PaymentsAPI.Payments;
}
export declare namespace Invoices {
    export { Payments as Payments };
}
//# sourceMappingURL=invoices.d.ts.map
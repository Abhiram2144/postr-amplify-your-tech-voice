// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Payments extends APIResource {
    retrieve(paymentID, options) {
        return this._client.get(path `/invoices/payments/${paymentID}`, {
            ...options,
            headers: buildHeaders([{ Accept: 'application/pdf' }, options?.headers]),
            __binaryResponse: true,
        });
    }
    retrievePayout(payoutID, options) {
        return this._client.get(path `/invoices/payouts/${payoutID}`, {
            ...options,
            headers: buildHeaders([{ Accept: 'application/pdf' }, options?.headers]),
            __binaryResponse: true,
        });
    }
    retrieveRefund(refundID, options) {
        return this._client.get(path `/invoices/refunds/${refundID}`, {
            ...options,
            headers: buildHeaders([{ Accept: 'application/pdf' }, options?.headers]),
            __binaryResponse: true,
        });
    }
}
//# sourceMappingURL=payments.mjs.map
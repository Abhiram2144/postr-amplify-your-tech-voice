// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as PaymentsAPI from "./payments.mjs";
import { Payments } from "./payments.mjs";
export class Invoices extends APIResource {
    constructor() {
        super(...arguments);
        this.payments = new PaymentsAPI.Payments(this._client);
    }
}
Invoices.Payments = Payments;
//# sourceMappingURL=invoices.mjs.map
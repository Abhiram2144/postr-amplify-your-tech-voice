import { APIResource } from "../../core/resource.js";
import { APIPromise } from "../../core/api-promise.js";
import { RequestOptions } from "../../internal/request-options.js";
export declare class Payments extends APIResource {
    retrieve(paymentID: string, options?: RequestOptions): APIPromise<Response>;
    retrievePayout(payoutID: string, options?: RequestOptions): APIPromise<Response>;
    retrieveRefund(refundID: string, options?: RequestOptions): APIPromise<Response>;
}
//# sourceMappingURL=payments.d.ts.map
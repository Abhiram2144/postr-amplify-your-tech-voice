import { APIResource } from "../../core/resource.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Payments extends APIResource {
    retrieve(paymentID: string, options?: RequestOptions): APIPromise<Response>;
    retrievePayout(payoutID: string, options?: RequestOptions): APIPromise<Response>;
    retrieveRefund(refundID: string, options?: RequestOptions): APIPromise<Response>;
}
//# sourceMappingURL=payments.d.mts.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Payments = void 0;
const resource_1 = require("../../core/resource.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Payments extends resource_1.APIResource {
    retrieve(paymentID, options) {
        return this._client.get((0, path_1.path) `/invoices/payments/${paymentID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: 'application/pdf' }, options?.headers]),
            __binaryResponse: true,
        });
    }
    retrievePayout(payoutID, options) {
        return this._client.get((0, path_1.path) `/invoices/payouts/${payoutID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: 'application/pdf' }, options?.headers]),
            __binaryResponse: true,
        });
    }
    retrieveRefund(refundID, options) {
        return this._client.get((0, path_1.path) `/invoices/refunds/${refundID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: 'application/pdf' }, options?.headers]),
            __binaryResponse: true,
        });
    }
}
exports.Payments = Payments;
//# sourceMappingURL=payments.js.map
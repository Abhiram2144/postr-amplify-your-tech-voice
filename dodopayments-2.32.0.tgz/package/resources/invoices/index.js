"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Payments = exports.Invoices = void 0;
var invoices_1 = require("./invoices.js");
Object.defineProperty(exports, "Invoices", { enumerable: true, get: function () { return invoices_1.Invoices; } });
var payments_1 = require("./payments.js");
Object.defineProperty(exports, "Payments", { enumerable: true, get: function () { return payments_1.Payments; } });
//# sourceMappingURL=index.js.map
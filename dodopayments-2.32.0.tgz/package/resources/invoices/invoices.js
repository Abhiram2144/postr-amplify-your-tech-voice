"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Invoices = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const PaymentsAPI = tslib_1.__importStar(require("./payments.js"));
const payments_1 = require("./payments.js");
class Invoices extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.payments = new PaymentsAPI.Payments(this._client);
    }
}
exports.Invoices = Invoices;
Invoices.Payments = payments_1.Payments;
//# sourceMappingURL=invoices.js.map
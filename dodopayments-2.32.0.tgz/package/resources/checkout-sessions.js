"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheckoutSessions = void 0;
const resource_1 = require("../core/resource.js");
const path_1 = require("../internal/utils/path.js");
class CheckoutSessions extends resource_1.APIResource {
    create(body, options) {
        return this._client.post('/checkouts', { body, ...options });
    }
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/checkouts/${id}`, options);
    }
    preview(body, options) {
        return this._client.post('/checkouts/preview', { body, ...options });
    }
}
exports.CheckoutSessions = CheckoutSessions;
//# sourceMappingURL=checkout-sessions.js.map
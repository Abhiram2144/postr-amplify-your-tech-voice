// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../core/pagination.mjs";
import { path } from "../internal/utils/path.mjs";
export class Disputes extends APIResource {
    retrieve(disputeID, options) {
        return this._client.get(path `/disputes/${disputeID}`, options);
    }
    list(query = {}, options) {
        return this._client.getAPIList('/disputes', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
}
//# sourceMappingURL=disputes.mjs.map
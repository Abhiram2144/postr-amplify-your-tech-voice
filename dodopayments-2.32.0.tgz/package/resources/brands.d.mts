import { APIResource } from "../core/resource.mjs";
import { APIPromise } from "../core/api-promise.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
export declare class Brands extends APIResource {
    create(body: BrandCreateParams, options?: RequestOptions): APIPromise<Brand>;
    /**
     * Thin handler just calls `get_brand` and wraps in `Json(...)`
     */
    retrieve(id: string, options?: RequestOptions): APIPromise<Brand>;
    update(id: string, body: BrandUpdateParams, options?: RequestOptions): APIPromise<Brand>;
    list(options?: RequestOptions): APIPromise<BrandListResponse>;
    updateImages(id: string, options?: RequestOptions): APIPromise<BrandUpdateImagesResponse>;
}
export interface Brand {
    brand_id: string;
    business_id: string;
    enabled: boolean;
    statement_descriptor: string;
    verification_enabled: boolean;
    verification_status: 'Success' | 'Fail' | 'Review' | 'Hold';
    description?: string | null;
    image?: string | null;
    name?: string | null;
    /**
     * Incase the brand verification fails or is put on hold
     */
    reason_for_hold?: string | null;
    support_email?: string | null;
    url?: string | null;
}
export interface BrandListResponse {
    /**
     * List of brands for this business
     */
    items: Array<Brand>;
}
export interface BrandUpdateImagesResponse {
    /**
     * UUID that will be used as the image identifier/key suffix
     */
    image_id: string;
    /**
     * Presigned URL to upload the image
     */
    url: string;
}
export interface BrandCreateParams {
    description?: string | null;
    name?: string | null;
    statement_descriptor?: string | null;
    support_email?: string | null;
    url?: string | null;
}
export interface BrandUpdateParams {
    description?: string | null;
    /**
     * The UUID you got back from the presigned‐upload call
     */
    image_id?: string | null;
    name?: string | null;
    statement_descriptor?: string | null;
    support_email?: string | null;
    url?: string | null;
}
export declare namespace Brands {
    export { type Brand as Brand, type BrandListResponse as BrandListResponse, type BrandUpdateImagesResponse as BrandUpdateImagesResponse, type BrandCreateParams as BrandCreateParams, type BrandUpdateParams as BrandUpdateParams, };
}
//# sourceMappingURL=brands.d.mts.map
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../core/pagination.mjs";
import { buildHeaders } from "../internal/headers.mjs";
import { path } from "../internal/utils/path.mjs";
export class Meters extends APIResource {
    create(body, options) {
        return this._client.post('/meters', { body, ...options });
    }
    retrieve(id, options) {
        return this._client.get(path `/meters/${id}`, options);
    }
    list(query = {}, options) {
        return this._client.getAPIList('/meters', (DefaultPageNumberPagination), { query, ...options });
    }
    archive(id, options) {
        return this._client.delete(path `/meters/${id}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    unarchive(id, options) {
        return this._client.post(path `/meters/${id}/unarchive`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=meters.mjs.map
import { APIResource } from "../core/resource.mjs";
import * as DisputesAPI from "./disputes.mjs";
import * as LicenseKeysAPI from "./license-keys.mjs";
import * as PaymentsAPI from "./payments.mjs";
import * as RefundsAPI from "./refunds.mjs";
import * as SubscriptionsAPI from "./subscriptions.mjs";
import * as BalancesAPI from "./credit-entitlements/balances.mjs";
import * as GrantsAPI from "./entitlements/grants.mjs";
export declare class WebhookEvents extends APIResource {
}
/**
 * Event types for Dodo events
 */
export type WebhookEventType = 'payment.succeeded' | 'payment.failed' | 'payment.processing' | 'payment.cancelled' | 'refund.succeeded' | 'refund.failed' | 'dispute.opened' | 'dispute.expired' | 'dispute.accepted' | 'dispute.cancelled' | 'dispute.challenged' | 'dispute.won' | 'dispute.lost' | 'subscription.active' | 'subscription.renewed' | 'subscription.on_hold' | 'subscription.paused' | 'subscription.cancelled' | 'subscription.failed' | 'subscription.expired' | 'subscription.plan_changed' | 'subscription.updated' | 'license_key.created' | 'payout.not_initiated' | 'payout.on_hold' | 'payout.in_progress' | 'payout.failed' | 'payout.success' | 'credit.added' | 'credit.deducted' | 'credit.expired' | 'credit.rolled_over' | 'credit.rollover_forfeited' | 'credit.overage_charged' | 'credit.overage_reset' | 'credit.manual_adjustment' | 'credit.balance_low' | 'abandoned_checkout.detected' | 'abandoned_checkout.recovered' | 'dunning.started' | 'dunning.recovered' | 'entitlement_grant.created' | 'entitlement_grant.delivered' | 'entitlement_grant.failed' | 'entitlement_grant.revoked';
export interface WebhookPayload {
    business_id: string;
    /**
     * The latest data at the time of delivery attempt
     */
    data: WebhookPayload.Payment | WebhookPayload.Subscription | WebhookPayload.Refund | WebhookPayload.Dispute | WebhookPayload.LicenseKey | WebhookPayload.CreditLedgerEntry | WebhookPayload.CreditBalanceLow | WebhookPayload.AbandonedCheckout | WebhookPayload.DunningAttempt | WebhookPayload.EntitlementGrant;
    /**
     * The timestamp of when the event occurred (not necessarily the same of when it
     * was delivered)
     */
    timestamp: string;
    /**
     * Event types for Dodo events
     */
    type: WebhookEventType;
}
export declare namespace WebhookPayload {
    interface Payment extends PaymentsAPI.Payment {
        payload_type: 'Payment';
    }
    /**
     * Response struct representing subscription details
     */
    interface Subscription extends SubscriptionsAPI.Subscription {
        payload_type: 'Subscription';
    }
    interface Refund extends RefundsAPI.Refund {
        payload_type: 'Refund';
    }
    interface Dispute extends DisputesAPI.GetDispute {
        payload_type: 'Dispute';
    }
    interface LicenseKey extends LicenseKeysAPI.LicenseKey {
        payload_type: 'LicenseKey';
    }
    /**
     * Response for a ledger entry
     */
    interface CreditLedgerEntry extends BalancesAPI.CreditLedgerEntry {
        payload_type: 'CreditLedgerEntry';
    }
    interface CreditBalanceLow {
        available_balance: string;
        credit_entitlement_id: string;
        credit_entitlement_name: string;
        customer_id: string;
        payload_type: 'CreditBalanceLow';
        subscription_credits_amount: string;
        subscription_id: string;
        threshold_amount: string;
        threshold_percent: number;
    }
    interface AbandonedCheckout {
        abandoned_at: string;
        abandonment_reason: 'payment_failed' | 'checkout_incomplete';
        customer_id: string;
        payload_type: 'AbandonedCheckout';
        payment_id: string;
        status: 'abandoned' | 'recovering' | 'recovered' | 'exhausted' | 'opted_out';
        recovered_payment_id?: string | null;
    }
    interface DunningAttempt {
        created_at: string;
        customer_id: string;
        payload_type: 'DunningAttempt';
        status: 'recovering' | 'recovered' | 'exhausted';
        subscription_id: string;
        trigger_state: 'on_hold' | 'cancelled';
        payment_id?: string | null;
    }
    /**
     * Detailed view of a single entitlement grant: who it's for, its lifecycle state,
     * and any integration-specific delivery payload.
     */
    interface EntitlementGrant extends GrantsAPI.EntitlementGrant {
        payload_type: 'EntitlementGrant';
    }
}
export declare namespace WebhookEvents {
    export { type WebhookEventType as WebhookEventType, type WebhookPayload as WebhookPayload };
}
//# sourceMappingURL=webhook-events.d.mts.map
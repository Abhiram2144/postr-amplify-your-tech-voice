"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Meters = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class Meters extends resource_1.APIResource {
    create(body, options) {
        return this._client.post('/meters', { body, ...options });
    }
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/meters/${id}`, options);
    }
    list(query = {}, options) {
        return this._client.getAPIList('/meters', (pagination_1.DefaultPageNumberPagination), { query, ...options });
    }
    archive(id, options) {
        return this._client.delete((0, path_1.path) `/meters/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    unarchive(id, options) {
        return this._client.post((0, path_1.path) `/meters/${id}/unarchive`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Meters = Meters;
//# sourceMappingURL=meters.js.map
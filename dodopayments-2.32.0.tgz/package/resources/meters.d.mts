import { APIResource } from "../core/resource.mjs";
import * as MetersAPI from "./meters.mjs";
import { APIPromise } from "../core/api-promise.mjs";
import { DefaultPageNumberPagination, type DefaultPageNumberPaginationParams, PagePromise } from "../core/pagination.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
export declare class Meters extends APIResource {
    create(body: MeterCreateParams, options?: RequestOptions): APIPromise<Meter>;
    retrieve(id: string, options?: RequestOptions): APIPromise<Meter>;
    list(query?: MeterListParams | null | undefined, options?: RequestOptions): PagePromise<MetersDefaultPageNumberPagination, Meter>;
    archive(id: string, options?: RequestOptions): APIPromise<void>;
    unarchive(id: string, options?: RequestOptions): APIPromise<void>;
}
export type MetersDefaultPageNumberPagination = DefaultPageNumberPagination<Meter>;
export type Conjunction = 'and' | 'or';
export type FilterOperator = 'equals' | 'not_equals' | 'greater_than' | 'greater_than_or_equals' | 'less_than' | 'less_than_or_equals' | 'contains' | 'does_not_contain';
/**
 * Filter clauses — either a flat list of `MeterFilterCondition`s or a list of
 * nested `MeterFilter`s. Up to 3 levels of nesting are accepted; the limit is
 * enforced at runtime.
 */
export type FilterType = Array<FilterType.MeterFilterConditionList> | Array<MeterFilter>;
export declare namespace FilterType {
    interface MeterFilterConditionList {
        /**
         * Filter key to apply
         */
        key: string;
        /**
         * Filter operator
         */
        operator: MetersAPI.FilterOperator;
        /**
         * Filter value - can be string, number, or boolean
         */
        value: string | number | boolean;
    }
}
export interface Meter {
    id: string;
    aggregation: MeterAggregation;
    business_id: string;
    created_at: string;
    event_name: string;
    measurement_unit: string;
    name: string;
    updated_at: string;
    description?: string | null;
    /**
     * A filter structure that combines multiple conditions with logical conjunctions
     * (AND/OR).
     *
     * Supports up to 3 levels of nesting to create complex filter expressions. Each
     * filter has a conjunction (and/or) and clauses that can be either direct
     * conditions or nested filters.
     */
    filter?: MeterFilter | null;
}
export interface MeterAggregation {
    /**
     * Aggregation type for the meter
     */
    type: 'count' | 'sum' | 'max' | 'last';
    /**
     * Required when type is not COUNT
     */
    key?: string | null;
}
/**
 * A filter structure that combines multiple conditions with logical conjunctions
 * (AND/OR).
 *
 * Supports up to 3 levels of nesting to create complex filter expressions. Each
 * filter has a conjunction (and/or) and clauses that can be either direct
 * conditions or nested filters.
 */
export interface MeterFilter {
    /**
     * Filter clauses - can be direct conditions or nested filters (up to 3 levels
     * deep)
     */
    clauses: FilterType;
    /**
     * Logical conjunction to apply between clauses (and/or)
     */
    conjunction: Conjunction;
}
export interface MeterCreateParams {
    /**
     * Aggregation configuration for the meter
     */
    aggregation: MeterAggregation;
    /**
     * Event name to track
     */
    event_name: string;
    /**
     * measurement unit
     */
    measurement_unit: string;
    /**
     * Name of the meter
     */
    name: string;
    /**
     * Optional description of the meter
     */
    description?: string | null;
    /**
     * Optional filter to apply to the meter
     */
    filter?: MeterFilter | null;
}
export interface MeterListParams extends DefaultPageNumberPaginationParams {
    /**
     * List archived meters
     */
    archived?: boolean;
}
export declare namespace Meters {
    export { type Conjunction as Conjunction, type FilterOperator as FilterOperator, type FilterType as FilterType, type Meter as Meter, type MeterAggregation as MeterAggregation, type MeterFilter as MeterFilter, type MetersDefaultPageNumberPagination as MetersDefaultPageNumberPagination, type MeterCreateParams as MeterCreateParams, type MeterListParams as MeterListParams, };
}
//# sourceMappingURL=meters.d.mts.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Disputes = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const path_1 = require("../internal/utils/path.js");
class Disputes extends resource_1.APIResource {
    retrieve(disputeID, options) {
        return this._client.get((0, path_1.path) `/disputes/${disputeID}`, options);
    }
    list(query = {}, options) {
        return this._client.getAPIList('/disputes', (pagination_1.DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
}
exports.Disputes = Disputes;
//# sourceMappingURL=disputes.js.map
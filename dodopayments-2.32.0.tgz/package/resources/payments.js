"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Payments = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const path_1 = require("../internal/utils/path.js");
class Payments extends resource_1.APIResource {
    /**
     * @deprecated
     */
    create(body, options) {
        return this._client.post('/payments', { body, ...options });
    }
    retrieve(paymentID, options) {
        return this._client.get((0, path_1.path) `/payments/${paymentID}`, options);
    }
    list(query = {}, options) {
        return this._client.getAPIList('/payments', (pagination_1.DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    retrieveLineItems(paymentID, options) {
        return this._client.get((0, path_1.path) `/payments/${paymentID}/line-items`, options);
    }
}
exports.Payments = Payments;
//# sourceMappingURL=payments.js.map
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../core/pagination.mjs";
export class Balances extends APIResource {
    retrieveLedger(query = {}, options) {
        return this._client.getAPIList('/balances/ledger', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
}
//# sourceMappingURL=balances.mjs.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Discounts = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class Discounts extends resource_1.APIResource {
    /**
     * POST /discounts If `code` is omitted or empty, a random 16-char uppercase code
     * is generated.
     */
    create(body, options) {
        return this._client.post('/discounts', { body, ...options });
    }
    /**
     * GET /discounts/{discount_id}
     */
    retrieve(discountID, options) {
        return this._client.get((0, path_1.path) `/discounts/${discountID}`, options);
    }
    /**
     * PATCH /discounts/{discount_id}
     */
    update(discountID, body, options) {
        return this._client.patch((0, path_1.path) `/discounts/${discountID}`, { body, ...options });
    }
    /**
     * GET /discounts
     */
    list(query = {}, options) {
        return this._client.getAPIList('/discounts', (pagination_1.DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    /**
     * DELETE /discounts/{discount_id}
     */
    delete(discountID, options) {
        return this._client.delete((0, path_1.path) `/discounts/${discountID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Validate and fetch a discount by its code name (e.g., "SAVE20"). This allows
     * real-time validation directly against the API using the human-readable discount
     * code instead of requiring the internal discount_id.
     */
    retrieveByCode(code, options) {
        return this._client.get((0, path_1.path) `/discounts/code/${code}`, options);
    }
}
exports.Discounts = Discounts;
//# sourceMappingURL=discounts.js.map
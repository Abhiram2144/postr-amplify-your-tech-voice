// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../core/pagination.mjs";
import { path } from "../internal/utils/path.mjs";
export class Addons extends APIResource {
    create(body, options) {
        return this._client.post('/addons', { body, ...options });
    }
    retrieve(id, options) {
        return this._client.get(path `/addons/${id}`, options);
    }
    update(id, body, options) {
        return this._client.patch(path `/addons/${id}`, { body, ...options });
    }
    list(query = {}, options) {
        return this._client.getAPIList('/addons', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    updateImages(id, options) {
        return this._client.put(path `/addons/${id}/images`, options);
    }
}
//# sourceMappingURL=addons.mjs.map
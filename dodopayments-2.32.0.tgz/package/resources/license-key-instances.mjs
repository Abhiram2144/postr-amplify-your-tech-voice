// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../core/pagination.mjs";
import { path } from "../internal/utils/path.mjs";
export class LicenseKeyInstances extends APIResource {
    /**
     * @example
     * ```ts
     * const licenseKeyInstance =
     *   await client.licenseKeyInstances.retrieve('lki_123');
     * ```
     */
    retrieve(id, options) {
        return this._client.get(path `/license_key_instances/${id}`, options);
    }
    /**
     * @example
     * ```ts
     * const licenseKeyInstance =
     *   await client.licenseKeyInstances.update('lki_123', {
     *     name: 'name',
     *   });
     * ```
     */
    update(id, body, options) {
        return this._client.patch(path `/license_key_instances/${id}`, { body, ...options });
    }
    /**
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const licenseKeyInstance of client.licenseKeyInstances.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
        return this._client.getAPIList('/license_key_instances', (DefaultPageNumberPagination), { query, ...options });
    }
}
//# sourceMappingURL=license-key-instances.mjs.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Headers = void 0;
const resource_1 = require("../../core/resource.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Headers extends resource_1.APIResource {
    /**
     * Get a webhook by id
     */
    retrieve(webhookID, options) {
        return this._client.get((0, path_1.path) `/webhooks/${webhookID}/headers`, options);
    }
    /**
     * Patch a webhook by id
     */
    update(webhookID, body, options) {
        return this._client.patch((0, path_1.path) `/webhooks/${webhookID}/headers`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Headers = Headers;
//# sourceMappingURL=headers.js.map
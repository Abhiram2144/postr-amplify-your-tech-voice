"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Webhooks = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const HeadersAPI = tslib_1.__importStar(require("./headers.js"));
const headers_1 = require("./headers.js");
const standardwebhooks_1 = require("standardwebhooks");
const pagination_1 = require("../../core/pagination.js");
const headers_2 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
class Webhooks extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.headers = new HeadersAPI.Headers(this._client);
    }
    /**
     * Create a new webhook
     */
    create(body, options) {
        return this._client.post('/webhooks', { body, ...options });
    }
    /**
     * Get a webhook by id
     */
    retrieve(webhookID, options) {
        return this._client.get((0, path_1.path) `/webhooks/${webhookID}`, options);
    }
    /**
     * Patch a webhook by id
     */
    update(webhookID, body, options) {
        return this._client.patch((0, path_1.path) `/webhooks/${webhookID}`, { body, ...options });
    }
    /**
     * List all webhooks
     */
    list(query = {}, options) {
        return this._client.getAPIList('/webhooks', (pagination_1.CursorPagePagination), { query, ...options });
    }
    /**
     * Delete a webhook by id
     */
    delete(webhookID, options) {
        return this._client.delete((0, path_1.path) `/webhooks/${webhookID}`, {
            ...options,
            headers: (0, headers_2.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Get webhook secret by id
     */
    retrieveSecret(webhookID, options) {
        return this._client.get((0, path_1.path) `/webhooks/${webhookID}/secret`, options);
    }
    unsafeUnwrap(body) {
        return JSON.parse(body);
    }
    unwrap(body, { headers, key }) {
        if (headers !== undefined) {
            const keyStr = key === undefined ? this._client.webhookKey : key;
            if (keyStr === null)
                throw new Error('Webhook key must not be null in order to unwrap');
            const wh = new standardwebhooks_1.Webhook(keyStr);
            wh.verify(body, headers);
        }
        return JSON.parse(body);
    }
}
exports.Webhooks = Webhooks;
Webhooks.Headers = headers_1.Headers;
//# sourceMappingURL=webhooks.js.map
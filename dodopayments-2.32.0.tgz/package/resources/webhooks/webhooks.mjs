// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as HeadersAPI from "./headers.mjs";
import { Headers } from "./headers.mjs";
import { Webhook } from 'standardwebhooks';
import { CursorPagePagination } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Webhooks extends APIResource {
    constructor() {
        super(...arguments);
        this.headers = new HeadersAPI.Headers(this._client);
    }
    /**
     * Create a new webhook
     */
    create(body, options) {
        return this._client.post('/webhooks', { body, ...options });
    }
    /**
     * Get a webhook by id
     */
    retrieve(webhookID, options) {
        return this._client.get(path `/webhooks/${webhookID}`, options);
    }
    /**
     * Patch a webhook by id
     */
    update(webhookID, body, options) {
        return this._client.patch(path `/webhooks/${webhookID}`, { body, ...options });
    }
    /**
     * List all webhooks
     */
    list(query = {}, options) {
        return this._client.getAPIList('/webhooks', (CursorPagePagination), { query, ...options });
    }
    /**
     * Delete a webhook by id
     */
    delete(webhookID, options) {
        return this._client.delete(path `/webhooks/${webhookID}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Get webhook secret by id
     */
    retrieveSecret(webhookID, options) {
        return this._client.get(path `/webhooks/${webhookID}/secret`, options);
    }
    unsafeUnwrap(body) {
        return JSON.parse(body);
    }
    unwrap(body, { headers, key }) {
        if (headers !== undefined) {
            const keyStr = key === undefined ? this._client.webhookKey : key;
            if (keyStr === null)
                throw new Error('Webhook key must not be null in order to unwrap');
            const wh = new Webhook(keyStr);
            wh.verify(body, headers);
        }
        return JSON.parse(body);
    }
}
Webhooks.Headers = Headers;
//# sourceMappingURL=webhooks.mjs.map
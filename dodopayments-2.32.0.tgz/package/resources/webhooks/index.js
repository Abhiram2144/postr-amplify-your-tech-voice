"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Webhooks = exports.Headers = void 0;
var headers_1 = require("./headers.js");
Object.defineProperty(exports, "Headers", { enumerable: true, get: function () { return headers_1.Headers; } });
var webhooks_1 = require("./webhooks.js");
Object.defineProperty(exports, "Webhooks", { enumerable: true, get: function () { return webhooks_1.Webhooks; } });
//# sourceMappingURL=index.js.map
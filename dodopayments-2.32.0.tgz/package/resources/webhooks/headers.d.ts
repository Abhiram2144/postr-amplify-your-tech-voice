import { APIResource } from "../../core/resource.js";
import { APIPromise } from "../../core/api-promise.js";
import { RequestOptions } from "../../internal/request-options.js";
export declare class Headers extends APIResource {
    /**
     * Get a webhook by id
     */
    retrieve(webhookID: string, options?: RequestOptions): APIPromise<HeaderRetrieveResponse>;
    /**
     * Patch a webhook by id
     */
    update(webhookID: string, body: HeaderUpdateParams, options?: RequestOptions): APIPromise<void>;
}
/**
 * The value of the headers is returned in the `headers` field.
 *
 * Sensitive headers that have been redacted are returned in the sensitive field.
 */
export interface HeaderRetrieveResponse {
    /**
     * List of headers configured
     */
    headers: {
        [key: string]: string;
    };
    /**
     * Sensitive headers without the value
     */
    sensitive: Array<string>;
}
export interface HeaderUpdateParams {
    /**
     * Object of header-value pair to update or add
     */
    headers: {
        [key: string]: string;
    };
}
export declare namespace Headers {
    export { type HeaderRetrieveResponse as HeaderRetrieveResponse, type HeaderUpdateParams as HeaderUpdateParams, };
}
//# sourceMappingURL=headers.d.ts.map
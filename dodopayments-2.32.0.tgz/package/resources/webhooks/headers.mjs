// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Headers extends APIResource {
    /**
     * Get a webhook by id
     */
    retrieve(webhookID, options) {
        return this._client.get(path `/webhooks/${webhookID}/headers`, options);
    }
    /**
     * Patch a webhook by id
     */
    update(webhookID, body, options) {
        return this._client.patch(path `/webhooks/${webhookID}/headers`, {
            body,
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=headers.mjs.map
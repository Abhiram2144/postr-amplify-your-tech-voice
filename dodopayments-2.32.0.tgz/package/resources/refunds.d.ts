import { APIResource } from "../core/resource.js";
import * as MiscAPI from "./misc.js";
import * as PaymentsAPI from "./payments.js";
import { RefundListItemsDefaultPageNumberPagination } from "./payments.js";
import { APIPromise } from "../core/api-promise.js";
import { type DefaultPageNumberPaginationParams, PagePromise } from "../core/pagination.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Refunds extends APIResource {
    create(body: RefundCreateParams, options?: RequestOptions): APIPromise<Refund>;
    retrieve(refundID: string, options?: RequestOptions): APIPromise<Refund>;
    list(query?: RefundListParams | null | undefined, options?: RequestOptions): PagePromise<RefundListItemsDefaultPageNumberPagination, PaymentsAPI.RefundListItem>;
}
export interface Refund {
    /**
     * The unique identifier of the business issuing the refund.
     */
    business_id: string;
    /**
     * The timestamp of when the refund was created in UTC.
     */
    created_at: string;
    /**
     * Details about the customer for this refund (from the associated payment)
     */
    customer: PaymentsAPI.CustomerLimitedDetails;
    /**
     * If true the refund is a partial refund
     */
    is_partial: boolean;
    /**
     * Additional metadata stored with the refund.
     */
    metadata: {
        [key: string]: string;
    };
    /**
     * The unique identifier of the payment associated with the refund.
     */
    payment_id: string;
    /**
     * The unique identifier of the refund.
     */
    refund_id: string;
    /**
     * The current status of the refund.
     */
    status: RefundStatus;
    /**
     * The refunded amount.
     */
    amount?: number | null;
    /**
     * The currency of the refund, represented as an ISO 4217 currency code.
     */
    currency?: MiscAPI.Currency | null;
    /**
     * The reason provided for the refund, if any. Optional.
     */
    reason?: string | null;
}
export type RefundStatus = 'succeeded' | 'failed' | 'pending' | 'review';
export interface RefundCreateParams {
    /**
     * The unique identifier of the payment to be refunded.
     */
    payment_id: string;
    /**
     * Partially Refund an Individual Item
     */
    items?: Array<RefundCreateParams.Item> | null;
    /**
     * Additional metadata associated with the refund.
     */
    metadata?: {
        [key: string]: string;
    };
    /**
     * The reason for the refund, if any. Maximum length is 3000 characters. Optional.
     */
    reason?: string | null;
}
export declare namespace RefundCreateParams {
    interface Item {
        /**
         * The id of the item (i.e. `product_id` or `addon_id`)
         */
        item_id: string;
        /**
         * The amount to refund. if None the whole item is refunded
         */
        amount?: number | null;
        /**
         * Specify if tax is inclusive of the refund. Default true.
         */
        tax_inclusive?: boolean;
    }
}
export interface RefundListParams extends DefaultPageNumberPaginationParams {
    /**
     * Get events after this created time
     */
    created_at_gte?: string;
    /**
     * Get events created before this time
     */
    created_at_lte?: string;
    /**
     * Filter by customer_id
     */
    customer_id?: string;
    /**
     * Filter by status
     */
    status?: 'succeeded' | 'failed' | 'pending' | 'review';
    /**
     * Filter by subscription id
     */
    subscription_id?: string;
}
export declare namespace Refunds {
    export { type Refund as Refund, type RefundStatus as RefundStatus, type RefundCreateParams as RefundCreateParams, type RefundListParams as RefundListParams, };
}
export { type RefundListItemsDefaultPageNumberPagination };
//# sourceMappingURL=refunds.d.ts.map
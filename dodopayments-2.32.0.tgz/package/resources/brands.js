"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Brands = void 0;
const resource_1 = require("../core/resource.js");
const path_1 = require("../internal/utils/path.js");
class Brands extends resource_1.APIResource {
    create(body, options) {
        return this._client.post('/brands', { body, ...options });
    }
    /**
     * Thin handler just calls `get_brand` and wraps in `Json(...)`
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/brands/${id}`, options);
    }
    update(id, body, options) {
        return this._client.patch((0, path_1.path) `/brands/${id}`, { body, ...options });
    }
    list(options) {
        return this._client.get('/brands', options);
    }
    updateImages(id, options) {
        return this._client.put((0, path_1.path) `/brands/${id}/images`, options);
    }
}
exports.Brands = Brands;
//# sourceMappingURL=brands.js.map
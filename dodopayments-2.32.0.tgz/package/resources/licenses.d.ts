import { APIResource } from "../core/resource.js";
import * as PaymentsAPI from "./payments.js";
import { APIPromise } from "../core/api-promise.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Licenses extends APIResource {
    /**
     * @example
     * ```ts
     * const response = await client.licenses.activate({
     *   license_key: 'license_key',
     *   name: 'name',
     * });
     * ```
     */
    activate(body: LicenseActivateParams, options?: RequestOptions): APIPromise<LicenseActivateResponse>;
    /**
     * @example
     * ```ts
     * await client.licenses.deactivate({
     *   license_key: 'license_key',
     *   license_key_instance_id: 'license_key_instance_id',
     * });
     * ```
     */
    deactivate(body: LicenseDeactivateParams, options?: RequestOptions): APIPromise<void>;
    /**
     * @example
     * ```ts
     * const response = await client.licenses.validate({
     *   license_key: '2b1f8e2d-c41e-4e8f-b2d3-d9fd61c38f43',
     * });
     * ```
     */
    validate(body: LicenseValidateParams, options?: RequestOptions): APIPromise<LicenseValidateResponse>;
}
export interface LicenseActivateResponse {
    /**
     * License key instance ID
     */
    id: string;
    /**
     * Business ID
     */
    business_id: string;
    /**
     * Creation timestamp
     */
    created_at: string;
    /**
     * Limited customer details associated with the license key.
     */
    customer: PaymentsAPI.CustomerLimitedDetails;
    /**
     * Associated license key ID
     */
    license_key_id: string;
    /**
     * Instance name
     */
    name: string;
    /**
     * Related product info. Present if the license key is tied to a product.
     */
    product: LicenseActivateResponse.Product;
}
export declare namespace LicenseActivateResponse {
    /**
     * Related product info. Present if the license key is tied to a product.
     */
    interface Product {
        /**
         * Unique identifier for the product.
         */
        product_id: string;
        /**
         * Name of the product, if set by the merchant.
         */
        name?: string | null;
    }
}
export interface LicenseValidateResponse {
    valid: boolean;
}
export interface LicenseActivateParams {
    license_key: string;
    name: string;
}
export interface LicenseDeactivateParams {
    license_key: string;
    license_key_instance_id: string;
}
export interface LicenseValidateParams {
    license_key: string;
    license_key_instance_id?: string | null;
}
export declare namespace Licenses {
    export { type LicenseActivateResponse as LicenseActivateResponse, type LicenseValidateResponse as LicenseValidateResponse, type LicenseActivateParams as LicenseActivateParams, type LicenseDeactivateParams as LicenseDeactivateParams, type LicenseValidateParams as LicenseValidateParams, };
}
//# sourceMappingURL=licenses.d.ts.map
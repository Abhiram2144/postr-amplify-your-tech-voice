"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Licenses = void 0;
const resource_1 = require("../core/resource.js");
const headers_1 = require("../internal/headers.js");
class Licenses extends resource_1.APIResource {
    /**
     * @example
     * ```ts
     * const response = await client.licenses.activate({
     *   license_key: 'license_key',
     *   name: 'name',
     * });
     * ```
     */
    activate(body, options) {
        return this._client.post('/licenses/activate', { body, ...options });
    }
    /**
     * @example
     * ```ts
     * await client.licenses.deactivate({
     *   license_key: 'license_key',
     *   license_key_instance_id: 'license_key_instance_id',
     * });
     * ```
     */
    deactivate(body, options) {
        return this._client.post('/licenses/deactivate', {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * @example
     * ```ts
     * const response = await client.licenses.validate({
     *   license_key: '2b1f8e2d-c41e-4e8f-b2d3-d9fd61c38f43',
     * });
     * ```
     */
    validate(body, options) {
        return this._client.post('/licenses/validate', { body, ...options });
    }
}
exports.Licenses = Licenses;
//# sourceMappingURL=licenses.js.map
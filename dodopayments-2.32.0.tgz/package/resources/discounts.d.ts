import { APIResource } from "../core/resource.js";
import { APIPromise } from "../core/api-promise.js";
import { DefaultPageNumberPagination, type DefaultPageNumberPaginationParams, PagePromise } from "../core/pagination.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Discounts extends APIResource {
    /**
     * POST /discounts If `code` is omitted or empty, a random 16-char uppercase code
     * is generated.
     */
    create(body: DiscountCreateParams, options?: RequestOptions): APIPromise<Discount>;
    /**
     * GET /discounts/{discount_id}
     */
    retrieve(discountID: string, options?: RequestOptions): APIPromise<Discount>;
    /**
     * PATCH /discounts/{discount_id}
     */
    update(discountID: string, body: DiscountUpdateParams, options?: RequestOptions): APIPromise<Discount>;
    /**
     * GET /discounts
     */
    list(query?: DiscountListParams | null | undefined, options?: RequestOptions): PagePromise<DiscountsDefaultPageNumberPagination, Discount>;
    /**
     * DELETE /discounts/{discount_id}
     */
    delete(discountID: string, options?: RequestOptions): APIPromise<void>;
    /**
     * Validate and fetch a discount by its code name (e.g., "SAVE20"). This allows
     * real-time validation directly against the API using the human-readable discount
     * code instead of requiring the internal discount_id.
     */
    retrieveByCode(code: string, options?: RequestOptions): APIPromise<Discount>;
}
export type DiscountsDefaultPageNumberPagination = DefaultPageNumberPagination<Discount>;
export interface Discount {
    /**
     * The discount amount.
     *
     * - If `discount_type` is `percentage`, this is in **basis points** (e.g., 540 =>
     *   5.4%).
     * - Otherwise, this is **USD cents** (e.g., 100 => `$1.00`).
     */
    amount: number;
    /**
     * The business this discount belongs to.
     */
    business_id: string;
    /**
     * The discount code (up to 16 chars).
     */
    code: string;
    /**
     * Timestamp when the discount is created
     */
    created_at: string;
    /**
     * The unique discount ID
     */
    discount_id: string;
    metadata: {
        [key: string]: string;
    };
    /**
     * Whether this discount should be preserved when a subscription changes plans.
     * Default: false (discount is removed on plan change)
     */
    preserve_on_plan_change: boolean;
    /**
     * List of product IDs to which this discount is restricted.
     */
    restricted_to: Array<string>;
    /**
     * How many times this discount has been used.
     */
    times_used: number;
    /**
     * The type of discount, e.g. `percentage`, `flat`, or `flat_per_unit`.
     */
    type: DiscountType;
    /**
     * Optional date/time after which discount is expired.
     */
    expires_at?: string | null;
    /**
     * Name for the Discount
     */
    name?: string | null;
    /**
     * Number of subscription billing cycles this discount is valid for. If not
     * provided, the discount will be applied indefinitely to all recurring payments
     * related to the subscription.
     */
    subscription_cycles?: number | null;
    /**
     * Usage limit for this discount, if any.
     */
    usage_limit?: number | null;
}
/**
 * Response struct for a discount with its position in a stack and optional
 * cycle-tracking information (for subscriptions).
 */
export interface DiscountDetail {
    /**
     * The discount amount (basis points for percentage, USD cents for flat)
     */
    amount: number;
    /**
     * The business this discount belongs to
     */
    business_id: string;
    /**
     * The discount code
     */
    code: string;
    /**
     * Timestamp when the discount was created
     */
    created_at: string;
    /**
     * The unique discount ID
     */
    discount_id: string;
    /**
     * Additional metadata
     */
    metadata: {
        [key: string]: string;
    };
    /**
     * Position of this discount in the stack (0-based)
     */
    position: number;
    /**
     * Whether this discount should be preserved when a subscription changes plans
     */
    preserve_on_plan_change: boolean;
    /**
     * List of product IDs to which this discount is restricted
     */
    restricted_to: Array<string>;
    /**
     * How many times this discount has been used
     */
    times_used: number;
    /**
     * The type of discount
     */
    type: DiscountType;
    /**
     * Remaining billing cycles for this discount on this subscription (None for
     * one-time payments)
     */
    cycles_remaining?: number | null;
    /**
     * Optional date/time after which discount is expired
     */
    expires_at?: string | null;
    /**
     * Name for the Discount
     */
    name?: string | null;
    /**
     * Number of subscription billing cycles this discount is valid for
     */
    subscription_cycles?: number | null;
    /**
     * Usage limit for this discount, if any
     */
    usage_limit?: number | null;
}
export type DiscountType = 'percentage';
export interface DiscountCreateParams {
    /**
     * The discount amount.
     *
     * - If `discount_type` is **not** `percentage`, `amount` is in **USD cents**. For
     *   example, `100` means `$1.00`. Only USD is allowed.
     * - If `discount_type` **is** `percentage`, `amount` is in **basis points**. For
     *   example, `540` means `5.4%`.
     *
     * Must be at least 1.
     */
    amount: number;
    /**
     * The discount type (e.g. `percentage`, `flat`, or `flat_per_unit`).
     */
    type: DiscountType;
    /**
     * Optionally supply a code (will be uppercased).
     *
     * - Must be at least 3 characters if provided.
     * - If omitted, a random 16-character code is generated.
     */
    code?: string | null;
    /**
     * When the discount expires, if ever.
     */
    expires_at?: string | null;
    /**
     * Additional metadata for the discount
     */
    metadata?: {
        [key: string]: string;
    };
    name?: string | null;
    /**
     * Whether this discount should be preserved when a subscription changes plans.
     * Default: false (discount is removed on plan change)
     */
    preserve_on_plan_change?: boolean;
    /**
     * List of product IDs to restrict usage (if any).
     */
    restricted_to?: Array<string> | null;
    /**
     * Number of subscription billing cycles this discount is valid for. If not
     * provided, the discount will be applied indefinitely to all recurring payments
     * related to the subscription.
     */
    subscription_cycles?: number | null;
    /**
     * How many times this discount can be used (if any). Must be >= 1 if provided.
     */
    usage_limit?: number | null;
}
export interface DiscountUpdateParams {
    /**
     * If present, update the discount amount:
     *
     * - If `discount_type` is `percentage`, this represents **basis points** (e.g.,
     *   `540` = `5.4%`).
     * - Otherwise, this represents **USD cents** (e.g., `100` = `$1.00`).
     *
     * Must be at least 1 if provided.
     */
    amount?: number | null;
    /**
     * If present, update the discount code (uppercase).
     */
    code?: string | null;
    expires_at?: string | null;
    /**
     * Additional metadata for the discount
     */
    metadata?: {
        [key: string]: string;
    } | null;
    name?: string | null;
    /**
     * Whether this discount should be preserved when a subscription changes plans. If
     * not provided, the existing value is kept.
     */
    preserve_on_plan_change?: boolean | null;
    /**
     * If present, replaces all restricted product IDs with this new set. To remove all
     * restrictions, send empty array
     */
    restricted_to?: Array<string> | null;
    /**
     * Number of subscription billing cycles this discount is valid for. If not
     * provided, the discount will be applied indefinitely to all recurring payments
     * related to the subscription.
     */
    subscription_cycles?: number | null;
    /**
     * If present, update the discount type.
     */
    type?: DiscountType | null;
    usage_limit?: number | null;
}
export interface DiscountListParams extends DefaultPageNumberPaginationParams {
    /**
     * Filter by active status (true = not expired, false = expired)
     */
    active?: boolean;
    /**
     * Filter by discount code (partial match, case-insensitive)
     */
    code?: string;
    /**
     * Filter by discount type (percentage)
     */
    discount_type?: DiscountType;
    /**
     * Filter by product restriction (only discounts that apply to this product)
     */
    product_id?: string;
}
export declare namespace Discounts {
    export { type Discount as Discount, type DiscountDetail as DiscountDetail, type DiscountType as DiscountType, type DiscountsDefaultPageNumberPagination as DiscountsDefaultPageNumberPagination, type DiscountCreateParams as DiscountCreateParams, type DiscountUpdateParams as DiscountUpdateParams, type DiscountListParams as DiscountListParams, };
}
//# sourceMappingURL=discounts.d.ts.map
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../core/pagination.mjs";
import { path } from "../internal/utils/path.mjs";
export class Payments extends APIResource {
    /**
     * @deprecated
     */
    create(body, options) {
        return this._client.post('/payments', { body, ...options });
    }
    retrieve(paymentID, options) {
        return this._client.get(path `/payments/${paymentID}`, options);
    }
    list(query = {}, options) {
        return this._client.getAPIList('/payments', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    retrieveLineItems(paymentID, options) {
        return this._client.get(path `/payments/${paymentID}/line-items`, options);
    }
}
//# sourceMappingURL=payments.mjs.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Balances = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
class Balances extends resource_1.APIResource {
    retrieveLedger(query = {}, options) {
        return this._client.getAPIList('/balances/ledger', (pagination_1.DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
}
exports.Balances = Balances;
//# sourceMappingURL=balances.js.map
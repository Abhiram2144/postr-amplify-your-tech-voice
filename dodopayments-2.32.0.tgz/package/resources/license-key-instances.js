"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.LicenseKeyInstances = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const path_1 = require("../internal/utils/path.js");
class LicenseKeyInstances extends resource_1.APIResource {
    /**
     * @example
     * ```ts
     * const licenseKeyInstance =
     *   await client.licenseKeyInstances.retrieve('lki_123');
     * ```
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/license_key_instances/${id}`, options);
    }
    /**
     * @example
     * ```ts
     * const licenseKeyInstance =
     *   await client.licenseKeyInstances.update('lki_123', {
     *     name: 'name',
     *   });
     * ```
     */
    update(id, body, options) {
        return this._client.patch((0, path_1.path) `/license_key_instances/${id}`, { body, ...options });
    }
    /**
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const licenseKeyInstance of client.licenseKeyInstances.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
        return this._client.getAPIList('/license_key_instances', (pagination_1.DefaultPageNumberPagination), { query, ...options });
    }
}
exports.LicenseKeyInstances = LicenseKeyInstances;
//# sourceMappingURL=license-key-instances.js.map
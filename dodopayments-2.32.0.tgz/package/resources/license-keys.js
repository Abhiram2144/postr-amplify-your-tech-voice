"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.LicenseKeys = void 0;
const resource_1 = require("../core/resource.js");
const pagination_1 = require("../core/pagination.js");
const path_1 = require("../internal/utils/path.js");
class LicenseKeys extends resource_1.APIResource {
    /**
     * @example
     * ```ts
     * const licenseKey = await client.licenseKeys.create({
     *   customer_id: 'customer_id',
     *   key: 'key',
     *   product_id: 'product_id',
     * });
     * ```
     */
    create(body, options) {
        return this._client.post('/license_keys', { body, ...options });
    }
    /**
     * @deprecated
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/license_keys/${id}`, options);
    }
    /**
     * @deprecated
     */
    update(id, body, options) {
        return this._client.patch((0, path_1.path) `/license_keys/${id}`, { body, ...options });
    }
    /**
     * @deprecated
     */
    list(query = {}, options) {
        return this._client.getAPIList('/license_keys', (pagination_1.DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
}
exports.LicenseKeys = LicenseKeys;
//# sourceMappingURL=license-keys.js.map
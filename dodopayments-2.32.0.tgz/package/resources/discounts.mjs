// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../core/pagination.mjs";
import { buildHeaders } from "../internal/headers.mjs";
import { path } from "../internal/utils/path.mjs";
export class Discounts extends APIResource {
    /**
     * POST /discounts If `code` is omitted or empty, a random 16-char uppercase code
     * is generated.
     */
    create(body, options) {
        return this._client.post('/discounts', { body, ...options });
    }
    /**
     * GET /discounts/{discount_id}
     */
    retrieve(discountID, options) {
        return this._client.get(path `/discounts/${discountID}`, options);
    }
    /**
     * PATCH /discounts/{discount_id}
     */
    update(discountID, body, options) {
        return this._client.patch(path `/discounts/${discountID}`, { body, ...options });
    }
    /**
     * GET /discounts
     */
    list(query = {}, options) {
        return this._client.getAPIList('/discounts', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
    /**
     * DELETE /discounts/{discount_id}
     */
    delete(discountID, options) {
        return this._client.delete(path `/discounts/${discountID}`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
    /**
     * Validate and fetch a discount by its code name (e.g., "SAVE20"). This allows
     * real-time validation directly against the API using the human-readable discount
     * code instead of requiring the internal discount_id.
     */
    retrieveByCode(code, options) {
        return this._client.get(path `/discounts/code/${code}`, options);
    }
}
//# sourceMappingURL=discounts.mjs.map
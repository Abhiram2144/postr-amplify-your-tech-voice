import { APIResource } from "../../core/resource.mjs";
import * as MiscAPI from "../misc.mjs";
import * as BreakupAPI from "./breakup/breakup.mjs";
import { Breakup, BreakupRetrieveResponse } from "./breakup/breakup.mjs";
import { DefaultPageNumberPagination, type DefaultPageNumberPaginationParams, PagePromise } from "../../core/pagination.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Payouts extends APIResource {
    breakup: BreakupAPI.Breakup;
    list(query?: PayoutListParams | null | undefined, options?: RequestOptions): PagePromise<PayoutListResponsesDefaultPageNumberPagination, PayoutListResponse>;
}
export type PayoutListResponsesDefaultPageNumberPagination = DefaultPageNumberPagination<PayoutListResponse>;
export interface PayoutListResponse {
    /**
     * The total amount of the payout.
     */
    amount: number;
    /**
     * The unique identifier of the business associated with the payout.
     */
    business_id: string;
    /**
     * @deprecated Use the v3 payout breakup endpoints instead. Will be removed in a
     * future release.
     */
    chargebacks: number;
    /**
     * The timestamp when the payout was created, in UTC.
     */
    created_at: string;
    /**
     * The currency of the payout, represented as an ISO 4217 currency code.
     */
    currency: MiscAPI.Currency;
    /**
     * The fee charged for processing the payout.
     */
    fee: number;
    /**
     * The payment method used for the payout (e.g., bank transfer, card, etc.).
     */
    payment_method: string;
    /**
     * The unique identifier of the payout.
     */
    payout_id: string;
    /**
     * @deprecated Use the v3 payout breakup endpoints instead. Will be removed in a
     * future release.
     */
    refunds: number;
    /**
     * The current status of the payout.
     */
    status: 'not_initiated' | 'in_progress' | 'on_hold' | 'failed' | 'success';
    /**
     * @deprecated Use the v3 payout breakup endpoints instead. Will be removed in a
     * future release.
     */
    tax: number;
    /**
     * The timestamp when the payout was last updated, in UTC.
     */
    updated_at: string;
    /**
     * The name of the payout recipient or purpose.
     */
    name?: string | null;
    /**
     * The URL of the document associated with the payout.
     */
    payout_document_url?: string | null;
    /**
     * Any additional remarks or notes associated with the payout.
     */
    remarks?: string | null;
}
export interface PayoutListParams extends DefaultPageNumberPaginationParams {
    /**
     * Get payouts created after this time (inclusive)
     */
    created_at_gte?: string;
    /**
     * Get payouts created before this time (inclusive)
     */
    created_at_lte?: string;
}
export declare namespace Payouts {
    export { type PayoutListResponse as PayoutListResponse, type PayoutListResponsesDefaultPageNumberPagination as PayoutListResponsesDefaultPageNumberPagination, type PayoutListParams as PayoutListParams, };
    export { Breakup as Breakup, type BreakupRetrieveResponse as BreakupRetrieveResponse };
}
//# sourceMappingURL=payouts.d.mts.map
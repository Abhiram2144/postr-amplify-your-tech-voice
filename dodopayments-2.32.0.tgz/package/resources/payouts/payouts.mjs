// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as BreakupAPI from "./breakup/breakup.mjs";
import { Breakup } from "./breakup/breakup.mjs";
import { DefaultPageNumberPagination, } from "../../core/pagination.mjs";
export class Payouts extends APIResource {
    constructor() {
        super(...arguments);
        this.breakup = new BreakupAPI.Breakup(this._client);
    }
    list(query = {}, options) {
        return this._client.getAPIList('/payouts', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
}
Payouts.Breakup = Breakup;
//# sourceMappingURL=payouts.mjs.map
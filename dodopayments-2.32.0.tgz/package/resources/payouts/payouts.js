"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Payouts = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const BreakupAPI = tslib_1.__importStar(require("./breakup/breakup.js"));
const breakup_1 = require("./breakup/breakup.js");
const pagination_1 = require("../../core/pagination.js");
class Payouts extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.breakup = new BreakupAPI.Breakup(this._client);
    }
    list(query = {}, options) {
        return this._client.getAPIList('/payouts', (pagination_1.DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
}
exports.Payouts = Payouts;
Payouts.Breakup = breakup_1.Breakup;
//# sourceMappingURL=payouts.js.map
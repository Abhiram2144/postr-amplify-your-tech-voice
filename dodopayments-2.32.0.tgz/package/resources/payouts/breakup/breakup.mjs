// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../core/resource.mjs";
import * as DetailsAPI from "./details.mjs";
import { Details, } from "./details.mjs";
import { path } from "../../../internal/utils/path.mjs";
export class Breakup extends APIResource {
    constructor() {
        super(...arguments);
        this.details = new DetailsAPI.Details(this._client);
    }
    /**
     * Returns the breakdown of a payout by event type (payments, refunds, disputes,
     * fees, etc.) in the payout's currency. Each amount is proportionally allocated
     * based on USD equivalent values, ensuring the total sums exactly to the payout
     * amount.
     */
    retrieve(payoutID, options) {
        return this._client.get(path `/payouts/${payoutID}/breakup`, options);
    }
}
Breakup.Details = Details;
//# sourceMappingURL=breakup.mjs.map
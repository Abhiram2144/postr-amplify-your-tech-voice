// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../../../core/pagination.mjs";
import { buildHeaders } from "../../../internal/headers.mjs";
import { path } from "../../../internal/utils/path.mjs";
export class Details extends APIResource {
    /**
     * Returns paginated individual balance ledger entries for a payout, with each
     * entry's amount pro-rated into the payout's currency. Supports pagination via
     * `page_size` (default 10, max 100) and `page_number` (default 0) query
     * parameters.
     */
    list(payoutID, query = {}, options) {
        return this._client.getAPIList(path `/payouts/${payoutID}/breakup/details`, (DefaultPageNumberPagination), { query, ...options });
    }
    /**
     * Downloads the complete payout breakup as a CSV file. Each row represents a
     * balance ledger entry with columns: Ledger ID, Event Type, Original Amount,
     * Original Currency, Reference Object ID, Description, Created At, USD Equivalent
     * Amount, and Payout Currency Amount.
     */
    downloadCsv(payoutID, options) {
        return this._client.get(path `/payouts/${payoutID}/breakup/details/csv`, {
            ...options,
            headers: buildHeaders([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
//# sourceMappingURL=details.mjs.map
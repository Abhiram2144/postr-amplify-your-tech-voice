"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Details = exports.Breakup = void 0;
var breakup_1 = require("./breakup.js");
Object.defineProperty(exports, "Breakup", { enumerable: true, get: function () { return breakup_1.Breakup; } });
var details_1 = require("./details.js");
Object.defineProperty(exports, "Details", { enumerable: true, get: function () { return details_1.Details; } });
//# sourceMappingURL=index.js.map
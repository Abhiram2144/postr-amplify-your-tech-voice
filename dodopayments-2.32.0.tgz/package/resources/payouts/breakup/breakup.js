"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Breakup = void 0;
const tslib_1 = require("../../../internal/tslib.js");
const resource_1 = require("../../../core/resource.js");
const DetailsAPI = tslib_1.__importStar(require("./details.js"));
const details_1 = require("./details.js");
const path_1 = require("../../../internal/utils/path.js");
class Breakup extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.details = new DetailsAPI.Details(this._client);
    }
    /**
     * Returns the breakdown of a payout by event type (payments, refunds, disputes,
     * fees, etc.) in the payout's currency. Each amount is proportionally allocated
     * based on USD equivalent values, ensuring the total sums exactly to the payout
     * amount.
     */
    retrieve(payoutID, options) {
        return this._client.get((0, path_1.path) `/payouts/${payoutID}/breakup`, options);
    }
}
exports.Breakup = Breakup;
Breakup.Details = details_1.Details;
//# sourceMappingURL=breakup.js.map
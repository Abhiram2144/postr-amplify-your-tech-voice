import { APIResource } from "../../../core/resource.mjs";
import * as DetailsAPI from "./details.mjs";
import { DetailListParams, DetailListResponse, DetailListResponsesDefaultPageNumberPagination, Details } from "./details.mjs";
import { APIPromise } from "../../../core/api-promise.mjs";
import { RequestOptions } from "../../../internal/request-options.mjs";
export declare class Breakup extends APIResource {
    details: DetailsAPI.Details;
    /**
     * Returns the breakdown of a payout by event type (payments, refunds, disputes,
     * fees, etc.) in the payout's currency. Each amount is proportionally allocated
     * based on USD equivalent values, ensuring the total sums exactly to the payout
     * amount.
     */
    retrieve(payoutID: string, options?: RequestOptions): APIPromise<BreakupRetrieveResponse>;
}
export type BreakupRetrieveResponse = Array<BreakupRetrieveResponse.BreakupRetrieveResponseItem>;
export declare namespace BreakupRetrieveResponse {
    /**
     * Payout breakup aggregated by event type, with amounts in the payout's currency.
     */
    interface BreakupRetrieveResponseItem {
        /**
         * The type of balance ledger event (e.g., "payment", "refund", "dispute",
         * "payment_fees").
         */
        event_type: string;
        /**
         * Total amount for this event type in the payout's currency (in smallest currency
         * unit, e.g., cents).
         */
        total: number;
    }
}
export declare namespace Breakup {
    export { type BreakupRetrieveResponse as BreakupRetrieveResponse };
    export { Details as Details, type DetailListResponse as DetailListResponse, type DetailListResponsesDefaultPageNumberPagination as DetailListResponsesDefaultPageNumberPagination, type DetailListParams as DetailListParams, };
}
//# sourceMappingURL=breakup.d.mts.map
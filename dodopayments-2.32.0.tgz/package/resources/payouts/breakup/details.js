"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Details = void 0;
const resource_1 = require("../../../core/resource.js");
const pagination_1 = require("../../../core/pagination.js");
const headers_1 = require("../../../internal/headers.js");
const path_1 = require("../../../internal/utils/path.js");
class Details extends resource_1.APIResource {
    /**
     * Returns paginated individual balance ledger entries for a payout, with each
     * entry's amount pro-rated into the payout's currency. Supports pagination via
     * `page_size` (default 10, max 100) and `page_number` (default 0) query
     * parameters.
     */
    list(payoutID, query = {}, options) {
        return this._client.getAPIList((0, path_1.path) `/payouts/${payoutID}/breakup/details`, (pagination_1.DefaultPageNumberPagination), { query, ...options });
    }
    /**
     * Downloads the complete payout breakup as a CSV file. Each row represents a
     * balance ledger entry with columns: Ledger ID, Event Type, Original Amount,
     * Original Currency, Reference Object ID, Description, Created At, USD Equivalent
     * Amount, and Payout Currency Amount.
     */
    downloadCsv(payoutID, options) {
        return this._client.get((0, path_1.path) `/payouts/${payoutID}/breakup/details/csv`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Details = Details;
//# sourceMappingURL=details.js.map
"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Payouts = exports.Breakup = void 0;
var index_1 = require("./breakup/index.js");
Object.defineProperty(exports, "Breakup", { enumerable: true, get: function () { return index_1.Breakup; } });
var payouts_1 = require("./payouts.js");
Object.defineProperty(exports, "Payouts", { enumerable: true, get: function () { return payouts_1.Payouts; } });
//# sourceMappingURL=index.js.map
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { DefaultPageNumberPagination, } from "../core/pagination.mjs";
import { path } from "../internal/utils/path.mjs";
export class Refunds extends APIResource {
    create(body, options) {
        return this._client.post('/refunds', { body, ...options });
    }
    retrieve(refundID, options) {
        return this._client.get(path `/refunds/${refundID}`, options);
    }
    list(query = {}, options) {
        return this._client.getAPIList('/refunds', (DefaultPageNumberPagination), {
            query,
            ...options,
        });
    }
}
//# sourceMappingURL=refunds.mjs.map
# Changelog

## 2.32.0 (2026-05-21)

Full Changelog: [v2.31.2...v2.32.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.31.2...v2.32.0)

### Features

* **api:** fixed a breaking modal change ([2ebadfd](https://github.com/dodopayments/dodopayments-typescript/commit/2ebadfd83adf32d8d27793242ddcc0c11472c30c))
* **api:** stainless fixes ([de22d45](https://github.com/dodopayments/dodopayments-typescript/commit/de22d45d43fcd8111f7df9f9e32dcc41aee49799))
* **api:** updated openapi spec to v1.99.0 and added missing endpoints as well ([355bcff](https://github.com/dodopayments/dodopayments-typescript/commit/355bcff595128ea31846c905ca88c120e0f80d6c))


### Bug Fixes

* **typescript:** upgrade tsc-multi so that it works with Node 26 ([a8a2dbe](https://github.com/dodopayments/dodopayments-typescript/commit/a8a2dbeed8f84ad36f4b88b8ff96220502a98b15))


### Chores

* **tests:** remove redundant File import ([3713e1b](https://github.com/dodopayments/dodopayments-typescript/commit/3713e1b86140cc3a495c9d9b09f2e6c7cffe01e5))

## 2.31.2 (2026-05-14)

Full Changelog: [v2.31.1...v2.31.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.31.1...v2.31.2)

### Features

* **api:** updated openapi spec to 1.98.0 ([55eabba](https://github.com/dodopayments/dodopayments-typescript/commit/55eabbae87b4d98b8b0d2f9999e7054041383a50))
* **api:** updated openapi spec to v1.97.10 ([c667602](https://github.com/dodopayments/dodopayments-typescript/commit/c6676029193705993fa77e02e2ed15d9a2810124))


### Chores

* redact api-key headers in debug logs ([89f010e](https://github.com/dodopayments/dodopayments-typescript/commit/89f010e0b179a7c88489939178fadbb67e3007d1))

## 2.31.1 (2026-05-07)

Full Changelog: [v2.31.0...v2.31.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.31.0...v2.31.1)

### Chores

* **internal:** fix MCP cloudflare worker initialization ([a26ff9c](https://github.com/dodopayments/dodopayments-typescript/commit/a26ff9cdca004d4a5e0403a9c03ce875b4030281))


### Documentation

* clarify forwards compat behavior ([4759387](https://github.com/dodopayments/dodopayments-typescript/commit/47593879315b1f184c85f2c324e72be70dde5eba))
* update logging docs ([e1f5a3c](https://github.com/dodopayments/dodopayments-typescript/commit/e1f5a3c05b72c36def6eb057c832e575cfd0f98e))
* update with proxy auth info ([2742050](https://github.com/dodopayments/dodopayments-typescript/commit/2742050f3a272ac12dcf85f2367918517e3bd95b))

## 2.31.0 (2026-05-04)

Full Changelog: [v2.30.0...v2.31.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.30.0...v2.31.0)

### Features

* **api:** update openapi spec ([2e9e91f](https://github.com/dodopayments/dodopayments-typescript/commit/2e9e91ff97cb54d1652ef5735723c275e28fa967))


### Chores

* **internal:** fix MCP cloudflare worker builds ([7557c65](https://github.com/dodopayments/dodopayments-typescript/commit/7557c656d3648b44a3d675bde9e5b216324c4653))

## 2.30.0 (2026-04-30)

Full Changelog: [v2.29.1...v2.30.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.29.1...v2.30.0)

### Features

* **api:** added more models to make the dx easy ([eac71ff](https://github.com/dodopayments/dodopayments-typescript/commit/eac71ffba93609b6e460a13a63f3e18b8430f791))
* **api:** updated openapi spec to v1.97.5 ([3c4e7a5](https://github.com/dodopayments/dodopayments-typescript/commit/3c4e7a5dd4a2e6982205bc4e8d0cd6f0c2678a24))


### Chores

* avoid formatting file that gets changed during releases ([16c9e78](https://github.com/dodopayments/dodopayments-typescript/commit/16c9e789fa594a3e5f945b609c1512505f3be59e))
* **format:** run eslint and prettier separately ([0d82378](https://github.com/dodopayments/dodopayments-typescript/commit/0d823786e1f3620ce8ff42416805fd679f9bdf51))

## 2.29.1 (2026-04-29)

Full Changelog: [v2.29.0...v2.29.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.29.0...v2.29.1)

### Chores

* **internal:** codegen related update ([f83448a](https://github.com/dodopayments/dodopayments-typescript/commit/f83448a70aaafd8d10bd05ed1d741b41a13d1789))

## 2.29.0 (2026-04-28)

Full Changelog: [v2.28.2...v2.29.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.28.2...v2.29.0)

### Features

* support setting headers via env ([5f12398](https://github.com/dodopayments/dodopayments-typescript/commit/5f123981cf972c2496148f29d6ee1ca7a2ca5874))


### Chores

* **formatter:** run prettier and eslint separately ([1ecbd38](https://github.com/dodopayments/dodopayments-typescript/commit/1ecbd38765222d49cb4de3e318170357115a15bb))
* **internal:** codegen related update ([189f28c](https://github.com/dodopayments/dodopayments-typescript/commit/189f28c960e0167df02f6a10fd4f6f169083a037))
* **internal:** more robust bootstrap script ([341f2cf](https://github.com/dodopayments/dodopayments-typescript/commit/341f2cf48b97959b295728ca418826d801ef7875))
* **internal:** update docs ordering ([e7282c8](https://github.com/dodopayments/dodopayments-typescript/commit/e7282c89e264caafb4da6ddefb8a9091fc82a0f5))
* restructure docs search code ([b8a1b49](https://github.com/dodopayments/dodopayments-typescript/commit/b8a1b493df0f1549c69564c731ae69cb27b37f6c))

## 2.28.2 (2026-04-18)

Full Changelog: [v2.28.1...v2.28.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.28.1...v2.28.2)

### Chores

* **tests:** bump steady to v0.22.1 ([830b260](https://github.com/dodopayments/dodopayments-typescript/commit/830b260011f2e9559334137e54adee15a47c44d2))

## 2.28.1 (2026-04-17)

Full Changelog: [v2.28.0...v2.28.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.28.0...v2.28.1)

### Bug Fixes

* **mcp-server:** resolve agents peer dep conflict by upgrading zod to v4 and adding .npmrc ([37a3535](https://github.com/dodopayments/dodopayments-typescript/commit/37a3535e4c9f184a470a62474eaef9b12d88e167))


### Chores

* **mcp-server:** add Dodo Payments favicon to Cloudflare worker ([442a5ee](https://github.com/dodopayments/dodopayments-typescript/commit/442a5ee51375b1dc51fb82d59e455040eb9a2db4))

## 2.28.0 (2026-04-14)

Full Changelog: [v2.27.0...v2.28.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.27.0...v2.28.0)

### Features

* **api:** update openapi spec to v1.95.3 ([d48e9c9](https://github.com/dodopayments/dodopayments-typescript/commit/d48e9c9135cdf88a293c93f5f1fae4e4e1b5244c))


### Chores

* **internal:** codegen related update ([99d85e7](https://github.com/dodopayments/dodopayments-typescript/commit/99d85e72a1b70532e60cdfc10ea2ff4e51b76eb7))
* **internal:** codegen related update ([cd0dd6c](https://github.com/dodopayments/dodopayments-typescript/commit/cd0dd6c48d112e4e408894f5a490bd9c135f0819))
* **internal:** show error causes in MCP servers when running in local mode ([bd4186a](https://github.com/dodopayments/dodopayments-typescript/commit/bd4186a46f9efa536a6bf4c363679598003c23b6))
* **mcp-server:** increase local docs search result count from 5 to 10 ([888da66](https://github.com/dodopayments/dodopayments-typescript/commit/888da668c7e641676595b2460140a50d6e1edc89))
* update CLI documentation ([fb5d2e2](https://github.com/dodopayments/dodopayments-typescript/commit/fb5d2e2f392e5396733d6252d897bb8a21021c11))

## 2.27.0 (2026-04-08)

Full Changelog: [v2.26.0...v2.27.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.26.0...v2.27.0)

### Features

* **api:** updated openapi spec to v1.94.2 ([b93c830](https://github.com/dodopayments/dodopayments-typescript/commit/b93c8300537530edb0a06bc4a0059d5057d4d222))


### Chores

* **internal:** codegen related update ([143b18d](https://github.com/dodopayments/dodopayments-typescript/commit/143b18d4f7d18533d4e6529d9ef121a95a7f050c))
* **internal:** fix MCP docker image builds in yarn projects ([2c66aea](https://github.com/dodopayments/dodopayments-typescript/commit/2c66aeae8f6a5eae2f787ae74c6bb9200190c349))
* **internal:** fix MCP server import ordering ([681f60c](https://github.com/dodopayments/dodopayments-typescript/commit/681f60c828eba6f4d0d6532fd8747ec1f8e5a556))
* **internal:** support type annotations when running MCP in local execution mode ([fefc74e](https://github.com/dodopayments/dodopayments-typescript/commit/fefc74e84ee81330402b6305483106956453deb8))
* **internal:** use link instead of file in MCP server package.json files ([85c7dd8](https://github.com/dodopayments/dodopayments-typescript/commit/85c7dd8c38c8ee9a818bf873160c746675461bc0))
* **mcp-server:** log client info ([cea2fe4](https://github.com/dodopayments/dodopayments-typescript/commit/cea2fe41ef55920229c466a01740d536a24ef97f))

## 2.26.0 (2026-04-01)

Full Changelog: [v2.25.1...v2.26.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.25.1...v2.26.0)

### Features

* **api:** updated openapi spec to v1.93.0 ([bbf86ae](https://github.com/dodopayments/dodopayments-typescript/commit/bbf86ae841233feee2e40cd9c9d724ebcf9d63ee))


### Chores

* **ci:** escape input path in publish-npm workflow ([0c3c637](https://github.com/dodopayments/dodopayments-typescript/commit/0c3c637424107ab345ce0c02e923561bcba99d16))
* **internal:** improve local docs search for MCP servers ([8f3310a](https://github.com/dodopayments/dodopayments-typescript/commit/8f3310ad527cc34dbd1496f584c69d7f5be9e906))
* **internal:** improve local docs search for MCP servers ([f7816c8](https://github.com/dodopayments/dodopayments-typescript/commit/f7816c822df4f84c7d5af27392c51867a75c842c))
* **internal:** support local docs search in MCP servers ([cfdb5ae](https://github.com/dodopayments/dodopayments-typescript/commit/cfdb5ae93cf1582c0a2cd63f39c1e34de6ed7f4d))
* **mcp-server:** add support for session id, forward client info ([2798002](https://github.com/dodopayments/dodopayments-typescript/commit/2798002ff2b12e7f0c2bb0f4d186323beb9499b6))
* **tests:** bump steady to v0.20.1 ([b122aeb](https://github.com/dodopayments/dodopayments-typescript/commit/b122aeb04c962b773588ddf5e27568a3a13a99e5))
* **tests:** bump steady to v0.20.2 ([edadf5f](https://github.com/dodopayments/dodopayments-typescript/commit/edadf5f0bc680b65e4edb8c9576d893dbbbe4bfa))

## 2.25.1 (2026-03-27)

Full Changelog: [v2.25.0...v2.25.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.25.0...v2.25.1)

### Bug Fixes

* **mcp:** bump agents version in cloudflare worker MCP servers ([075d888](https://github.com/dodopayments/dodopayments-typescript/commit/075d88892ecba12863c3bd49b620b6aa4560a774))


### Chores

* **internal:** support custom-instructions-path flag in MCP servers ([424ca7c](https://github.com/dodopayments/dodopayments-typescript/commit/424ca7cb1816961633b6347f1373ab6dbc0593f8))
* **internal:** update multipart form array serialization ([1caf3e6](https://github.com/dodopayments/dodopayments-typescript/commit/1caf3e62961f303fb91f39c1c25b846bdb11a7a2))

## 2.25.0 (2026-03-25)

Full Changelog: [v2.24.0...v2.25.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.24.0...v2.25.0)

### Features

* **api:** manual updates ([1077f85](https://github.com/dodopayments/dodopayments-typescript/commit/1077f85035ffac6432331017267d90a7d42e1b3a))
* **api:** updated openapi spec to v1.92.3 ([12a6d53](https://github.com/dodopayments/dodopayments-typescript/commit/12a6d53ca4c78ae399e2400b0a84956ecccf2918))

## 2.24.0 (2026-03-25)

Full Changelog: [v2.23.3...v2.24.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.23.3...v2.24.0)

### Features

* **api:** added cancel change plan endpoint ([e8115f2](https://github.com/dodopayments/dodopayments-typescript/commit/e8115f2510533b8182319cfa376660bf988e5c97))
* **api:** updated openapi spec to 1.92.1 ([4e9d416](https://github.com/dodopayments/dodopayments-typescript/commit/4e9d41612b0bc80bd6061421c1450e477d353519))


### Chores

* **ci:** skip lint on metadata-only changes ([1ae7d95](https://github.com/dodopayments/dodopayments-typescript/commit/1ae7d95d720da0f866eff3a5e3d7f72047842b98))
* **internal:** fix MCP server TS errors that occur with required client options ([68bacef](https://github.com/dodopayments/dodopayments-typescript/commit/68bacefb5f86f4e3b680fdab912306456b323d8e))
* **internal:** update gitignore ([8b9d6e8](https://github.com/dodopayments/dodopayments-typescript/commit/8b9d6e83e1cd66d03dcba84e98343ac9d89d7e35))
* **tests:** bump steady to v0.19.6 ([266ad2e](https://github.com/dodopayments/dodopayments-typescript/commit/266ad2e5bba3e02a8b1111be5382a4c35c1e818a))
* **tests:** bump steady to v0.19.7 ([35effd0](https://github.com/dodopayments/dodopayments-typescript/commit/35effd07569bcb80ea97da669af7fa266e66314c))

## 2.23.3 (2026-03-21)

Full Changelog: [v2.23.2...v2.23.3](https://github.com/dodopayments/dodopayments-typescript/compare/v2.23.2...v2.23.3)

### Bug Fixes

* **client:** preserve URL params already embedded in path ([470059b](https://github.com/dodopayments/dodopayments-typescript/commit/470059b31d6e0204861dab46ebe58ebec0aadc45))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([cd1fbdd](https://github.com/dodopayments/dodopayments-typescript/commit/cd1fbdda039c28a930b6a9c5c233a0b933093de1))
* **internal:** bump @modelcontextprotocol/sdk, @hono/node-server, and minimatch ([bdf7816](https://github.com/dodopayments/dodopayments-typescript/commit/bdf78160c4bedbd6366d94e081ec74b264ad8821))
* **internal:** make generated MCP servers compatible with Cloudflare worker environments ([c90ff84](https://github.com/dodopayments/dodopayments-typescript/commit/c90ff8482a58ef344c9096e81414ef1de115f5a1))
* **internal:** support x-stainless-mcp-client-envs header in MCP servers ([85cc625](https://github.com/dodopayments/dodopayments-typescript/commit/85cc6253a8e751aaeb2119d533e9dcf3a4157831))
* **internal:** support x-stainless-mcp-client-permissions headers in MCP servers ([ecb97a6](https://github.com/dodopayments/dodopayments-typescript/commit/ecb97a6bfd35b53ea0fbb97fa408264b57bee749))
* **internal:** tweak CI branches ([02433fc](https://github.com/dodopayments/dodopayments-typescript/commit/02433fc1f0141ef6b2371ed04bab2f809913ecfc))
* **internal:** update dependencies to address dependabot vulnerabilities ([86cf9d0](https://github.com/dodopayments/dodopayments-typescript/commit/86cf9d0fbf0c394c5cc5f33cfe2b7bcad507c2d1))
* **mcp-server:** improve instructions ([de8e2f6](https://github.com/dodopayments/dodopayments-typescript/commit/de8e2f6a00a7299d29150521726d72a1f3ed63e0))
* **tests:** bump steady to v0.19.4 ([23cd5da](https://github.com/dodopayments/dodopayments-typescript/commit/23cd5da94d0d478334b49a34c1174807b53b90b1))
* **tests:** bump steady to v0.19.5 ([ccf8652](https://github.com/dodopayments/dodopayments-typescript/commit/ccf865251e264e13cab3fe320a38536d236946e5))
* use proper capitalization for WebSockets ([221ea23](https://github.com/dodopayments/dodopayments-typescript/commit/221ea2338f2562840c95acf561d90b3c7567687b))


### Refactors

* **tests:** switch from prism to steady ([3dbc684](https://github.com/dodopayments/dodopayments-typescript/commit/3dbc6847acd5204681fedca45a33bfc3602c4642))

## 2.23.2 (2026-03-06)

Full Changelog: [v2.23.1...v2.23.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.23.1...v2.23.2)

### Chores

* **internal:** unconfigure MCP Server hosting ([d163b06](https://github.com/dodopayments/dodopayments-typescript/commit/d163b066d46c0854b13f01e9e93f235ea8d63bd5))

## 2.23.1 (2026-03-06)

Full Changelog: [v2.23.0...v2.23.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.23.0...v2.23.1)

### Chores

* **internal:** codegen related update ([5d9b9f9](https://github.com/dodopayments/dodopayments-typescript/commit/5d9b9f9889a157823a8555248bd70208a9b40458))
* **test:** do not count install time for mock server timeout ([7b75d0b](https://github.com/dodopayments/dodopayments-typescript/commit/7b75d0b9f89c7afc7983c41f95a86ed9c931f6a1))

## 2.23.0 (2026-03-05)

Full Changelog: [v2.22.6...v2.23.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.22.6...v2.23.0)

### Features

* **api:** updated openapi spec to v1.87.0 ([4c60a84](https://github.com/dodopayments/dodopayments-typescript/commit/4c60a84c36a7a54e01e4f18b6eedc13e2c6413a7))


### Chores

* **internal:** configure MCP Server hosting ([90df39a](https://github.com/dodopayments/dodopayments-typescript/commit/90df39ae802a0ead40880bfd3bafbeaca75148c8))
* **internal:** use x-stainless-mcp-client-envs header for MCP remote code tool calls ([7bfe048](https://github.com/dodopayments/dodopayments-typescript/commit/7bfe048466655b1da03ecab6d3491d13b292a068))

## 2.22.6 (2026-03-03)

Full Changelog: [v2.22.5...v2.22.6](https://github.com/dodopayments/dodopayments-typescript/compare/v2.22.5...v2.22.6)

### Bug Fixes

* also patch global setInterval in instructions module for CF Workers ([8f6d682](https://github.com/dodopayments/dodopayments-typescript/commit/8f6d68203477e064df6b97558f215f7d085998d6))
* patch code-tool-paths.cjs for Cloudflare Workers compatibility ([66d9bee](https://github.com/dodopayments/dodopayments-typescript/commit/66d9beeaeaf03f68c6a3a8d38c4db56e7df9e791))
* patch pino logger and await initMcpServer for CF Workers ([55dfa0f](https://github.com/dodopayments/dodopayments-typescript/commit/55dfa0f3c5435026cc2a30e056c5dc0397f9a281))
* prettier formatting and pin wrangler-action to commit hash ([2ac5c4c](https://github.com/dodopayments/dodopayments-typescript/commit/2ac5c4ce0569adb1a2e22146b263ed1b010b7330))
* rename dodopayments_api to dodopayments-mcp ([7aafafc](https://github.com/dodopayments/dodopayments-typescript/commit/7aafafcf27782ca262558fb3e1759de3b0dcdf10))
* resolve CodeQL TOCTOU race conditions and revert wrangler-action pin ([f5730b7](https://github.com/dodopayments/dodopayments-typescript/commit/f5730b78bcac0a2fc5bacdf77a372e1748dc6963))

## 2.22.5 (2026-03-03)

Full Changelog: [v2.22.4...v2.22.5](https://github.com/dodopayments/dodopayments-typescript/compare/v2.22.4...v2.22.5)

### Bug Fixes

* stub @valtown/deno-http-worker for Cloudflare Workers compatibility ([152a361](https://github.com/dodopayments/dodopayments-typescript/commit/152a3611b3285b50faa9b7920941ebf0c2dda3e4))


### Chores

* **internal:** configure MCP Server hosting ([c8ffe79](https://github.com/dodopayments/dodopayments-typescript/commit/c8ffe79f57efb9780bc8e8d6b6a8962fcca36841))
* **internal:** unconfigure MCP Server hosting ([cb3f5c5](https://github.com/dodopayments/dodopayments-typescript/commit/cb3f5c5074d3db0f491f27feeb292f369258a7f3))

## 2.22.4 (2026-03-03)

Full Changelog: [v2.22.3...v2.22.4](https://github.com/dodopayments/dodopayments-typescript/compare/v2.22.3...v2.22.4)

### Bug Fixes

* update cloudflare worker imports for current dodopayments-mcp API ([0fea649](https://github.com/dodopayments/dodopayments-typescript/commit/0fea649ee2c9f27fc2b72289274ed38cf9dd25f4))

## 2.22.3 (2026-03-03)

Full Changelog: [v2.22.2...v2.22.3](https://github.com/dodopayments/dodopayments-typescript/compare/v2.22.2...v2.22.3)

### Bug Fixes

* update cloudflare worker to use latest dodopayments-mcp version ([a442d45](https://github.com/dodopayments/dodopayments-typescript/commit/a442d455569b0a376227ff1a08dd40d1b2c4252a))


### Chores

* only deploy cloudflare worker on release, not every push to main ([289a3b8](https://github.com/dodopayments/dodopayments-typescript/commit/289a3b8805b77057c942985629c558b3e569e4b9))

## 2.22.2 (2026-03-03)

Full Changelog: [v2.22.1...v2.22.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.22.1...v2.22.2)

### Bug Fixes

* remove src/ from published npm package ([5d0f1bc](https://github.com/dodopayments/dodopayments-typescript/commit/5d0f1bcf313eab80bffd735d441adec30d4ce989)), closes [#177](https://github.com/dodopayments/dodopayments-typescript/issues/177)

## 2.22.1 (2026-03-03)

Full Changelog: [v2.22.0...v2.22.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.22.0...v2.22.1)

### Chores

* **internal:** codegen related update ([0093f84](https://github.com/dodopayments/dodopayments-typescript/commit/0093f84cd54a9252869b27aa4e1aab97c64d8e73))
* **mcp-server:** return access instructions for 404 without API key ([0f5cbaf](https://github.com/dodopayments/dodopayments-typescript/commit/0f5cbaf02c45339dcc8e49377eff37d7adb36d4c))
* **tests:** update webhook tests ([b929ca3](https://github.com/dodopayments/dodopayments-typescript/commit/b929ca38339a42da680a416f733ff0c346c6da3c))

## 2.22.0 (2026-03-01)

Full Changelog: [v2.21.0...v2.22.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.21.0...v2.22.0)

### Features

* **api:** added more models ([1022cee](https://github.com/dodopayments/dodopayments-typescript/commit/1022cee0c0ede09f4bf6eee2b1c2134d83fa3e3a))
* **api:** updated to openapi spec v1.86.0 ([d575930](https://github.com/dodopayments/dodopayments-typescript/commit/d575930137f95e5670084bda7dd7b259ab70f6ec))

## 2.21.0 (2026-02-27)

Full Changelog: [v2.20.0...v2.21.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.20.0...v2.21.0)

### Features

* **mcp:** add an option to disable code tool ([5a66e8b](https://github.com/dodopayments/dodopayments-typescript/commit/5a66e8b904380cc9a2233e19fcc51da2eb3303d6))


### Bug Fixes

* **docs/contributing:** correct pnpm link command ([3a8d217](https://github.com/dodopayments/dodopayments-typescript/commit/3a8d217537354e0e4c08c10e57b5aa4093ab8bbe))
* **mcp:** update prompt ([d7933ab](https://github.com/dodopayments/dodopayments-typescript/commit/d7933abde8764e7829e42560628f77120643ca9c))


### Chores

* **internal:** codegen related update ([fe8a89c](https://github.com/dodopayments/dodopayments-typescript/commit/fe8a89c40c9841bac1735faa6b692618d270a7f6))
* **internal:** fix MCP Dockerfiles so they can be built without buildkit ([00068c1](https://github.com/dodopayments/dodopayments-typescript/commit/00068c102bcef5be14e1ee4a16d40c9032ad872e))
* **internal:** fix MCP Dockerfiles so they can be built without buildkit ([b4fa32c](https://github.com/dodopayments/dodopayments-typescript/commit/b4fa32cfc1b41d4eed597b6659e986a658235937))
* **internal:** make MCP code execution location configurable via a flag ([76c9ed6](https://github.com/dodopayments/dodopayments-typescript/commit/76c9ed60830731a9caa8b1acd340b56f35c87fd2))
* **internal:** move stringifyQuery implementation to internal function ([f28b0b4](https://github.com/dodopayments/dodopayments-typescript/commit/f28b0b4bea6475a86671b61bf7585365cec06576))
* **internal:** update agents version ([fbdbce3](https://github.com/dodopayments/dodopayments-typescript/commit/fbdbce302cc1fc2e90d478d64a067a3384837661))
* **internal:** upgrade @modelcontextprotocol/sdk and hono ([f4b2d17](https://github.com/dodopayments/dodopayments-typescript/commit/f4b2d17fb47145cd7e185991cda5891114cafafe))

## 2.20.0 (2026-02-20)

Full Changelog: [v2.19.1...v2.20.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.19.1...v2.20.0)

### Features

* **api:** updated openapi spec to v1.84.0 ([1b8bd36](https://github.com/dodopayments/dodopayments-typescript/commit/1b8bd3658c157d6449a40618ea1ec35b0004dea2))


### Bug Fixes

* **mcp:** initialize SDK lazily to avoid failing the connection on init errors ([c65ce38](https://github.com/dodopayments/dodopayments-typescript/commit/c65ce38c0ee14994f7f956aacb0eddcd722cd171))


### Chores

* **internal/client:** fix form-urlencoded requests ([fd87d64](https://github.com/dodopayments/dodopayments-typescript/commit/fd87d64625100b655268d72b0e6458b7b56af735))
* **internal:** allow setting x-stainless-api-key header on mcp server requests ([55f4404](https://github.com/dodopayments/dodopayments-typescript/commit/55f44043b8302e32cd0ca39da78be7e8a84ace11))
* **internal:** cache fetch instruction calls in MCP server ([08e1d52](https://github.com/dodopayments/dodopayments-typescript/commit/08e1d5267bf2d80bf0cbce18382cf7ac25345337))
* **mcp:** correctly update version in sync with sdk ([cd9b2f6](https://github.com/dodopayments/dodopayments-typescript/commit/cd9b2f628f75cebcd958740e2abd3e2931a31647))
* update mock server docs ([7932b8b](https://github.com/dodopayments/dodopayments-typescript/commit/7932b8b47c2892a5b4aefd3d1d2322168e78a433))

## 2.19.1 (2026-02-14)

Full Changelog: [v2.19.0...v2.19.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.19.0...v2.19.1)

### Chores

* **internal:** add health check to MCP server when running in HTTP mode ([f2cc612](https://github.com/dodopayments/dodopayments-typescript/commit/f2cc61229c785e706611546a62c8aa25913b0870))
* **internal:** allow basic filtering of methods allowed for MCP code mode ([835f33e](https://github.com/dodopayments/dodopayments-typescript/commit/835f33ec229d3154012ff089b28e9ea4f85610f1))
* **internal:** always generate MCP server dockerfiles and upgrade associated dependencies ([cafee43](https://github.com/dodopayments/dodopayments-typescript/commit/cafee43698fb372c658d82a3bd25147398c8d75c))
* **internal:** avoid type checking errors with ts-reset ([9019eba](https://github.com/dodopayments/dodopayments-typescript/commit/9019eba52959e714b790d9b473dc70e9899595d1))
* **internal:** improve layout of generated MCP server files ([7956369](https://github.com/dodopayments/dodopayments-typescript/commit/7956369df794261103b52d104aa91b00ad297671))
* **internal:** upgrade hono ([7752c6a](https://github.com/dodopayments/dodopayments-typescript/commit/7752c6afd2d21dcca4a5bfe981b1d745bdb1885c))
* **mcp:** forward STAINLESS_API_KEY to docs search endpoint ([d13a251](https://github.com/dodopayments/dodopayments-typescript/commit/d13a251d937dd7be6b92a4fc2b5796c1c7ddd29e))

## 2.19.0 (2026-02-06)

Full Changelog: [v2.18.0...v2.19.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.18.0...v2.19.0)

### Features

* **api:** updated openapi spec to v1.81.0 ([d965c50](https://github.com/dodopayments/dodopayments-typescript/commit/d965c500fa882a0a0369453208a560bfa8e7a1de))
* **mcp:** add initial server instructions ([7c3b317](https://github.com/dodopayments/dodopayments-typescript/commit/7c3b3176c9856091ea8775170dea8405c85ef0f9))


### Bug Fixes

* **client:** avoid memory leak with abort signals ([43fee23](https://github.com/dodopayments/dodopayments-typescript/commit/43fee23c409c46cdc7e70fc10971361bed8d39c9))
* **client:** avoid removing abort listener too early ([98670fb](https://github.com/dodopayments/dodopayments-typescript/commit/98670fbcf5cd44290638b90ba3a199025cf05654))


### Chores

* **client:** do not parse responses with empty content-length ([8e016ce](https://github.com/dodopayments/dodopayments-typescript/commit/8e016ce6dcca5d47768d9a1bb5ab22acee752915))
* **client:** restructure abort controller binding ([5df0db6](https://github.com/dodopayments/dodopayments-typescript/commit/5df0db60524d8180b5a405b088270826c37a4376))
* **internal:** fix pagination internals not accepting option promises ([84bd174](https://github.com/dodopayments/dodopayments-typescript/commit/84bd1746b20780756e2fd9e3b1858155a1afc5bd))
* **internal:** refactor flag parsing for MCP servers and add debug flag ([c1dba91](https://github.com/dodopayments/dodopayments-typescript/commit/c1dba916b8d39ec80555f221feef774370069ea5))
* **internal:** support oauth authorization code flow for MCP servers ([73ee572](https://github.com/dodopayments/dodopayments-typescript/commit/73ee5720b067c69d39cc463453f8227b025a6a61))

## 2.18.0 (2026-02-02)

Full Changelog: [v2.17.2...v2.18.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.17.2...v2.18.0)

### Features

* **api:** updated openapi spec for v1.78.1 ([b948d56](https://github.com/dodopayments/dodopayments-typescript/commit/b948d564ffe08c1d44940f7d269f1093283581d9))


### Bug Fixes

* **mcp:** do not fallback on baseUrl if environment env variable is set ([c493aee](https://github.com/dodopayments/dodopayments-typescript/commit/c493aeee0442d011020fd1329c7c71966669c01c))

## 2.17.2 (2026-01-29)

Full Changelog: [v2.17.1...v2.17.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.17.1...v2.17.2)

### Bug Fixes

* **docs:** fix mcp installation instructions for remote servers ([457a056](https://github.com/dodopayments/dodopayments-typescript/commit/457a056a4d7cec5b562f64582b7f72bc9e14c3cc))
* **mcp:** allow falling back for required env variables ([0f81b34](https://github.com/dodopayments/dodopayments-typescript/commit/0f81b340bccc432b1106d0cb81fb28acc977eaa9))


### Chores

* **internal:** codegen related update ([250b777](https://github.com/dodopayments/dodopayments-typescript/commit/250b777332317903394a5aff1f221f20dcd71f30))
* **internal:** upgrade wrangler version ([9bb5b5a](https://github.com/dodopayments/dodopayments-typescript/commit/9bb5b5a098259ee1e3bd97c4bf5fb690be2e7c3e))
* **mcp:** up tsconfig lib version to es2022 ([42eb7fd](https://github.com/dodopayments/dodopayments-typescript/commit/42eb7fd669fbb4a6edff65c09215536d73648c6d))

## 2.17.1 (2026-01-24)

Full Changelog: [v2.17.0...v2.17.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.17.0...v2.17.1)

### Chores

* **ci:** upgrade `actions/github-script` ([1dfc35d](https://github.com/dodopayments/dodopayments-typescript/commit/1dfc35daf47b267ce92d6b499d75950e4659f68d))
* **internal:** update lock file ([590ba2e](https://github.com/dodopayments/dodopayments-typescript/commit/590ba2e04080103140ff6f91c8ba72c6dd29bf83))

## 2.17.0 (2026-01-23)

Full Changelog: [v2.16.0...v2.17.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.16.0...v2.17.0)

### Features

* **api:** updated openapi spec to v1.75.0 ([4e44de1](https://github.com/dodopayments/dodopayments-typescript/commit/4e44de19e1cf2f2a4c87400068dbc336b9be6d42))

## 2.16.0 (2026-01-21)

Full Changelog: [v2.15.0...v2.16.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.15.0...v2.16.0)

### Features

* **api:** updated openapi spec to v1.74.0 ([9ab678f](https://github.com/dodopayments/dodopayments-typescript/commit/9ab678fd8051a05d73beb2c5fdc0a7a8fcdbcb0a))

## 2.15.0 (2026-01-20)

Full Changelog: [v2.14.3...v2.15.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.14.3...v2.15.0)

### Features

* **api:** update openapi spec to v1.73.0 ([9ad3664](https://github.com/dodopayments/dodopayments-typescript/commit/9ad36648ec7a7e684fef9aa788c2b59ff0f71755))


### Chores

* **internal:** update `actions/checkout` version ([a38b8d5](https://github.com/dodopayments/dodopayments-typescript/commit/a38b8d54bcc8c67a3c5633e20540a40b07f72eb0))

## 2.14.3 (2026-01-15)

Full Changelog: [v2.14.2...v2.14.3](https://github.com/dodopayments/dodopayments-typescript/compare/v2.14.2...v2.14.3)

### Chores

* **internal:** bump MCP dependencies ([db8c602](https://github.com/dodopayments/dodopayments-typescript/commit/db8c60265d443e496f83e57c11b3a0af9409d94b))
* **internal:** codegen related update ([e67b8ab](https://github.com/dodopayments/dodopayments-typescript/commit/e67b8ab13deeb95f1e26d002da944e8f1433f38b))
* **internal:** codegen related update ([9cdbd78](https://github.com/dodopayments/dodopayments-typescript/commit/9cdbd78dbdb3500f2220dd1166e11eaa99bd3e6d))
* **internal:** codegen related update ([e4684fd](https://github.com/dodopayments/dodopayments-typescript/commit/e4684fdccd39d8a3b5e4e3d27568636675b4c24b))
* **internal:** codegen related update ([1794dfc](https://github.com/dodopayments/dodopayments-typescript/commit/1794dfc5ae919881a1ca6f0a29f304f0f3cb809d))
* **internal:** upgrade babel, qs, js-yaml ([59f708e](https://github.com/dodopayments/dodopayments-typescript/commit/59f708e31af6921f6843ef11f44a30c40a0253b2))
* **mcp:** add intent param to execute tool ([f106d1f](https://github.com/dodopayments/dodopayments-typescript/commit/f106d1fbf8f606846e691af59bf3790a8a282ab2))
* **mcp:** pass intent param to execute handler ([2e764c8](https://github.com/dodopayments/dodopayments-typescript/commit/2e764c8381c3985f7efa253489d36ac3eb8ef9cb))
* **mcp:** upgrade dependencies ([007bdc7](https://github.com/dodopayments/dodopayments-typescript/commit/007bdc758773540e2c6a639cf73d9d8f28a00905))

## 2.14.2 (2026-01-09)

Full Changelog: [v2.14.1...v2.14.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.14.1...v2.14.2)

### Bug Fixes

* **mcp:** update code tool prompt ([f054974](https://github.com/dodopayments/dodopayments-typescript/commit/f05497455943d2036554336f18423fffc37d28b9))

## 2.14.1 (2026-01-08)

Full Changelog: [v2.14.0...v2.14.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.14.0...v2.14.1)

### Bug Fixes

* **mcp:** fix env parsing ([f3af21d](https://github.com/dodopayments/dodopayments-typescript/commit/f3af21ddd3b4259baf9253104287ef8df5c1ce99))

## 2.14.0 (2026-01-07)

Full Changelog: [v2.13.1...v2.14.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.13.1...v2.14.0)

### Features

* **api:** updated openapi spec to v1.70.0 ([d36e38c](https://github.com/dodopayments/dodopayments-typescript/commit/d36e38c6ca8220c2fc0542033e9b2e6218439939))


### Bug Fixes

* **mcp:** correct code tool api output types ([bbbc142](https://github.com/dodopayments/dodopayments-typescript/commit/bbbc1423854c86f70677c068cb2e6668637c3f67))
* **mcp:** fix options parsing ([6da0a7c](https://github.com/dodopayments/dodopayments-typescript/commit/6da0a7cdaa25ae1c41f7e04091fb27df434cad2b))
* **mcp:** update cloudflare worker host page ([ae227f9](https://github.com/dodopayments/dodopayments-typescript/commit/ae227f9fda328ee51a18a9615d106a8795606b1b))


### Chores

* break long lines in snippets into multiline ([2636044](https://github.com/dodopayments/dodopayments-typescript/commit/2636044ef2a14dff84e9434a0ac9597fb549c89c))
* **internal:** codegen related update ([fc2cb03](https://github.com/dodopayments/dodopayments-typescript/commit/fc2cb03574ec0802b0805de4fe5d111d682f2c94))
* **internal:** fix dockerfile ([3ba3c84](https://github.com/dodopayments/dodopayments-typescript/commit/3ba3c8454c3ef7aff01ff507cb8ca29648bf555c))


### Documentation

* prominently feature MCP server setup in root SDK readmes ([4591215](https://github.com/dodopayments/dodopayments-typescript/commit/459121587c7337168049998ad1c8b79ffa9ea82f))

## 2.13.1 (2025-12-23)

Full Changelog: [v2.13.0...v2.13.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.13.0...v2.13.1)

## 2.13.0 (2025-12-23)

Full Changelog: [v2.12.0...v2.13.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.12.0...v2.13.0)

### Features

* **api:** manual updates ([7d94f13](https://github.com/dodopayments/dodopayments-typescript/commit/7d94f13b0a87e48545bc2247c592637180977b3d))

## 2.12.0 (2025-12-23)

Full Changelog: [v2.11.0...v2.12.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.11.0...v2.12.0)

### Features

* **api:** manual updates ([f6e359e](https://github.com/dodopayments/dodopayments-typescript/commit/f6e359e957edcdd5f8e7461e84450fdb60eea6ad))
* **api:** manual updates ([0b44ac4](https://github.com/dodopayments/dodopayments-typescript/commit/0b44ac45f8881f007dc5d865708b62d55378732e))
* **api:** manual updates ([20b535a](https://github.com/dodopayments/dodopayments-typescript/commit/20b535a73d16ed172f98ce6dd9c9ca505ccafbfe))

## 2.11.0 (2025-12-19)

Full Changelog: [v2.10.0...v2.11.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.10.0...v2.11.0)

### Features

* **api:** updated openapi spec to v1.68.4 ([4dfb782](https://github.com/dodopayments/dodopayments-typescript/commit/4dfb78238635536d76b60ed0acd401d41b08f3bc))

## 2.10.0 (2025-12-19)

Full Changelog: [v2.9.3...v2.10.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.9.3...v2.10.0)

### ⚠ BREAKING CHANGES

* **mcp:** remove deprecated tool schemes
* **mcp:** **Migration:** To migrate, simply modify the command used to invoke the MCP server. Currently, the only supported tool scheme is code mode. Now, starting the server with just `node /path/to/mcp/server` or `npx package-name` will invoke code tools: changing your command to one of these is likely all you will need to do.

### Chores

* **mcp:** remove deprecated tool schemes ([30636e2](https://github.com/dodopayments/dodopayments-typescript/commit/30636e2ade07ae6c63cca244396292b4af255f1c))

## 2.9.3 (2025-12-18)

Full Changelog: [v2.9.2...v2.9.3](https://github.com/dodopayments/dodopayments-typescript/compare/v2.9.2...v2.9.3)

### Features

* added github workflow to deploy remote mcp ([47bc497](https://github.com/dodopayments/dodopayments-typescript/commit/47bc4974dc7891d90bb187f5d56fbd5cabc13b5c))

## 2.9.2 (2025-12-18)

Full Changelog: [v2.9.1...v2.9.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.9.1...v2.9.2)

## 2.9.1 (2025-12-18)

Full Changelog: [v2.9.0...v2.9.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.9.0...v2.9.1)

### Bug Fixes

* **mcp:** pass base url to code tool ([072f6ae](https://github.com/dodopayments/dodopayments-typescript/commit/072f6ae95b170f12b6b9a784902ac4716678f273))

## 2.9.0 (2025-12-16)

Full Changelog: [v2.8.2...v2.9.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.8.2...v2.9.0)

### Features

* **api:** updated openapi spec to 1.67.0 ([51f51c2](https://github.com/dodopayments/dodopayments-typescript/commit/51f51c250de091cf446e3dcc07b769807ccce0d4))

## 2.8.2 (2025-12-12)

Full Changelog: [v2.8.1...v2.8.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.8.1...v2.8.2)

### Features

* **api:** manual updates ([ee46503](https://github.com/dodopayments/dodopayments-typescript/commit/ee4650384dcea5b6582d05f4b026222a95a5bcda))

## 2.8.1 (2025-12-11)

Full Changelog: [v2.8.0...v2.8.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.8.0...v2.8.1)

### Bug Fixes

* **mcp:** add client instantiation options to code tool ([2a4d359](https://github.com/dodopayments/dodopayments-typescript/commit/2a4d3597473d5cd99b5b1b953c1542e72f67a7ed))


### Chores

* **mcp:** update lockfile ([f134474](https://github.com/dodopayments/dodopayments-typescript/commit/f134474be68c9810f614f1c9d6b94e299251d24f))

## 2.8.0 (2025-12-08)

Full Changelog: [v2.7.0...v2.8.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.7.0...v2.8.0)

### Features

* **api:** updated openapi spec to v1.66.1 ([474043c](https://github.com/dodopayments/dodopayments-typescript/commit/474043c1f42a43320bb4dd0b0382db8c15966dbf))

## 2.7.0 (2025-12-06)

Full Changelog: [v2.6.1...v2.7.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.6.1...v2.7.0)

### Features

* **mcp:** add typescript check to code execution tool ([2f56804](https://github.com/dodopayments/dodopayments-typescript/commit/2f56804c7cf6dc223c979e584c887eab9b604dde))
* **mcp:** handle code mode calls in the Stainless API ([f6bd9d6](https://github.com/dodopayments/dodopayments-typescript/commit/f6bd9d6f4d0772381cadafb66c0d722c6312eb47))
* **mcp:** return logs on code tool errors ([83027fa](https://github.com/dodopayments/dodopayments-typescript/commit/83027faac8152d5b77daadfd27d6e7faff357270))


### Bug Fixes

* **mcp:** correct code tool API endpoint ([afe32e3](https://github.com/dodopayments/dodopayments-typescript/commit/afe32e33cb2cd739e08b64793cec95d5042cc917))
* **mcp:** return correct lines on typescript errors ([3b3812a](https://github.com/dodopayments/dodopayments-typescript/commit/3b3812adfe4dcef428aa5bdc5d322f163e5b9df3))
* **mcp:** return tool execution error on api error ([f07b9bd](https://github.com/dodopayments/dodopayments-typescript/commit/f07b9bd918bbc2a1204e602f9372520ac8714014))


### Chores

* **client:** fix logger property type ([b8287ca](https://github.com/dodopayments/dodopayments-typescript/commit/b8287cae23381f54b8dece0208b7f447dee991d5))
* **internal:** codegen related update ([7c6e9ef](https://github.com/dodopayments/dodopayments-typescript/commit/7c6e9ef24f57274b326fdffacc8c88ffb82f1010))
* **internal:** codegen related update ([0c4f3cb](https://github.com/dodopayments/dodopayments-typescript/commit/0c4f3cbd22e4e3ff0281c8354ad05d56d199a7d9))
* **internal:** upgrade eslint ([1087217](https://github.com/dodopayments/dodopayments-typescript/commit/1087217168c4b4a3230cee92643e7f248c6fa103))
* use latest @modelcontextprotocol/sdk ([5ee0582](https://github.com/dodopayments/dodopayments-typescript/commit/5ee05822a8084f85a65deee940c3fff80743a6b4))

## 2.6.1 (2025-11-26)

Full Changelog: [v2.6.0...v2.6.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.6.0...v2.6.1)

### Features

* **mcp:** add detail field to docs search tool ([2e964b0](https://github.com/dodopayments/dodopayments-typescript/commit/2e964b0e3a252f9a77470bcf346d1991d653cd8b))

## 2.6.0 (2025-11-17)

Full Changelog: [v2.5.0...v2.6.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.5.0...v2.6.0)

### Features

* **api:** updated openapi spec to v1.61.5 ([aeb4dfc](https://github.com/dodopayments/dodopayments-typescript/commit/aeb4dfcb79667c789422b1106f4b0536d3d8e833))

## 2.5.0 (2025-11-14)

Full Changelog: [v2.4.6...v2.5.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.4.6...v2.5.0)

### Features

* **api:** added update payment method and updated openapi spec to v1.60.0 ([05fa53d](https://github.com/dodopayments/dodopayments-typescript/commit/05fa53d2182621dc51b90bf62b3acf3f75f06702))

## 2.4.6 (2025-11-13)

Full Changelog: [v2.4.5...v2.4.6](https://github.com/dodopayments/dodopayments-typescript/compare/v2.4.5...v2.4.6)

### Bug Fixes

* **mcp:** return tool execution error on jq failure ([a5e673a](https://github.com/dodopayments/dodopayments-typescript/commit/a5e673ab548c0596a14fcf2654b049212fcd9e23))


### Chores

* **mcp:** upgrade jq-web ([82e2b27](https://github.com/dodopayments/dodopayments-typescript/commit/82e2b2784ea2538bb45e7d33559e48f12929d455))

## 2.4.5 (2025-11-11)

Full Changelog: [v2.4.4...v2.4.5](https://github.com/dodopayments/dodopayments-typescript/compare/v2.4.4...v2.4.5)

### Bug Fixes

* **mcp:** use raw responses for binary content ([a5954f0](https://github.com/dodopayments/dodopayments-typescript/commit/a5954f00b96ebc1a422b706894b0ed57e914abe2))


### Chores

* **internal:** codegen related update ([c21861f](https://github.com/dodopayments/dodopayments-typescript/commit/c21861fb2a1f3d1d87e1d27ba1faa700655163f0))
* **internal:** codegen related update ([25d312a](https://github.com/dodopayments/dodopayments-typescript/commit/25d312ac17d7da5825564782dff206873ca3440d))
* **mcp:** clarify http auth error ([a6e4eab](https://github.com/dodopayments/dodopayments-typescript/commit/a6e4eab2e2f2d05ff675432e9c13a475faa85233))

## 2.4.4 (2025-11-07)

Full Changelog: [v2.4.3...v2.4.4](https://github.com/dodopayments/dodopayments-typescript/compare/v2.4.3...v2.4.4)

### Chores

* **internal:** codegen related update ([818e90b](https://github.com/dodopayments/dodopayments-typescript/commit/818e90b659ed5fcd34e882c2d6fff158a59ea612))
* **mcp:** add friendlier MCP code tool errors on incorrect method invocations ([abbe057](https://github.com/dodopayments/dodopayments-typescript/commit/abbe057c30e109ad630804a66020fdb2131dee98))
* **mcp:** add line numbers to code tool errors ([2de014b](https://github.com/dodopayments/dodopayments-typescript/commit/2de014babcdbf101ad373677e24ce17e54fa51e7))


### Documentation

* **mcp:** add a README button for one-click add to Cursor ([cf25725](https://github.com/dodopayments/dodopayments-typescript/commit/cf2572540a90396e32b73becbded03dbe18fb6b3))
* **mcp:** add a README link to add server to VS Code or Claude Code ([e9131bb](https://github.com/dodopayments/dodopayments-typescript/commit/e9131bb9bee194dcdf29625cc31325b15764027a))

## 2.4.3 (2025-11-05)

Full Changelog: [v2.4.2...v2.4.3](https://github.com/dodopayments/dodopayments-typescript/compare/v2.4.2...v2.4.3)

### Features

* **mcp:** enable optional code execution tool on http mcp servers ([6d35c29](https://github.com/dodopayments/dodopayments-typescript/commit/6d35c29e461d58f4697a83fffc8fc6f818fe7bbc))


### Chores

* **internal:** codegen related update ([0dc8e91](https://github.com/dodopayments/dodopayments-typescript/commit/0dc8e91e6d9d1622f38f65f6bfb4a3abb4ab8e3e))
* **internal:** grammar fix (it's -&gt; its) ([6275ab5](https://github.com/dodopayments/dodopayments-typescript/commit/6275ab5cea238e1c52bd44af1a2bb66deacc899d))
* mcp code tool explicit error message when missing a run function ([b1409a5](https://github.com/dodopayments/dodopayments-typescript/commit/b1409a54f124d5cdaae427dbf0ece4dc4f8cb0f6))
* use structured error when code execution tool errors ([c6ea394](https://github.com/dodopayments/dodopayments-typescript/commit/c6ea39446c6d236aa3f9a9c6a400e81aa8a946be))

## 2.4.2 (2025-10-31)

Full Changelog: [v2.4.1...v2.4.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.4.1...v2.4.2)

### Bug Fixes

* **mcpb:** pin @anthropic-ai/mcpb version ([ca20767](https://github.com/dodopayments/dodopayments-typescript/commit/ca20767f9d543a320374df1315f3d4e6a90b2326))

## 2.4.1 (2025-10-29)

Full Changelog: [v2.4.0...v2.4.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.4.0...v2.4.1)

### Features

* **api:** updated openapi spec to v1.56.3 ([65bd174](https://github.com/dodopayments/dodopayments-typescript/commit/65bd1742a77724511637a535953ade0ca151d30d))

## 2.4.0 (2025-10-27)

Full Changelog: [v2.3.1...v2.4.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.3.1...v2.4.0)

### Features

* **api:** updated to openapi spec v1.56.0 ([bbffb43](https://github.com/dodopayments/dodopayments-typescript/commit/bbffb435587036518d86a719313b609a43e63bdb))

## 2.3.1 (2025-10-25)

Full Changelog: [v2.3.0...v2.3.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.3.0...v2.3.1)

### Bug Fixes

* fixed docker tags to for ghcr registry ([fb5f727](https://github.com/dodopayments/dodopayments-typescript/commit/fb5f727b04fc176be17bd19508034f6ccfcac3d6))

## 2.3.0 (2025-10-25)

Full Changelog: [v2.2.1...v2.3.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.2.1...v2.3.0)

### Features

* **api:** added unwrap functions for webhooks ([0d29085](https://github.com/dodopayments/dodopayments-typescript/commit/0d29085bd32fdeebdb36762e61f1a5e3a365e5b1))

## 2.2.1 (2025-10-17)

Full Changelog: [v2.2.0...v2.2.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.2.0...v2.2.1)

### Features

* **api:** updates for openapi spec v1.55.7 ([2ec3ba5](https://github.com/dodopayments/dodopayments-typescript/commit/2ec3ba57a4a69a92ad3982d98b9f8e0f756e0d60))

## 2.2.0 (2025-10-16)

Full Changelog: [v2.1.2...v2.2.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.1.2...v2.2.0)

### Features

* **api:** updated openapi spec to v1.55.0 ([a58bb8c](https://github.com/dodopayments/dodopayments-typescript/commit/a58bb8c880d745469f9eae7e575fc48fb3064692))

## 2.1.2 (2025-10-09)

Full Changelog: [v2.1.1...v2.1.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.1.1...v2.1.2)

### Bug Fixes

* **mcp:** fix cli argument parsing logic ([be71da4](https://github.com/dodopayments/dodopayments-typescript/commit/be71da4e2d5b2d031ede89fc4ee81fc0a0e7cd8b))
* **mcp:** resolve a linting issue in server code ([210cc3b](https://github.com/dodopayments/dodopayments-typescript/commit/210cc3b45f351ceeb07fa397000bbf7021b2b09d))


### Chores

* extract some types in mcp docs ([2ed0150](https://github.com/dodopayments/dodopayments-typescript/commit/2ed0150ec13d1756910dfd551272a2321ddffb0d))
* **internal:** codegen related update ([38db37d](https://github.com/dodopayments/dodopayments-typescript/commit/38db37dc84d4c69f176e85e26fcff5d9804e0eee))
* **internal:** install openssl in mcp dockerfile ([376336e](https://github.com/dodopayments/dodopayments-typescript/commit/376336e9743637eadfa051becc8f1c21d56febce))
* **internal:** remove .eslintcache ([6b291aa](https://github.com/dodopayments/dodopayments-typescript/commit/6b291aa43ec692f85fa557cda16e3711aa993cc6))
* **internal:** use npm pack for build uploads ([ee07311](https://github.com/dodopayments/dodopayments-typescript/commit/ee073119746a36e9f14ff577fd6a075ea107cb5c))
* **jsdoc:** fix [@link](https://github.com/link) annotations to refer only to parts of the package‘s public interface ([1b777fc](https://github.com/dodopayments/dodopayments-typescript/commit/1b777fc9fc10cd87e01dff0cb21b8788cab4113d))
* update lockfile ([75b31af](https://github.com/dodopayments/dodopayments-typescript/commit/75b31afb0abee6ecf3b58dd2102235aa3dd8c9b4))

## 2.1.1 (2025-09-27)

Full Changelog: [v2.1.0...v2.1.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.1.0...v2.1.1)

### Performance Improvements

* faster formatting ([724b1c7](https://github.com/dodopayments/dodopayments-typescript/commit/724b1c7048ab6fbdfe0233813d59faccd185a152))


### Chores

* **internal:** codegen related update ([e8818ea](https://github.com/dodopayments/dodopayments-typescript/commit/e8818eaedce15ea0c39f34174439587ae520b124))
* **internal:** fix incremental formatting in some cases ([5aeafd4](https://github.com/dodopayments/dodopayments-typescript/commit/5aeafd41fd072e24d91f4ae766bd1c13052ba4e6))
* **internal:** ignore .eslintcache ([33aff0d](https://github.com/dodopayments/dodopayments-typescript/commit/33aff0d2e3d901120aab9ca65802a55f17056412))
* **internal:** remove deprecated `compilerOptions.baseUrl` from tsconfig.json ([635fe9f](https://github.com/dodopayments/dodopayments-typescript/commit/635fe9fbe1c3fb542d3aa220eee0ef2a73b4daa5))
* **mcp:** allow pointing `docs_search` tool at other URLs ([4e76510](https://github.com/dodopayments/dodopayments-typescript/commit/4e76510b44d5ba65444d5209bf45f4edf3630b72))

## 2.1.0 (2025-09-24)

Full Changelog: [v2.0.2...v2.1.0](https://github.com/dodopayments/dodopayments-typescript/compare/v2.0.2...v2.1.0)

### Features

* **mcp:** add docs search tool ([5c9347e](https://github.com/dodopayments/dodopayments-typescript/commit/5c9347e55e8a8a3bff47ba6da1a31c4f43ecc073))
* **mcp:** add option for including docs tools ([99f2b78](https://github.com/dodopayments/dodopayments-typescript/commit/99f2b786c82b708687362f45ccaed1638c851cea))
* **mcp:** enable experimental docs search tool ([0bb2426](https://github.com/dodopayments/dodopayments-typescript/commit/0bb2426ade3fe591c64eae721d44fb7404bcaca1))


### Chores

* **codegen:** internal codegen update ([9a2cf7d](https://github.com/dodopayments/dodopayments-typescript/commit/9a2cf7d75677004865f13e9b21663729549cdf0b))
* do not install brew dependencies in ./scripts/bootstrap by default ([d9dd55f](https://github.com/dodopayments/dodopayments-typescript/commit/d9dd55fb53e50f8fded47696b2621969b3539d06))
* **internal:** gitignore .mcpb files ([a71c421](https://github.com/dodopayments/dodopayments-typescript/commit/a71c421ffcfcdc203f127dd7a691b6a99e5a5fd5))
* **mcp:** rename dxt to mcpb ([0622aa1](https://github.com/dodopayments/dodopayments-typescript/commit/0622aa1a6805aa1e81ed4004bcdab7e8b5034c43))

## 2.0.2 (2025-09-17)

Full Changelog: [v2.0.1...v2.0.2](https://github.com/dodopayments/dodopayments-typescript/compare/v2.0.1...v2.0.2)

### Bug Fixes

* **ci:** set permissions for DXT publish action ([b317617](https://github.com/dodopayments/dodopayments-typescript/commit/b317617e8ec64a23713562dc479e0fb62bd07fd0))

## 2.0.1 (2025-09-13)

Full Changelog: [v2.0.0...v2.0.1](https://github.com/dodopayments/dodopayments-typescript/compare/v2.0.0...v2.0.1)

### Features

* **api:** added ghcr deployment for mcp ([f341bc9](https://github.com/dodopayments/dodopayments-typescript/commit/f341bc993ac6d3f1456d2e00a6071c1549112cf4))
* **api:** manual updates ([885eba9](https://github.com/dodopayments/dodopayments-typescript/commit/885eba915dd27ff9e3adaef2653d89a59c7c7aab))

## 2.0.0 (2025-09-13)

Full Changelog: [v1.53.2...v2.0.0](https://github.com/dodopayments/dodopayments-typescript/compare/v1.53.2...v2.0.0)

### Features

* **api:** added typescript sdk for migration and updated org info ([3806e38](https://github.com/dodopayments/dodopayments-typescript/commit/3806e38ac7f1aab12d728357201f9c37d704e2e2))
* **api:** changed target version for typescript sdk to 2.0.0 ([eedbc6f](https://github.com/dodopayments/dodopayments-typescript/commit/eedbc6f492fdfe9cba6ce592f57570a7e6a36233))
* **api:** manual updates ([cce60af](https://github.com/dodopayments/dodopayments-typescript/commit/cce60af560973e4cd56bd3d8f07a0a6f088964b5))

## 1.53.2 (2025-09-13)

Full Changelog: [v1.52.6...v1.53.2](https://github.com/dodopayments/dodopayments-node/compare/v1.52.6...v1.53.2)

### Features

* **api:** updated openapi spec to v1.53.2 with customer credits. ([e581980](https://github.com/dodopayments/dodopayments-node/commit/e5819800818775d22638fda9b4b3f02ff8ca7189))

## 1.52.6 (2025-09-12)

Full Changelog: [v1.52.5...v1.52.6](https://github.com/dodopayments/dodopayments-node/compare/v1.52.5...v1.52.6)

### Bug Fixes

* coerce nullable values to undefined ([5adbb53](https://github.com/dodopayments/dodopayments-node/commit/5adbb53687ee1c807c9dfc372ffd6e9df23d2d3c))
* **mcp:** fix uploading dxt release assets ([b3a8b02](https://github.com/dodopayments/dodopayments-node/commit/b3a8b0287e3910710040dfbbb238d2f5e712181a))


### Chores

* ci build action ([5c198c5](https://github.com/dodopayments/dodopayments-node/commit/5c198c5b04e10cc2d6fe72b66c03941ead3d3aea))
* **internal:** codegen related update ([233e6f4](https://github.com/dodopayments/dodopayments-node/commit/233e6f4063f323277dfb473b55101679e8bbf5e8))
* **internal:** codegen related update ([ea563ba](https://github.com/dodopayments/dodopayments-node/commit/ea563bafefc9e10b56bfb9b4bcef573a2c23eb5b))
* **internal:** codegen related update ([6f372f8](https://github.com/dodopayments/dodopayments-node/commit/6f372f832f2cda7b3140e7d9162701f562a3ecb6))
* **internal:** codegen related update ([7f0b0e5](https://github.com/dodopayments/dodopayments-node/commit/7f0b0e5c29d6d4143ab6bf8f511f028719155d48))

## 1.52.5 (2025-09-04)

Full Changelog: [v1.52.3...v1.52.5](https://github.com/dodopayments/dodopayments-node/compare/v1.52.3...v1.52.5)

### Features

* **api:** updated openapi spec to v1.52.4 ([a37d6c4](https://github.com/dodopayments/dodopayments-node/commit/a37d6c433fc3e4810118d6f665e398210554cc6c))

## 1.52.3 (2025-09-03)

Full Changelog: [v1.51.2...v1.52.3](https://github.com/dodopayments/dodopayments-node/compare/v1.51.2...v1.52.3)

### Features

* **api:** manual updates ([7a7db07](https://github.com/dodopayments/dodopayments-node/commit/7a7db0762a1020d0728d9da846a3d65b5d0d4c0a))
* **api:** updated openapi spec ([db99ebf](https://github.com/dodopayments/dodopayments-node/commit/db99ebfb265529a3997b873722a0aaf80b314279))
* **mcp:** add client infer to cloudflare oauth screen ([335f078](https://github.com/dodopayments/dodopayments-node/commit/335f078f1d66afe41532d29558aed3d8a5c118eb))
* **mcp:** allow setting logging level ([b3850a4](https://github.com/dodopayments/dodopayments-node/commit/b3850a4f6c383c3bd60c5dc23f9af6e5bf7a69d5))
* **mcp:** expose client options in `streamableHTTPApp` ([621a46f](https://github.com/dodopayments/dodopayments-node/commit/621a46f4b907fae51e1b515b2e492ba8cee4dd3e))
* updated openapi spec and added model and API functions for Usage Based Billing ([1714ff8](https://github.com/dodopayments/dodopayments-node/commit/1714ff822ddd24afe7d979710f20dac30630faaf))


### Chores

* **internal:** codegen related update ([b5228cd](https://github.com/dodopayments/dodopayments-node/commit/b5228cd2b0e92ca723cbb21fc5dc6de90adb472d))

## 1.51.2 (2025-08-24)

Full Changelog: [v1.51.1...v1.51.2](https://github.com/dodopayments/dodopayments-node/compare/v1.51.1...v1.51.2)

### Chores

* **internal:** codegen related update ([a1c2ade](https://github.com/dodopayments/dodopayments-node/commit/a1c2ade3449d477ec6cb4d56707cc7ea01e5c2b4))

## 1.51.1 (2025-08-23)

Full Changelog: [v1.51.0...v1.51.1](https://github.com/dodopayments/dodopayments-node/compare/v1.51.0...v1.51.1)

### Chores

* update CI script ([aaa4323](https://github.com/dodopayments/dodopayments-node/commit/aaa4323ec1514c6da767ecb85b8431eb5f0be055))

## 1.51.0 (2025-08-22)

Full Changelog: [v1.50.0...v1.51.0](https://github.com/dodopayments/dodopayments-node/compare/v1.50.0...v1.51.0)

### Features

* **api:** updated example ([151f228](https://github.com/dodopayments/dodopayments-node/commit/151f228a14708fbe310759a6bf3a8f8ae5c7bf05))
* **api:** updated openapi spec to v1.51.0 and added checkout sessions ([a6112d2](https://github.com/dodopayments/dodopayments-node/commit/a6112d233096c7965cadc198ea24bd97cb5fe7c1))
* **mcp:** add code execution tool ([4078bec](https://github.com/dodopayments/dodopayments-node/commit/4078becd78ac85ca3c02979e64c50762ffa98ff4))
* **mcp:** add option to infer mcp client ([a8e60df](https://github.com/dodopayments/dodopayments-node/commit/a8e60df1a59e578dee481d59a47808e7cf54bdc8))


### Chores

* **internal:** make mcp-server publishing public by defaut ([016ca5d](https://github.com/dodopayments/dodopayments-node/commit/016ca5dfe898dd368284ba0ca1021f5ba7ca8a03))
* **mcp:** add cors to oauth metadata route ([7a1dfab](https://github.com/dodopayments/dodopayments-node/commit/7a1dfab7417af634831e17ade3d230ad9c669efe))
* **mcp:** update package.json ([178dc54](https://github.com/dodopayments/dodopayments-node/commit/178dc547856924dc78e53476a476b2e094b17e13))
* **mcp:** update types ([4a5334a](https://github.com/dodopayments/dodopayments-node/commit/4a5334aa6ffe45df5a838f0e1adf0729e8774124))

## 1.50.0 (2025-08-19)

Full Changelog: [v1.49.0...v1.50.0](https://github.com/dodopayments/dodopayments-node/compare/v1.49.0...v1.50.0)

### Features

* **mcp:** parse query string as mcp client options in mcp server ([437576b](https://github.com/dodopayments/dodopayments-node/commit/437576ba21fbb0b4af499d36e42968bb3f1e9ec8))


### Chores

* **internal:** codegen related update ([cf27f35](https://github.com/dodopayments/dodopayments-node/commit/cf27f35ae4962cf8518c987adecbc299665831b7))
* **internal:** formatting change ([a205553](https://github.com/dodopayments/dodopayments-node/commit/a205553b4b08e01d2baef2c4a2bcc17182488220))
* **internal:** refactor array check ([e6493fd](https://github.com/dodopayments/dodopayments-node/commit/e6493fd69e4c6d34c8e236918fc210affd6d70b5))
* **mcp:** update README ([a47e159](https://github.com/dodopayments/dodopayments-node/commit/a47e1595012064cbfea21503cc648782dd0a5233))

## 1.49.0 (2025-08-13)

Full Changelog: [v1.47.0...v1.49.0](https://github.com/dodopayments/dodopayments-node/compare/v1.47.0...v1.49.0)

### Features

* **api:** manual updates ([723f2fc](https://github.com/dodopayments/dodopayments-node/commit/723f2fcec2953beae7c13d256be6453f8c76a0de))
* **api:** manual updates ([611d6f7](https://github.com/dodopayments/dodopayments-node/commit/611d6f7b27065df3dca4af7cf4ae2b0abb469945))

## 1.47.0 (2025-08-11)

Full Changelog: [v1.44.0...v1.47.0](https://github.com/dodopayments/dodopayments-node/compare/v1.44.0...v1.47.0)

### Features

* **api:** updated openapi spec to 1.47.0 ([93680ff](https://github.com/dodopayments/dodopayments-node/commit/93680fff0db339f25e3566d3dd04d58592121009))

## 1.44.0 (2025-08-02)

Full Changelog: [v1.43.1...v1.44.0](https://github.com/dodopayments/dodopayments-node/compare/v1.43.1...v1.44.0)

### Features

* **api:** updated openapi spec to 1.44.0 ([db97e62](https://github.com/dodopayments/dodopayments-node/commit/db97e623b97ed8302ed40a20a91f29c8b30fea1e))
* **mcp:** add logging when environment variable is set ([db7818f](https://github.com/dodopayments/dodopayments-node/commit/db7818f85d3f4a25cf81b418dee31c901a09a898))


### Bug Fixes

* **mcp:** avoid sending `jq_filter` to base API ([2ad3c06](https://github.com/dodopayments/dodopayments-node/commit/2ad3c06fcfbf991cc0aa6c4eebdc2bdbc084ebc7))
* **mcp:** fix tool description of jq_filter ([984671c](https://github.com/dodopayments/dodopayments-node/commit/984671c7b04460aba5685d815e20a251b9fc3ca2))
* **mcp:** reverse validJson capability option and limit scope ([f86edb8](https://github.com/dodopayments/dodopayments-node/commit/f86edb8cd9e585555b3e8a3eec2134e26d3f5233))


### Chores

* **internal:** remove redundant imports config ([925d5dd](https://github.com/dodopayments/dodopayments-node/commit/925d5dd8d23f9c742f2e62d5661b986eeab898a6))

## 1.43.1 (2025-07-24)

Full Changelog: [v1.43.0...v1.43.1](https://github.com/dodopayments/dodopayments-node/compare/v1.43.0...v1.43.1)

### Chores

* **internal:** codegen related update ([a5e5dcb](https://github.com/dodopayments/dodopayments-node/commit/a5e5dcb087020cd180fc4943c6a0d8dd1e02de12))

## 1.43.0 (2025-07-23)

Full Changelog: [v1.42.0...v1.43.0](https://github.com/dodopayments/dodopayments-node/compare/v1.42.0...v1.43.0)

### Features

* **api:** updated openapi spec to v1.42.5 ([58e3e45](https://github.com/dodopayments/dodopayments-node/commit/58e3e45c43b69f8f800404fbdf1cd072b404000d))


### Bug Fixes

* **mcp:** include required section for top-level properties and support naming transformations ([55a4476](https://github.com/dodopayments/dodopayments-node/commit/55a4476b4d3e24a2201d019779859ac41891bc99))


### Chores

* **mcp:** formatting ([9232c27](https://github.com/dodopayments/dodopayments-node/commit/9232c27b944cc70912475714d0893db427093da2))

## 1.42.0 (2025-07-16)

Full Changelog: [v1.39.0...v1.42.0](https://github.com/dodopayments/dodopayments-node/compare/v1.39.0...v1.42.0)

### Features

* **api:** updated open api spec to v1.42.0 ([f683f47](https://github.com/dodopayments/dodopayments-node/commit/f683f47856c6071ccb55d973f1531e6c954d6944))


### Bug Fixes

* **mcp:** support jq filtering on cloudflare workers ([d64da19](https://github.com/dodopayments/dodopayments-node/commit/d64da19e0ff9ac8079e93aaf871742abc2fce245))


### Chores

* **mcp:** rework imports in tools ([94907f5](https://github.com/dodopayments/dodopayments-node/commit/94907f5cb601a670762daa63f0c0ef59db1e7f01))

## 1.39.0 (2025-07-15)

Full Changelog: [v1.38.1...v1.39.0](https://github.com/dodopayments/dodopayments-node/compare/v1.38.1...v1.39.0)

### Features

* **api:** updated openapi spec to v1.40.0 ([e489d45](https://github.com/dodopayments/dodopayments-node/commit/e489d4506334554d6784a20a972ced8b45825a2b))

## 1.38.1 (2025-07-12)

Full Changelog: [v1.38.0...v1.38.1](https://github.com/dodopayments/dodopayments-node/compare/v1.38.0...v1.38.1)

### Features

* **mcp:** support filtering tool results by a jq expression ([f390045](https://github.com/dodopayments/dodopayments-node/commit/f390045e4d258218104616c68ba1c46fbebefd3b))


### Bug Fixes

* **mcp:** relax input type for asTextContextResult ([67a88e1](https://github.com/dodopayments/dodopayments-node/commit/67a88e17d91c4be59c6dbeb8895087a83508e512))


### Chores

* make some internal functions async ([04c263c](https://github.com/dodopayments/dodopayments-node/commit/04c263c8a4fc6a7bc19735da976d20d8986c0c72))


### Documentation

* **mcp:** correct instructions for adding to claude web ([4e68d7d](https://github.com/dodopayments/dodopayments-node/commit/4e68d7d3c6be9abdf0f3196ff475ce356ef4c9e2))

## 1.38.0 (2025-07-05)

Full Changelog: [v1.37.2...v1.38.0](https://github.com/dodopayments/dodopayments-node/compare/v1.37.2...v1.38.0)

### Features

* **api:** updated openapi spec to v1.38.0 ([e6b923f](https://github.com/dodopayments/dodopayments-node/commit/e6b923f77c2ab809d16a8304265bcf7b3fcb08ca))

## 1.37.2 (2025-07-04)

Full Changelog: [v1.37.1...v1.37.2](https://github.com/dodopayments/dodopayments-node/compare/v1.37.1...v1.37.2)

### Bug Fixes

* **build:** bump node version in CI build to 20 to be compatible with MCP package ([8d52f93](https://github.com/dodopayments/dodopayments-node/commit/8d52f93c06c7461a2ad5add9d26f36f88ddd1fc9))

## 1.37.1 (2025-07-03)

Full Changelog: [v1.37.1...v1.37.1](https://github.com/dodopayments/dodopayments-node/compare/v1.37.1...v1.37.1)

### Features

* **api:** added webhook event type model ([c82129b](https://github.com/dodopayments/dodopayments-node/commit/c82129b3cc45a79e9a8e113b50671837800f48f0))
* **api:** added webhook payload model ([978db2b](https://github.com/dodopayments/dodopayments-node/commit/978db2b2772d6b36ac850454db132f224087f28a))

## 1.37.1 (2025-07-03)

Full Changelog: [v1.37.0...v1.37.1](https://github.com/dodopayments/dodopayments-node/compare/v1.37.0...v1.37.1)

### Bug Fixes

* **client:** don't send `Content-Type` for bodyless methods ([4503d7b](https://github.com/dodopayments/dodopayments-node/commit/4503d7bec52fdf898bc0ec83fd5d052422ae0ddc))
* **mcp:** define `.well-known/oauth-protected-resource` ([4822976](https://github.com/dodopayments/dodopayments-node/commit/48229763c0d88a056e1b291b661491bca11e682e))


### Chores

* mention unit type in timeout docs ([4a8e9b7](https://github.com/dodopayments/dodopayments-node/commit/4a8e9b730cb63801a7b8f8066d869f6865126e6e))

## 1.37.0 (2025-07-02)

Full Changelog: [v1.34.2...v1.37.0](https://github.com/dodopayments/dodopayments-node/compare/v1.34.2...v1.37.0)

### Features

* **api:** updated openapi spec for v1.37.0 ([86f3058](https://github.com/dodopayments/dodopayments-node/commit/86f3058eee069f9362b9fe18d745312377cada35))
* **mcp:** fallback for void-typed methods ([e954db2](https://github.com/dodopayments/dodopayments-node/commit/e954db2bdc9d8be57f8fecf979fb60775e395f54))


### Bug Fixes

* **ci:** release-doctor — report correct token name ([66e853d](https://github.com/dodopayments/dodopayments-node/commit/66e853dc3e35e516357d0a0a05c7829806d321a7))


### Chores

* **ci:** only run for pushes and fork pull requests ([023e8a4](https://github.com/dodopayments/dodopayments-node/commit/023e8a41823d0f398cc8132fefe921996c163252))

## 1.34.2 (2025-06-24)

Full Changelog: [v1.34.1...v1.34.2](https://github.com/dodopayments/dodopayments-node/compare/v1.34.1...v1.34.2)

### Refactors

* **types:** replace Record with mapped types ([7863e76](https://github.com/dodopayments/dodopayments-node/commit/7863e762d41150756288cf325528530c40e5870d))

## 1.34.1 (2025-06-21)

Full Changelog: [v1.34.0...v1.34.1](https://github.com/dodopayments/dodopayments-node/compare/v1.34.0...v1.34.1)

### Features

* **api:** added cloudflare worker support for mcp ([92d0bca](https://github.com/dodopayments/dodopayments-node/commit/92d0bca4e826ca35e755329530e31b69646f02e6))

## 1.34.0 (2025-06-18)

Full Changelog: [v1.32.0...v1.34.0](https://github.com/dodopayments/dodopayments-node/compare/v1.32.0...v1.34.0)

### Features

* **api:** updated to version 1.34.0 ([5e2b0de](https://github.com/dodopayments/dodopayments-node/commit/5e2b0de9a03f8710c8a0668a98f14de8cbfa615e))
* **client:** add support for endpoint-specific base URLs ([be757eb](https://github.com/dodopayments/dodopayments-node/commit/be757ebae2d1a9f0f94a9928b78b62bbdaf35fe1))
* **mcp:** set X-Stainless-MCP header ([b3296b1](https://github.com/dodopayments/dodopayments-node/commit/b3296b109535889fc01687c3134bc3dd5b3846d1))


### Bug Fixes

* publish script — handle NPM errors correctly ([032afdd](https://github.com/dodopayments/dodopayments-node/commit/032afddaf6a48ab218d5f7655644aa668446a708))


### Chores

* **ci:** enable for pull requests ([2330bc5](https://github.com/dodopayments/dodopayments-node/commit/2330bc5595b85c172bb554b8a3ce97d99b0975ff))
* **internal:** make base APIResource abstract ([6101db1](https://github.com/dodopayments/dodopayments-node/commit/6101db10e3e77ef0d0afc9fcec8517fc6f4153b9))
* **mcp:** provides high-level initMcpServer function and exports known clients ([6fe8bae](https://github.com/dodopayments/dodopayments-node/commit/6fe8baeac05503e60ba1a0b2a808530558c62d73))

## 1.32.0 (2025-06-09)

Full Changelog: [v1.30.2...v1.32.0](https://github.com/dodopayments/dodopayments-node/compare/v1.30.2...v1.32.0)

### Features

* **api:** updated openapi spec to v1.32.0 ([7ceb3e7](https://github.com/dodopayments/dodopayments-node/commit/7ceb3e75b8d859ea2d7f5c8004fe7015dc852842))
* **mcp:** implement support for binary responses ([6c7bfef](https://github.com/dodopayments/dodopayments-node/commit/6c7bfef2203036e20b6b9af7fc2d414c6dacab42))

## 1.30.2 (2025-06-04)

Full Changelog: [v1.30.0...v1.30.2](https://github.com/dodopayments/dodopayments-node/compare/v1.30.0...v1.30.2)

### Features

* **api:** fixed openapi spec ([d4e2550](https://github.com/dodopayments/dodopayments-node/commit/d4e255020586557a8f834af37f2f56c8a7195b43))


### Chores

* **docs:** use top-level-await in example snippets ([cafdee2](https://github.com/dodopayments/dodopayments-node/commit/cafdee2532819b55cd0ebf89a51706507bf4c32f))

## 1.30.0 (2025-06-02)

Full Changelog: [v1.27.0...v1.30.0](https://github.com/dodopayments/dodopayments-node/compare/v1.27.0...v1.30.0)

### Features

* **api:** manual updates ([ef4f720](https://github.com/dodopayments/dodopayments-node/commit/ef4f7204bd534590706de090b9ad5ec71fd16ee8))
* **mcp:** include http information in tools ([afdcea8](https://github.com/dodopayments/dodopayments-node/commit/afdcea8dc743b8dcf8ef21a20689cf890573b936))


### Bug Fixes

* **mcp:** include description in dynamic tool search ([8ba2426](https://github.com/dodopayments/dodopayments-node/commit/8ba24264c8fc0c1e2eb456d1dde147f900da24ec))


### Chores

* improve publish-npm script --latest tag logic ([af7339c](https://github.com/dodopayments/dodopayments-node/commit/af7339c2afe0d7bdd016aa9002505188d0cf772d))
* **mcp:** remove duplicate assignment ([c685b50](https://github.com/dodopayments/dodopayments-node/commit/c685b50f407e976988b6ed0b8a9ed87a666c89d0))


### Documentation

* **pagination:** improve naming ([68f8a19](https://github.com/dodopayments/dodopayments-node/commit/68f8a199effe15d04ea0559916de5ade633afdbb))

## 1.27.0 (2025-05-26)

Full Changelog: [v1.25.0...v1.27.0](https://github.com/dodopayments/dodopayments-node/compare/v1.25.0...v1.27.0)

### Features

* **api:** added brands api in our sdk ([19c4592](https://github.com/dodopayments/dodopayments-node/commit/19c459298c508489d28777ca091a92ae11172f83))
* **api:** updated openapi spec to 1.27.0 ([dd3c5b5](https://github.com/dodopayments/dodopayments-node/commit/dd3c5b533e1724357f234c5cf1abc3a0b8d2a410))
* **mcp:** support initializing the server with an "environment" ([fab9bf1](https://github.com/dodopayments/dodopayments-node/commit/fab9bf17e50c8dbfe05e07a2c345e045a3b8d320))


### Bug Fixes

* **mcp:** fix cursor schema transformation issue with recursive references ([cae8015](https://github.com/dodopayments/dodopayments-node/commit/cae8015ffb291ec60a02fa65eb8a1fced3db70b7))


### Chores

* **docs:** grammar improvements ([cea6387](https://github.com/dodopayments/dodopayments-node/commit/cea6387d2d4ebace9551bd1565d6c9097c50a2a4))

## 1.25.0 (2025-05-17)

Full Changelog: [v1.22.0...v1.25.0](https://github.com/dodopayments/dodopayments-node/compare/v1.22.0...v1.25.0)

### Features

* **api:** updated openapi spec ([cb27d71](https://github.com/dodopayments/dodopayments-node/commit/cb27d718d2faccbe1d5636c73ab98246a21d2c55))
* **mcp:** support dynamically discovering and invoking tools for APIs with many endpoints ([ed124f7](https://github.com/dodopayments/dodopayments-node/commit/ed124f74107ad4352ae2bd88b4c56d9d65d668d2))


### Bug Fixes

* **mcp:** explicitly include zod and zod-to-json-schema in package.json ([487260a](https://github.com/dodopayments/dodopayments-node/commit/487260a023d319d98a7a53fd2f17ccc27a0c8115))


### Chores

* **build:** automatically build subpackages if present ([a324a69](https://github.com/dodopayments/dodopayments-node/commit/a324a693d1c3ceaabacf80970b203315c3db3259))
* **internal:** codegen related update ([50a6899](https://github.com/dodopayments/dodopayments-node/commit/50a6899676806c1ce8b64d17f13b120edf5fbf72))
* **tests:** use node 22 for CI tests ([b7aa91b](https://github.com/dodopayments/dodopayments-node/commit/b7aa91b4aabb0676412c8f38aabb2254712a18e1))

## 1.22.0 (2025-05-09)

Full Changelog: [v1.20.0...v1.22.0](https://github.com/dodopayments/dodopayments-node/compare/v1.20.0...v1.22.0)

### Features

* **api:** fixed api key schema to bearer ([0e6de1a](https://github.com/dodopayments/dodopayments-node/commit/0e6de1aa04dc734b3c9a8c669b2d47265ad4f055))
* **api:** manual updates ([e6ef7d2](https://github.com/dodopayments/dodopayments-node/commit/e6ef7d2ae5dab93c474708a1f5320a306288388a))
* **api:** updated openapi spec ([387911f](https://github.com/dodopayments/dodopayments-node/commit/387911fbb74050c3dd06e953bfcdb85a825ba642))


### Bug Fixes

* **mcp:** remove ajv dependency so MCP servers are more compatible with Cloudflare Workers ([6f88e63](https://github.com/dodopayments/dodopayments-node/commit/6f88e632a6f20955584aed3bb78191017ca75508))


### Chores

* **ci:** bump node version for release workflows ([9939000](https://github.com/dodopayments/dodopayments-node/commit/9939000e1d7e59a0af3cfa0251e5dc25256a5e69))
* **internal:** codegen related update ([89b1aae](https://github.com/dodopayments/dodopayments-node/commit/89b1aaefc7a9ce067de4203822fdf3d890418971))
* **internal:** codegen related update ([b39a15c](https://github.com/dodopayments/dodopayments-node/commit/b39a15cf6cc5c87c4b855eb12e22749dfe6ebdbd))
* **internal:** update dependency ([144c131](https://github.com/dodopayments/dodopayments-node/commit/144c1318c336ac715bd47ec94983803ca7d8dac7))


### Documentation

* add examples to tsdocs ([a134ade](https://github.com/dodopayments/dodopayments-node/commit/a134adef9ba75a6e62ed9da80d06a2935a7a4544))

## 1.20.0 (2025-05-01)

Full Changelog: [v1.19.0...v1.20.0](https://github.com/dodopayments/dodopayments-node/compare/v1.19.0...v1.20.0)

### Features

* **api:** added addons ([1e02684](https://github.com/dodopayments/dodopayments-node/commit/1e02684522d2e02e95995880a99856106977e24e))
* **api:** updated readme example ([eaa2425](https://github.com/dodopayments/dodopayments-node/commit/eaa24252f843775f237441d2371f22c8397057ef))
* **api:** updated readme example ([5e589ad](https://github.com/dodopayments/dodopayments-node/commit/5e589ad233c6724dc29ca56d6a673dae5c7caf4a))


### Documentation

* **readme:** fix typo ([a3357ea](https://github.com/dodopayments/dodopayments-node/commit/a3357ea1d18caf29afef209a287e9b87a9d5da9a))

## 1.19.0 (2025-04-30)

Full Changelog: [v1.18.3...v1.19.0](https://github.com/dodopayments/dodopayments-node/compare/v1.18.3...v1.19.0)

### Features

* **api:** manual updates ([14468c8](https://github.com/dodopayments/dodopayments-node/commit/14468c8512bbbc318608007aabce238a6d1f3a1d))
* more gracefully handle $refs and work around schema limitations ([ad64648](https://github.com/dodopayments/dodopayments-node/commit/ad646482ce60d96ae082d795ba917959a516657a))

## 1.18.3 (2025-04-25)

Full Changelog: [v1.18.1...v1.18.3](https://github.com/dodopayments/dodopayments-node/compare/v1.18.1...v1.18.3)

### Features

* **api:** manual updates ([8d9581f](https://github.com/dodopayments/dodopayments-node/commit/8d9581f9eb8596263bc34ba7871ce7b031761546))

## 1.18.1 (2025-04-24)

Full Changelog: [v1.18.0...v1.18.1](https://github.com/dodopayments/dodopayments-node/compare/v1.18.0...v1.18.1)

### Chores

* **ci:** only use depot for staging repos ([2b8cc0d](https://github.com/dodopayments/dodopayments-node/commit/2b8cc0d5d7b754ed4601dfb9143c10078b2867d6))
* **internal:** codegen related update ([1c3419c](https://github.com/dodopayments/dodopayments-node/commit/1c3419c9280a47c975a2c33426baefe2b6de76c4))

## 1.18.0 (2025-04-23)

Full Changelog: [v1.17.0...v1.18.0](https://github.com/dodopayments/dodopayments-node/compare/v1.17.0...v1.18.0)

### Features

* **api:** added change plan api ([b011a8d](https://github.com/dodopayments/dodopayments-node/commit/b011a8d66ddbb1a4b93a9e756f61de7d532835c7))
* **api:** manual updates ([8169c61](https://github.com/dodopayments/dodopayments-node/commit/8169c612f272b446783dc2403702266da6fedca4))


### Chores

* **ci:** add timeout thresholds for CI jobs ([868b836](https://github.com/dodopayments/dodopayments-node/commit/868b83655a0ef02edf81557ddc9f99fff6215c44))

## 1.17.0 (2025-04-22)

Full Changelog: [v1.16.1...v1.17.0](https://github.com/dodopayments/dodopayments-node/compare/v1.16.1...v1.17.0)

### Features

* **api:** manual updates ([d49b776](https://github.com/dodopayments/dodopayments-node/commit/d49b776209703a70508ddfa8e93440e9503e5a37))

## 1.16.1 (2025-04-18)

Full Changelog: [v1.14.1...v1.16.1](https://github.com/dodopayments/dodopayments-node/compare/v1.14.1...v1.16.1)

### Features

* **api:** manual updates ([ef93478](https://github.com/dodopayments/dodopayments-node/commit/ef934783eb972fa15429c4e2c38a2a9a6e2c09fd))

## 1.14.1 (2025-04-15)

Full Changelog: [v1.14.0...v1.14.1](https://github.com/dodopayments/dodopayments-node/compare/v1.14.0...v1.14.1)

### Chores

* **client:** minor internal fixes ([1455033](https://github.com/dodopayments/dodopayments-node/commit/1455033373190788bcfd6548c267cb5a983c8ecd))

## 1.14.0 (2025-04-11)

Full Changelog: [v1.13.0...v1.14.0](https://github.com/dodopayments/dodopayments-node/compare/v1.13.0...v1.14.0)

### Features

* **api:** fixed license key pagination issues in openapi spec ([1dd780f](https://github.com/dodopayments/dodopayments-node/commit/1dd780f589eb52eb55f030b0c86a504d1b269fe6))
* **api:** updated openapi spec ([b2d8c74](https://github.com/dodopayments/dodopayments-node/commit/b2d8c7434a63f075a2fcd802f6fbe1bf8e3c5187))


### Bug Fixes

* **mcp:** fix readEnv type error ([eea8bb0](https://github.com/dodopayments/dodopayments-node/commit/eea8bb0acf4df25b59f050497a6008ca88d839e2))
* **mcp:** include all necessary env vars in client instantiation ([017dc59](https://github.com/dodopayments/dodopayments-node/commit/017dc5984977620c49fa37412493831fa0932121))
* **mcp:** point homepage and repo for mcp package to the `packages/mcp-server` directory ([#116](https://github.com/dodopayments/dodopayments-node/issues/116)) ([1da6385](https://github.com/dodopayments/dodopayments-node/commit/1da63855b41b62dae90e7433ba382bab5a22412c))


### Chores

* **internal:** reduce CI branch coverage ([fffa272](https://github.com/dodopayments/dodopayments-node/commit/fffa27283218143b69abf7ce80c5b8dffe79837e))
* **internal:** upload builds and expand CI branch coverage ([7191c27](https://github.com/dodopayments/dodopayments-node/commit/7191c2763ac1e7d57620d0d208576e792f144fb8))

## 1.13.0 (2025-04-08)

Full Changelog: [v1.12.0...v1.13.0](https://github.com/dodopayments/dodopayments-node/compare/v1.12.0...v1.13.0)

### Features

* **api:** manual updates ([#113](https://github.com/dodopayments/dodopayments-node/issues/113)) ([e891a1b](https://github.com/dodopayments/dodopayments-node/commit/e891a1bb349845db6da1aefbfd78b16856fe4c56))

## 1.12.0 (2025-04-05)

Full Changelog: [v1.11.0...v1.12.0](https://github.com/dodopayments/dodopayments-node/compare/v1.11.0...v1.12.0)

### Bug Fixes

* **api:** improve type resolution when importing as a package ([#108](https://github.com/dodopayments/dodopayments-node/issues/108)) ([29668dc](https://github.com/dodopayments/dodopayments-node/commit/29668dc2a4c9e3b3cbd06b34119b41c751a0b87a))
* **client:** send `X-Stainless-Timeout` in seconds ([#106](https://github.com/dodopayments/dodopayments-node/issues/106)) ([36ecfdf](https://github.com/dodopayments/dodopayments-node/commit/36ecfdfc9558df804e8771ab36ce5f0ce08c7f1f))
* **mcp:** remove unused tools.ts ([#109](https://github.com/dodopayments/dodopayments-node/issues/109)) ([334197e](https://github.com/dodopayments/dodopayments-node/commit/334197e33b5bde9e2d406465cc3713f9919bc55f))


### Chores

* configure new SDK language ([#110](https://github.com/dodopayments/dodopayments-node/issues/110)) ([5f3e4c2](https://github.com/dodopayments/dodopayments-node/commit/5f3e4c2f683fe6f959064e867a206b46915f2703))
* **internal:** add aliases for Record and Array ([#107](https://github.com/dodopayments/dodopayments-node/issues/107)) ([fc97985](https://github.com/dodopayments/dodopayments-node/commit/fc97985e9ae649f33c6e94ef83b31a7967bc320c))

## 1.11.0 (2025-03-28)

Full Changelog: [v1.10.4...v1.11.0](https://github.com/dodopayments/dodopayments-node/compare/v1.10.4...v1.11.0)

### Features

* **api:** manual updates ([#102](https://github.com/dodopayments/dodopayments-node/issues/102)) ([48eecad](https://github.com/dodopayments/dodopayments-node/commit/48eecadd545df3676fa0ab1beea8b925cd04065a))

## 1.10.4 (2025-03-28)

Full Changelog: [v1.10.3...v1.10.4](https://github.com/dodopayments/dodopayments-node/compare/v1.10.3...v1.10.4)

### Bug Fixes

* **internal:** work around https://github.com/vercel/next.js/issues/76881 ([#99](https://github.com/dodopayments/dodopayments-node/issues/99)) ([4c12505](https://github.com/dodopayments/dodopayments-node/commit/4c12505acb178b79157981d9b23e8c4b48577121))

## 1.10.3 (2025-03-25)

Full Changelog: [v1.10.2...v1.10.3](https://github.com/dodopayments/dodopayments-node/compare/v1.10.2...v1.10.3)

### Features

* **api:** manual updates ([#96](https://github.com/dodopayments/dodopayments-node/issues/96)) ([23c1a4e](https://github.com/dodopayments/dodopayments-node/commit/23c1a4e38ddf68ee12b0f6b06b94781b59296d46))

## 1.10.2 (2025-03-22)

Full Changelog: [v1.10.1...v1.10.2](https://github.com/dodopayments/dodopayments-node/compare/v1.10.1...v1.10.2)

### Bug Fixes

* avoid type error in certain environments ([#93](https://github.com/dodopayments/dodopayments-node/issues/93)) ([64b5554](https://github.com/dodopayments/dodopayments-node/commit/64b55549efa34b6c2229d80339455f96ce4cd7b8))

## 1.10.1 (2025-03-21)

Full Changelog: [v1.7.1...v1.10.1](https://github.com/dodopayments/dodopayments-node/compare/v1.7.1...v1.10.1)

### Features

* **api:** updated openapispec to v1.10.1 ([#90](https://github.com/dodopayments/dodopayments-node/issues/90)) ([ece5da1](https://github.com/dodopayments/dodopayments-node/commit/ece5da1e5ce4911aba8ba80030dd74fb6c7d8388))

## 1.7.1 (2025-03-20)

Full Changelog: [v1.7.0...v1.7.1](https://github.com/dodopayments/dodopayments-node/compare/v1.7.0...v1.7.1)

### Chores

* **exports:** cleaner resource index imports ([#85](https://github.com/dodopayments/dodopayments-node/issues/85)) ([cd192bd](https://github.com/dodopayments/dodopayments-node/commit/cd192bd2a53640b91f57023bb4910dfdffc9a5e8))
* **exports:** stop using path fallbacks ([#87](https://github.com/dodopayments/dodopayments-node/issues/87)) ([0573909](https://github.com/dodopayments/dodopayments-node/commit/0573909b4b60a5e9ac8aca7e337c49577c327984))

## 1.7.0 (2025-03-14)

Full Changelog: [v1.6.3...v1.7.0](https://github.com/dodopayments/dodopayments-node/compare/v1.6.3...v1.7.0)

### Features

* **api:** added jsr publishing ([#80](https://github.com/dodopayments/dodopayments-node/issues/80)) ([b1040ec](https://github.com/dodopayments/dodopayments-node/commit/b1040ec22d840493db2e9fa6d0ca75495b69b4e0))
* **api:** fixed openapi spec issues ([#83](https://github.com/dodopayments/dodopayments-node/issues/83)) ([a05a6ff](https://github.com/dodopayments/dodopayments-node/commit/a05a6ff42da3d036aa7d6c5a8ce8409b432b9811))
* **api:** reverted jsr publishing ([#81](https://github.com/dodopayments/dodopayments-node/issues/81)) ([44cce37](https://github.com/dodopayments/dodopayments-node/commit/44cce37d7d6fa1beb28695693b579fe870f88bcf))

## 1.6.3 (2025-03-14)

Full Changelog: [v1.5.1...v1.6.3](https://github.com/dodopayments/dodopayments-node/compare/v1.5.1...v1.6.3)

### Features

* **api:** openapi spec updated ([#77](https://github.com/dodopayments/dodopayments-node/issues/77)) ([683d65e](https://github.com/dodopayments/dodopayments-node/commit/683d65e3f8bdcad333a4fcca2d6206095ebadaf0))
* **api:** updated stainless config ([#78](https://github.com/dodopayments/dodopayments-node/issues/78)) ([f5c0a0c](https://github.com/dodopayments/dodopayments-node/commit/f5c0a0cba2037616c86bfafd755cc6af992ab5af))


### Bug Fixes

* **exports:** ensure resource imports don't require /index ([#76](https://github.com/dodopayments/dodopayments-node/issues/76)) ([81670db](https://github.com/dodopayments/dodopayments-node/commit/81670db550b5c7c5fc9245e7415a338fa06fc826))


### Chores

* **internal:** remove extra empty newlines ([#74](https://github.com/dodopayments/dodopayments-node/issues/74)) ([74fa335](https://github.com/dodopayments/dodopayments-node/commit/74fa33567318e4c36a44c4ee6fd3910a176249e6))

## 1.5.1 (2025-03-12)

Full Changelog: [v1.5.0...v1.5.1](https://github.com/dodopayments/dodopayments-node/compare/v1.5.0...v1.5.1)

### Chores

* **internal:** codegen related update ([#71](https://github.com/dodopayments/dodopayments-node/issues/71)) ([0161d2c](https://github.com/dodopayments/dodopayments-node/commit/0161d2cbfcd68ba4aa16168278a31b286cba2df2))

## 1.5.0 (2025-03-07)

Full Changelog: [v1.0.0...v1.5.0](https://github.com/dodopayments/dodopayments-node/compare/v1.0.0...v1.5.0)

### Features

* **api:** manual updates ([#69](https://github.com/dodopayments/dodopayments-node/issues/69)) ([34a3570](https://github.com/dodopayments/dodopayments-node/commit/34a35708f68a7927d6f1002914f4635e1eb510ef))


### Documentation

* update URLs from stainlessapi.com to stainless.com ([#66](https://github.com/dodopayments/dodopayments-node/issues/66)) ([04fbf67](https://github.com/dodopayments/dodopayments-node/commit/04fbf678cde877da571244736f59eec72e0ebd15))

## 1.0.0 (2025-02-23)

Full Changelog: [v0.24.0...v1.0.0](https://github.com/dodopayments/dodopayments-node/compare/v0.24.0...v1.0.0)

### Features

* **api:** fixed errors ([#64](https://github.com/dodopayments/dodopayments-node/issues/64)) ([0ee82e8](https://github.com/dodopayments/dodopayments-node/commit/0ee82e8cf82b3127bba42a15a339a98ed000d476))
* **api:** updated config and updated version to v1.0.0 ([#63](https://github.com/dodopayments/dodopayments-node/issues/63)) ([ce72618](https://github.com/dodopayments/dodopayments-node/commit/ce72618ac47231097a13546ab60c2847b4e376e0))


### Chores

* **internal:** fix devcontainers setup ([#61](https://github.com/dodopayments/dodopayments-node/issues/61)) ([f43773f](https://github.com/dodopayments/dodopayments-node/commit/f43773f625c1b6d108c28932583aba723f12cd6f))

## 0.24.0 (2025-02-15)

Full Changelog: [v0.22.1...v0.24.0](https://github.com/dodopayments/dodopayments-node/compare/v0.22.1...v0.24.0)

### Features

* **api:** added discount apis ([#59](https://github.com/dodopayments/dodopayments-node/issues/59)) ([ca80ada](https://github.com/dodopayments/dodopayments-node/commit/ca80adaca0ff61a27dcc3024b7e2e985794e3ee0))
* **api:** openapi spec changes ([#58](https://github.com/dodopayments/dodopayments-node/issues/58)) ([fcbf145](https://github.com/dodopayments/dodopayments-node/commit/fcbf145b5039593e6e2dd357947ea970fa77829a))


### Bug Fixes

* **client:** fix export map for index exports ([#56](https://github.com/dodopayments/dodopayments-node/issues/56)) ([87b98a3](https://github.com/dodopayments/dodopayments-node/commit/87b98a3818629e79eb6f2256335eaa4c04a12bc6))

## 0.22.1 (2025-02-11)

Full Changelog: [v0.22.0...v0.22.1](https://github.com/dodopayments/dodopayments-node/compare/v0.22.0...v0.22.1)

### Features

* **api:** manual updates ([#53](https://github.com/dodopayments/dodopayments-node/issues/53)) ([14fa4a1](https://github.com/dodopayments/dodopayments-node/commit/14fa4a155be4f7a973033aefe43a2fc1b132e16a))

## 0.22.0 (2025-02-06)

Full Changelog: [v0.20.1...v0.22.0](https://github.com/dodopayments/dodopayments-node/compare/v0.20.1...v0.22.0)

### Features

* **api:** updated API changes for v0.22.0 ([#51](https://github.com/dodopayments/dodopayments-node/issues/51)) ([d57dec3](https://github.com/dodopayments/dodopayments-node/commit/d57dec3b32be9e3e3e4642a205cae69fe33268f0))
* **client:** send `X-Stainless-Timeout` header ([#49](https://github.com/dodopayments/dodopayments-node/issues/49)) ([432c959](https://github.com/dodopayments/dodopayments-node/commit/432c959909f8e918c387e34a6d4bcb0b70715699))

## 0.20.1 (2025-01-29)

Full Changelog: [v0.19.0...v0.20.1](https://github.com/dodopayments/dodopayments-node/compare/v0.19.0...v0.20.1)

### Features

* **api:** manual updates ([#45](https://github.com/dodopayments/dodopayments-node/issues/45)) ([47bc3a3](https://github.com/dodopayments/dodopayments-node/commit/47bc3a3fdf3de7486b7b8b3bfb15cd5d27226ab0))

## 0.19.0 (2025-01-23)

Full Changelog: [v0.18.0...v0.19.0](https://github.com/dodopayments/dodopayments-node/compare/v0.18.0...v0.19.0)

### Features

* **api:** added archive product api ([#39](https://github.com/dodopayments/dodopayments-node/issues/39)) ([809b126](https://github.com/dodopayments/dodopayments-node/commit/809b126784c606a9fb53863e86efd2268aecb22b))
* **api:** manual updates ([#42](https://github.com/dodopayments/dodopayments-node/issues/42)) ([ff0ba1c](https://github.com/dodopayments/dodopayments-node/commit/ff0ba1cb350db1ac74cd1fce98e1f1d9362306c2))
* **api:** manual updates ([#43](https://github.com/dodopayments/dodopayments-node/issues/43)) ([414cf72](https://github.com/dodopayments/dodopayments-node/commit/414cf724ea2903ed69d3240ccd942fb5f3606121))


### Chores

* **internal:** add test ([#41](https://github.com/dodopayments/dodopayments-node/issues/41)) ([c34b584](https://github.com/dodopayments/dodopayments-node/commit/c34b584d916f115cfb3e991fe9fb1cc8d5bc59f4))

## 0.18.0 (2025-01-20)

Full Changelog: [v0.17.0...v0.18.0](https://github.com/dodopayments/dodopayments-node/compare/v0.17.0...v0.18.0)

### Features

* **api:** updated openapi sepc ([#38](https://github.com/dodopayments/dodopayments-node/issues/38)) ([9682295](https://github.com/dodopayments/dodopayments-node/commit/96822951e14f7183a3375769cf1ef26877bc7d58))


### Chores

* **internal:** codegen related update ([#36](https://github.com/dodopayments/dodopayments-node/issues/36)) ([b954c61](https://github.com/dodopayments/dodopayments-node/commit/b954c61dfb4795c48fb6a8ff187a60320fe008b7))

## 0.17.0 (2025-01-16)

Full Changelog: [v0.16.1...v0.17.0](https://github.com/dodopayments/dodopayments-node/compare/v0.16.1...v0.17.0)

### Features

* **api:** added filter apis ([#33](https://github.com/dodopayments/dodopayments-node/issues/33)) ([0f7e77a](https://github.com/dodopayments/dodopayments-node/commit/0f7e77aa66dbc79df5718453e07287e264e5c471))

## 0.16.1 (2025-01-11)

Full Changelog: [v0.15.1...v0.16.1](https://github.com/dodopayments/dodopayments-node/compare/v0.15.1...v0.16.1)

### Features

* **api:** updated openapi spec ([#31](https://github.com/dodopayments/dodopayments-node/issues/31)) ([871b563](https://github.com/dodopayments/dodopayments-node/commit/871b5633328c91c510f98eaedf25593d010f30a4))


### Chores

* **internal:** change formatting ([#30](https://github.com/dodopayments/dodopayments-node/issues/30)) ([03737c3](https://github.com/dodopayments/dodopayments-node/commit/03737c3da27ac25c0250abfea2adf2a69a738abf))
* **internal:** codegen related update ([#28](https://github.com/dodopayments/dodopayments-node/issues/28)) ([2d46103](https://github.com/dodopayments/dodopayments-node/commit/2d461037e47846a19e9a48377c3a165140c0b424))

## 0.15.1 (2025-01-03)

Full Changelog: [v0.14.1...v0.15.1](https://github.com/dodopayments/dodopayments-node/compare/v0.14.1...v0.15.1)

### Features

* **api:** added invoice api and update openapi spec ([#26](https://github.com/dodopayments/dodopayments-node/issues/26)) ([1c3ecfa](https://github.com/dodopayments/dodopayments-node/commit/1c3ecfa0e702fe6ec5013f385999aefcb89664d5))


### Chores

* **internal:** codegen related update ([#24](https://github.com/dodopayments/dodopayments-node/issues/24)) ([37ceb8a](https://github.com/dodopayments/dodopayments-node/commit/37ceb8af59343cec5979074f2983f8382e61f19a))

## 0.14.1 (2024-12-29)

Full Changelog: [v0.14.0...v0.14.1](https://github.com/dodopayments/dodopayments-node/compare/v0.14.0...v0.14.1)

### Features

* **api:** manual updates ([#21](https://github.com/dodopayments/dodopayments-node/issues/21)) ([a97c2e1](https://github.com/dodopayments/dodopayments-node/commit/a97c2e1f7660fad78220af356041dead9a03a4f8))

## 0.14.0 (2024-12-25)

Full Changelog: [v0.13.2...v0.14.0](https://github.com/dodopayments/dodopayments-node/compare/v0.13.2...v0.14.0)

### Features

* **api:** updated openapi spec for License Keys ([#18](https://github.com/dodopayments/dodopayments-node/issues/18)) ([cf81c5d](https://github.com/dodopayments/dodopayments-node/commit/cf81c5d12aadb61fcdc933341c4089bbfd04739a))

## 0.13.2 (2024-12-21)

Full Changelog: [v0.12.0...v0.13.2](https://github.com/dodopayments/dodopayments-node/compare/v0.12.0...v0.13.2)

### Bug Fixes

* **client:** normalize method ([#15](https://github.com/dodopayments/dodopayments-node/issues/15)) ([44ff1cd](https://github.com/dodopayments/dodopayments-node/commit/44ff1cd212e3c4cbb920a76cb0471f3490e35d47))


### Chores

* **internal:** codegen related update ([#16](https://github.com/dodopayments/dodopayments-node/issues/16)) ([4cfac0c](https://github.com/dodopayments/dodopayments-node/commit/4cfac0c19d65136f19efcf26d1174d52a64517ab))
* **internal:** fix some typos ([#13](https://github.com/dodopayments/dodopayments-node/issues/13)) ([d419e43](https://github.com/dodopayments/dodopayments-node/commit/d419e432fd48f5dbfe92c7da082d9bb13283e2c8))

## 0.12.0 (2024-12-17)

Full Changelog: [v0.11.1...v0.12.0](https://github.com/dodopayments/dodopayments-node/compare/v0.11.1...v0.12.0)

### Features

* **api:** api update ([#9](https://github.com/dodopayments/dodopayments-node/issues/9)) ([eb67c8c](https://github.com/dodopayments/dodopayments-node/commit/eb67c8c159e56a2123915397279d47c93541e349))
* **api:** updated openapi methods ([#11](https://github.com/dodopayments/dodopayments-node/issues/11)) ([bb5d991](https://github.com/dodopayments/dodopayments-node/commit/bb5d991c1341b3fb6f92a4ada2ad5b06778023ae))

## 0.11.1 (2024-12-16)

Full Changelog: [v0.11.0...v0.11.1](https://github.com/dodopayments/dodopayments-node/compare/v0.11.0...v0.11.1)

### Features

* **api:** manual updates ([#6](https://github.com/dodopayments/dodopayments-node/issues/6)) ([3f7895c](https://github.com/dodopayments/dodopayments-node/commit/3f7895c88c11962bd4f63c63f561b5f82768a5bc))

## 0.11.0 (2024-12-16)

Full Changelog: [v0.0.1-alpha.0...v0.11.0](https://github.com/dodopayments/dodopayments-node/compare/v0.0.1-alpha.0...v0.11.0)

### Features

* **api:** update via SDK Studio ([3c8c120](https://github.com/dodopayments/dodopayments-node/commit/3c8c1207491653be794ef19f6c88685ea9ea25fc))
* **api:** update via SDK Studio ([2187350](https://github.com/dodopayments/dodopayments-node/commit/21873500053ab57c7e6896794f19cb02dd8f6ef2))
* **api:** update via SDK Studio ([b6a4997](https://github.com/dodopayments/dodopayments-node/commit/b6a4997533b095682c53b3cad7d45511989c0660))
* **api:** update via SDK Studio ([e7ee0bd](https://github.com/dodopayments/dodopayments-node/commit/e7ee0bd60f63a0d616546058c095b403d55e75ea))
* **api:** update via SDK Studio ([e69d96d](https://github.com/dodopayments/dodopayments-node/commit/e69d96d3f52a8b4de4cd59a2ee844d518335316d))
* **api:** update via SDK Studio ([cd1786f](https://github.com/dodopayments/dodopayments-node/commit/cd1786fb59450d77997302593a67f208652701ea))
* **api:** update via SDK Studio ([2b8c5a2](https://github.com/dodopayments/dodopayments-node/commit/2b8c5a21824a80d4cd8967b9e30464037cbca83a))
* **api:** update via SDK Studio ([ecd2ce8](https://github.com/dodopayments/dodopayments-node/commit/ecd2ce841aca90eb6853c6d96d734f6bde19b792))


### Chores

* go live ([#1](https://github.com/dodopayments/dodopayments-node/issues/1)) ([0ee38c7](https://github.com/dodopayments/dodopayments-node/commit/0ee38c7ef6ab3bb8057711aeeee1ddb381805775))
* update SDK settings ([#3](https://github.com/dodopayments/dodopayments-node/issues/3)) ([99f2b94](https://github.com/dodopayments/dodopayments-node/commit/99f2b94294e5b5dd5dc6eed57244b1b976858adf))

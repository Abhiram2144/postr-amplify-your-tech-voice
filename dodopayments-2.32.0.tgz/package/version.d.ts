export declare const VERSION = "2.32.0";
//# sourceMappingURL=version.d.ts.map
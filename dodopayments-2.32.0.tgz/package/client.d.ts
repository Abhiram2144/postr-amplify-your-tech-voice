import type { RequestInit, RequestInfo } from "./internal/builtin-types.js";
import type { PromiseOrValue, MergedRequestInit, FinalizedRequestInit } from "./internal/types.js";
export type { Logger, LogLevel } from "./internal/utils/log.js";
import * as Opts from "./internal/request-options.js";
import * as Errors from "./core/error.js";
import * as Pagination from "./core/pagination.js";
import { type CursorPagePaginationParams, CursorPagePaginationResponse, type DefaultPageNumberPaginationParams, DefaultPageNumberPaginationResponse } from "./core/pagination.js";
import * as Uploads from "./core/uploads.js";
import * as API from "./resources/index.js";
import { APIPromise } from "./core/api-promise.js";
import { AddonCreateParams, AddonListParams, AddonResponse, AddonResponsesDefaultPageNumberPagination, AddonUpdateImagesResponse, AddonUpdateParams, Addons } from "./resources/addons.js";
import { BalanceLedgerEntriesDefaultPageNumberPagination, BalanceLedgerEntry, BalanceRetrieveLedgerParams, Balances } from "./resources/balances.js";
import { Brand, BrandCreateParams, BrandListResponse, BrandUpdateImagesResponse, BrandUpdateParams, Brands } from "./resources/brands.js";
import { CheckoutSessionBillingAddress, CheckoutSessionCreateParams, CheckoutSessionCustomization, CheckoutSessionFlags, CheckoutSessionPreviewParams, CheckoutSessionPreviewResponse, CheckoutSessionRequest, CheckoutSessionResponse, CheckoutSessionStatus, CheckoutSessions, CustomField, ProductItemReq, SubscriptionData, ThemeConfig, ThemeModeConfig } from "./resources/checkout-sessions.js";
import { Discount, DiscountCreateParams, DiscountDetail, DiscountListParams, DiscountType, DiscountUpdateParams, Discounts, DiscountsDefaultPageNumberPagination } from "./resources/discounts.js";
import { Dispute, DisputeListParams, DisputeListResponse, DisputeListResponsesDefaultPageNumberPagination, DisputeStage, DisputeStatus, Disputes, GetDispute } from "./resources/disputes.js";
import { LicenseKeyInstance, LicenseKeyInstanceListParams, LicenseKeyInstanceUpdateParams, LicenseKeyInstances, LicenseKeyInstancesDefaultPageNumberPagination } from "./resources/license-key-instances.js";
import { LicenseKey, LicenseKeyCreateParams, LicenseKeyListParams, LicenseKeyStatus, LicenseKeyUpdateParams, LicenseKeys, LicenseKeysDefaultPageNumberPagination } from "./resources/license-keys.js";
import { LicenseActivateParams, LicenseActivateResponse, LicenseDeactivateParams, LicenseValidateParams, LicenseValidateResponse, Licenses } from "./resources/licenses.js";
import { Conjunction, FilterOperator, FilterType, Meter, MeterAggregation, MeterCreateParams, MeterFilter, MeterListParams, Meters, MetersDefaultPageNumberPagination } from "./resources/meters.js";
import { CountryCode, Currency, Misc, MiscListSupportedCountriesResponse, TaxCategory } from "./resources/misc.js";
import { AttachExistingCustomer, BillingAddress, CreateNewCustomer, CustomFieldResponse, CustomerLimitedDetails, CustomerRequest, IntentStatus, NewCustomer, OneTimeProductCartItem, Payment, PaymentCreateParams, PaymentCreateResponse, PaymentListParams, PaymentListResponse, PaymentListResponsesDefaultPageNumberPagination, PaymentMethodTypes, PaymentRefundStatus, PaymentRetrieveLineItemsResponse, Payments, RefundListItem } from "./resources/payments.js";
import { Refund, RefundCreateParams, RefundListParams, RefundStatus, Refunds } from "./resources/refunds.js";
import { AddonCartResponseItem, AttachAddon, CancellationFeedback, CreditEntitlementCartResponse, MeterCartResponseItem, MeterCreditEntitlementCartResponse, OnDemandSubscription, ScheduledPlanChange, Subscription, SubscriptionChangePlanParams, SubscriptionChargeParams, SubscriptionChargeResponse, SubscriptionCreateParams, SubscriptionCreateResponse, SubscriptionListParams, SubscriptionListResponse, SubscriptionListResponsesDefaultPageNumberPagination, SubscriptionPreviewChangePlanParams, SubscriptionPreviewChangePlanResponse, SubscriptionRetrieveCreditUsageResponse, SubscriptionRetrieveUsageHistoryParams, SubscriptionRetrieveUsageHistoryResponse, SubscriptionRetrieveUsageHistoryResponsesDefaultPageNumberPagination, SubscriptionStatus, SubscriptionUpdateParams, SubscriptionUpdatePaymentMethodParams, SubscriptionUpdatePaymentMethodResponse, Subscriptions, TimeInterval, UpdateSubscriptionPlanReq } from "./resources/subscriptions.js";
import { Event, EventInput, EventsDefaultPageNumberPagination, UsageEventIngestParams, UsageEventIngestResponse, UsageEventListParams, UsageEvents } from "./resources/usage-events.js";
import { WebhookEventType, WebhookEvents, WebhookPayload } from "./resources/webhook-events.js";
import { CbbOverageBehavior, CreditEntitlement, CreditEntitlementCreateParams, CreditEntitlementListParams, CreditEntitlementUpdateParams, CreditEntitlements, CreditEntitlementsDefaultPageNumberPagination } from "./resources/credit-entitlements/credit-entitlements.js";
import { Customer, CustomerCreateParams, CustomerDeletePaymentMethodParams, CustomerListCreditEntitlementsResponse, CustomerListEntitlementsResponse, CustomerListParams, CustomerPortalSession, CustomerRetrievePaymentMethodsResponse, CustomerUpdateParams, Customers, CustomersDefaultPageNumberPagination } from "./resources/customers/customers.js";
import { Entitlement, EntitlementCreateParams, EntitlementIntegrationType, EntitlementListParams, EntitlementUpdateParams, Entitlements, EntitlementsDefaultPageNumberPagination, GitHubPermission, IntegrationConfig, IntegrationConfigResponse } from "./resources/entitlements/entitlements.js";
import { Invoices } from "./resources/invoices/invoices.js";
import { PayoutListParams, PayoutListResponse, PayoutListResponsesDefaultPageNumberPagination, Payouts } from "./resources/payouts/payouts.js";
import { ProductCollection, ProductCollectionCreateParams, ProductCollectionListParams, ProductCollectionListResponse, ProductCollectionListResponsesDefaultPageNumberPagination, ProductCollectionUnarchiveResponse, ProductCollectionUpdateImagesParams, ProductCollectionUpdateImagesResponse, ProductCollectionUpdateParams, ProductCollections } from "./resources/product-collections/product-collections.js";
import { AddMeterToPrice, AttachCreditEntitlement, AttachProductEntitlement, CbbProrationBehavior, CreditEntitlementMappingResponse, DigitalProductDelivery, DigitalProductDeliveryFile, LicenseKeyDuration, Price, Product, ProductCreateParams, ProductEntitlementSummary, ProductListParams, ProductListResponse, ProductListResponsesDefaultPageNumberPagination, ProductUpdateFilesParams, ProductUpdateFilesResponse, ProductUpdateParams, Products } from "./resources/products/products.js";
import { AbandonedCheckoutDetectedWebhookEvent, AbandonedCheckoutRecoveredWebhookEvent, CreditAddedWebhookEvent, CreditBalanceLowWebhookEvent, CreditDeductedWebhookEvent, CreditExpiredWebhookEvent, CreditManualAdjustmentWebhookEvent, CreditOverageChargedWebhookEvent, CreditOverageResetWebhookEvent, CreditRolledOverWebhookEvent, CreditRolloverForfeitedWebhookEvent, DisputeAcceptedWebhookEvent, DisputeCancelledWebhookEvent, DisputeChallengedWebhookEvent, DisputeExpiredWebhookEvent, DisputeLostWebhookEvent, DisputeOpenedWebhookEvent, DisputeWonWebhookEvent, DunningRecoveredWebhookEvent, DunningStartedWebhookEvent, EntitlementGrantCreatedWebhookEvent, EntitlementGrantDeliveredWebhookEvent, EntitlementGrantFailedWebhookEvent, EntitlementGrantRevokedWebhookEvent, LicenseKeyCreatedWebhookEvent, PaymentCancelledWebhookEvent, PaymentFailedWebhookEvent, PaymentProcessingWebhookEvent, PaymentSucceededWebhookEvent, RefundFailedWebhookEvent, RefundSucceededWebhookEvent, SubscriptionActiveWebhookEvent, SubscriptionCancelledWebhookEvent, SubscriptionExpiredWebhookEvent, SubscriptionFailedWebhookEvent, SubscriptionOnHoldWebhookEvent, SubscriptionPlanChangedWebhookEvent, SubscriptionRenewedWebhookEvent, SubscriptionUpdatedWebhookEvent, UnsafeUnwrapWebhookEvent, UnwrapWebhookEvent, WebhookCreateParams, WebhookDetails, WebhookDetailsCursorPagePagination, WebhookListParams, WebhookRetrieveSecretResponse, WebhookUpdateParams, Webhooks } from "./resources/webhooks/webhooks.js";
import { type Fetch } from "./internal/builtin-types.js";
import { HeadersLike, NullableHeaders } from "./internal/headers.js";
import { FinalRequestOptions, RequestOptions } from "./internal/request-options.js";
import { type LogLevel, type Logger } from "./internal/utils/log.js";
declare const environments: {
    live_mode: string;
    test_mode: string;
};
type Environment = keyof typeof environments;
export interface ClientOptions {
    /**
     * Bearer Token for API authentication
     */
    bearerToken?: string | undefined;
    /**
     * Defaults to process.env['DODO_PAYMENTS_WEBHOOK_KEY'].
     */
    webhookKey?: string | null | undefined;
    /**
     * Specifies the environment to use for the API.
     *
     * Each environment maps to a different base URL:
     * - `live_mode` corresponds to `https://live.dodopayments.com`
     * - `test_mode` corresponds to `https://test.dodopayments.com`
     */
    environment?: Environment | undefined;
    /**
     * Override the default base URL for the API, e.g., "https://api.example.com/v2/"
     *
     * Defaults to process.env['DODO_PAYMENTS_BASE_URL'].
     */
    baseURL?: string | null | undefined;
    /**
     * The maximum amount of time (in milliseconds) that the client should wait for a response
     * from the server before timing out a single request.
     *
     * Note that request timeouts are retried by default, so in a worst-case scenario you may wait
     * much longer than this timeout before the promise succeeds or fails.
     *
     * @unit milliseconds
     */
    timeout?: number | undefined;
    /**
     * Additional `RequestInit` options to be passed to `fetch` calls.
     * Properties will be overridden by per-request `fetchOptions`.
     */
    fetchOptions?: MergedRequestInit | undefined;
    /**
     * Specify a custom `fetch` function implementation.
     *
     * If not provided, we expect that `fetch` is defined globally.
     */
    fetch?: Fetch | undefined;
    /**
     * The maximum number of times that the client will retry a request in case of a
     * temporary failure, like a network error or a 5XX error from the server.
     *
     * @default 2
     */
    maxRetries?: number | undefined;
    /**
     * Default headers to include with every request to the API.
     *
     * These can be removed in individual requests by explicitly setting the
     * header to `null` in request options.
     */
    defaultHeaders?: HeadersLike | undefined;
    /**
     * Default query parameters to include with every request to the API.
     *
     * These can be removed in individual requests by explicitly setting the
     * param to `undefined` in request options.
     */
    defaultQuery?: Record<string, string | undefined> | undefined;
    /**
     * Set the log level.
     *
     * Defaults to process.env['DODO_PAYMENTS_LOG'] or 'warn' if it isn't set.
     */
    logLevel?: LogLevel | undefined;
    /**
     * Set the logger.
     *
     * Defaults to globalThis.console.
     */
    logger?: Logger | undefined;
}
/**
 * API Client for interfacing with the Dodo Payments API.
 */
export declare class DodoPayments {
    #private;
    bearerToken: string;
    webhookKey: string | null;
    baseURL: string;
    maxRetries: number;
    timeout: number;
    logger: Logger;
    logLevel: LogLevel | undefined;
    fetchOptions: MergedRequestInit | undefined;
    private fetch;
    protected idempotencyHeader?: string;
    private _options;
    /**
     * API Client for interfacing with the Dodo Payments API.
     *
     * @param {string | undefined} [opts.bearerToken=process.env['DODO_PAYMENTS_API_KEY'] ?? undefined]
     * @param {string | null | undefined} [opts.webhookKey=process.env['DODO_PAYMENTS_WEBHOOK_KEY'] ?? null]
     * @param {Environment} [opts.environment=live_mode] - Specifies the environment URL to use for the API.
     * @param {string} [opts.baseURL=process.env['DODO_PAYMENTS_BASE_URL'] ?? https://live.dodopayments.com] - Override the default base URL for the API.
     * @param {number} [opts.timeout=1 minute] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
     * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
     */
    constructor({ baseURL, bearerToken, webhookKey, ...opts }?: ClientOptions);
    /**
     * Create a new client instance re-using the same options given to the current client with optional overriding.
     */
    withOptions(options: Partial<ClientOptions>): this;
    protected defaultQuery(): Record<string, string | undefined> | undefined;
    protected validateHeaders({ values, nulls }: NullableHeaders): void;
    protected authHeaders(opts: FinalRequestOptions): Promise<NullableHeaders | undefined>;
    /**
     * Basic re-implementation of `qs.stringify` for primitive types.
     */
    protected stringifyQuery(query: object | Record<string, unknown>): string;
    private getUserAgent;
    protected defaultIdempotencyKey(): string;
    protected makeStatusError(status: number, error: Object, message: string | undefined, headers: Headers): Errors.APIError;
    buildURL(path: string, query: Record<string, unknown> | null | undefined, defaultBaseURL?: string | undefined): string;
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    protected prepareOptions(options: FinalRequestOptions): Promise<void>;
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     */
    protected prepareRequest(request: RequestInit, { url, options }: {
        url: string;
        options: FinalRequestOptions;
    }): Promise<void>;
    get<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    post<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    patch<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    put<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    delete<Rsp>(path: string, opts?: PromiseOrValue<RequestOptions>): APIPromise<Rsp>;
    private methodRequest;
    request<Rsp>(options: PromiseOrValue<FinalRequestOptions>, remainingRetries?: number | null): APIPromise<Rsp>;
    private makeRequest;
    getAPIList<Item, PageClass extends Pagination.AbstractPage<Item> = Pagination.AbstractPage<Item>>(path: string, Page: new (...args: any[]) => PageClass, opts?: PromiseOrValue<RequestOptions>): Pagination.PagePromise<PageClass, Item>;
    requestAPIList<Item = unknown, PageClass extends Pagination.AbstractPage<Item> = Pagination.AbstractPage<Item>>(Page: new (...args: ConstructorParameters<typeof Pagination.AbstractPage>) => PageClass, options: PromiseOrValue<FinalRequestOptions>): Pagination.PagePromise<PageClass, Item>;
    fetchWithTimeout(url: RequestInfo, init: RequestInit | undefined, ms: number, controller: AbortController): Promise<Response>;
    private shouldRetry;
    private retryRequest;
    private calculateDefaultRetryTimeoutMillis;
    buildRequest(inputOptions: FinalRequestOptions, { retryCount }?: {
        retryCount?: number;
    }): Promise<{
        req: FinalizedRequestInit;
        url: string;
        timeout: number;
    }>;
    private buildHeaders;
    private _makeAbort;
    private buildBody;
    static DodoPayments: typeof DodoPayments;
    static DEFAULT_TIMEOUT: number;
    static DodoPaymentsError: typeof Errors.DodoPaymentsError;
    static APIError: typeof Errors.APIError;
    static APIConnectionError: typeof Errors.APIConnectionError;
    static APIConnectionTimeoutError: typeof Errors.APIConnectionTimeoutError;
    static APIUserAbortError: typeof Errors.APIUserAbortError;
    static NotFoundError: typeof Errors.NotFoundError;
    static ConflictError: typeof Errors.ConflictError;
    static RateLimitError: typeof Errors.RateLimitError;
    static BadRequestError: typeof Errors.BadRequestError;
    static AuthenticationError: typeof Errors.AuthenticationError;
    static InternalServerError: typeof Errors.InternalServerError;
    static PermissionDeniedError: typeof Errors.PermissionDeniedError;
    static UnprocessableEntityError: typeof Errors.UnprocessableEntityError;
    static toFile: typeof Uploads.toFile;
    checkoutSessions: API.CheckoutSessions;
    payments: API.Payments;
    subscriptions: API.Subscriptions;
    invoices: API.Invoices;
    licenses: API.Licenses;
    licenseKeys: API.LicenseKeys;
    licenseKeyInstances: API.LicenseKeyInstances;
    customers: API.Customers;
    refunds: API.Refunds;
    disputes: API.Disputes;
    payouts: API.Payouts;
    products: API.Products;
    misc: API.Misc;
    discounts: API.Discounts;
    addons: API.Addons;
    brands: API.Brands;
    webhooks: API.Webhooks;
    webhookEvents: API.WebhookEvents;
    usageEvents: API.UsageEvents;
    meters: API.Meters;
    balances: API.Balances;
    creditEntitlements: API.CreditEntitlements;
    entitlements: API.Entitlements;
    productCollections: API.ProductCollections;
}
export declare namespace DodoPayments {
    export type RequestOptions = Opts.RequestOptions;
    export import DefaultPageNumberPagination = Pagination.DefaultPageNumberPagination;
    export { type DefaultPageNumberPaginationParams as DefaultPageNumberPaginationParams, type DefaultPageNumberPaginationResponse as DefaultPageNumberPaginationResponse, };
    export import CursorPagePagination = Pagination.CursorPagePagination;
    export { type CursorPagePaginationParams as CursorPagePaginationParams, type CursorPagePaginationResponse as CursorPagePaginationResponse, };
    export { CheckoutSessions as CheckoutSessions, type CheckoutSessionBillingAddress as CheckoutSessionBillingAddress, type CheckoutSessionCustomization as CheckoutSessionCustomization, type CheckoutSessionFlags as CheckoutSessionFlags, type CheckoutSessionRequest as CheckoutSessionRequest, type CheckoutSessionResponse as CheckoutSessionResponse, type CheckoutSessionStatus as CheckoutSessionStatus, type CustomField as CustomField, type ProductItemReq as ProductItemReq, type SubscriptionData as SubscriptionData, type ThemeConfig as ThemeConfig, type ThemeModeConfig as ThemeModeConfig, type CheckoutSessionPreviewResponse as CheckoutSessionPreviewResponse, type CheckoutSessionCreateParams as CheckoutSessionCreateParams, type CheckoutSessionPreviewParams as CheckoutSessionPreviewParams, };
    export { Payments as Payments, type AttachExistingCustomer as AttachExistingCustomer, type BillingAddress as BillingAddress, type CreateNewCustomer as CreateNewCustomer, type CustomFieldResponse as CustomFieldResponse, type CustomerLimitedDetails as CustomerLimitedDetails, type CustomerRequest as CustomerRequest, type IntentStatus as IntentStatus, type NewCustomer as NewCustomer, type OneTimeProductCartItem as OneTimeProductCartItem, type Payment as Payment, type PaymentMethodTypes as PaymentMethodTypes, type PaymentRefundStatus as PaymentRefundStatus, type RefundListItem as RefundListItem, type PaymentCreateResponse as PaymentCreateResponse, type PaymentListResponse as PaymentListResponse, type PaymentRetrieveLineItemsResponse as PaymentRetrieveLineItemsResponse, type PaymentListResponsesDefaultPageNumberPagination as PaymentListResponsesDefaultPageNumberPagination, type PaymentCreateParams as PaymentCreateParams, type PaymentListParams as PaymentListParams, };
    export { Subscriptions as Subscriptions, type AddonCartResponseItem as AddonCartResponseItem, type AttachAddon as AttachAddon, type CancellationFeedback as CancellationFeedback, type CreditEntitlementCartResponse as CreditEntitlementCartResponse, type MeterCartResponseItem as MeterCartResponseItem, type MeterCreditEntitlementCartResponse as MeterCreditEntitlementCartResponse, type OnDemandSubscription as OnDemandSubscription, type ScheduledPlanChange as ScheduledPlanChange, type Subscription as Subscription, type SubscriptionStatus as SubscriptionStatus, type TimeInterval as TimeInterval, type UpdateSubscriptionPlanReq as UpdateSubscriptionPlanReq, type SubscriptionCreateResponse as SubscriptionCreateResponse, type SubscriptionListResponse as SubscriptionListResponse, type SubscriptionChargeResponse as SubscriptionChargeResponse, type SubscriptionPreviewChangePlanResponse as SubscriptionPreviewChangePlanResponse, type SubscriptionRetrieveCreditUsageResponse as SubscriptionRetrieveCreditUsageResponse, type SubscriptionRetrieveUsageHistoryResponse as SubscriptionRetrieveUsageHistoryResponse, type SubscriptionUpdatePaymentMethodResponse as SubscriptionUpdatePaymentMethodResponse, type SubscriptionListResponsesDefaultPageNumberPagination as SubscriptionListResponsesDefaultPageNumberPagination, type SubscriptionRetrieveUsageHistoryResponsesDefaultPageNumberPagination as SubscriptionRetrieveUsageHistoryResponsesDefaultPageNumberPagination, type SubscriptionCreateParams as SubscriptionCreateParams, type SubscriptionUpdateParams as SubscriptionUpdateParams, type SubscriptionListParams as SubscriptionListParams, type SubscriptionChangePlanParams as SubscriptionChangePlanParams, type SubscriptionChargeParams as SubscriptionChargeParams, type SubscriptionPreviewChangePlanParams as SubscriptionPreviewChangePlanParams, type SubscriptionRetrieveUsageHistoryParams as SubscriptionRetrieveUsageHistoryParams, type SubscriptionUpdatePaymentMethodParams as SubscriptionUpdatePaymentMethodParams, };
    export { Invoices as Invoices };
    export { Licenses as Licenses, type LicenseActivateResponse as LicenseActivateResponse, type LicenseValidateResponse as LicenseValidateResponse, type LicenseActivateParams as LicenseActivateParams, type LicenseDeactivateParams as LicenseDeactivateParams, type LicenseValidateParams as LicenseValidateParams, };
    export { LicenseKeys as LicenseKeys, type LicenseKey as LicenseKey, type LicenseKeyStatus as LicenseKeyStatus, type LicenseKeysDefaultPageNumberPagination as LicenseKeysDefaultPageNumberPagination, type LicenseKeyCreateParams as LicenseKeyCreateParams, type LicenseKeyUpdateParams as LicenseKeyUpdateParams, type LicenseKeyListParams as LicenseKeyListParams, };
    export { LicenseKeyInstances as LicenseKeyInstances, type LicenseKeyInstance as LicenseKeyInstance, type LicenseKeyInstancesDefaultPageNumberPagination as LicenseKeyInstancesDefaultPageNumberPagination, type LicenseKeyInstanceUpdateParams as LicenseKeyInstanceUpdateParams, type LicenseKeyInstanceListParams as LicenseKeyInstanceListParams, };
    export { Customers as Customers, type Customer as Customer, type CustomerPortalSession as CustomerPortalSession, type CustomerListCreditEntitlementsResponse as CustomerListCreditEntitlementsResponse, type CustomerListEntitlementsResponse as CustomerListEntitlementsResponse, type CustomerRetrievePaymentMethodsResponse as CustomerRetrievePaymentMethodsResponse, type CustomersDefaultPageNumberPagination as CustomersDefaultPageNumberPagination, type CustomerCreateParams as CustomerCreateParams, type CustomerUpdateParams as CustomerUpdateParams, type CustomerListParams as CustomerListParams, type CustomerDeletePaymentMethodParams as CustomerDeletePaymentMethodParams, };
    export { Refunds as Refunds, type Refund as Refund, type RefundStatus as RefundStatus, type RefundCreateParams as RefundCreateParams, type RefundListParams as RefundListParams, };
    export { Disputes as Disputes, type Dispute as Dispute, type DisputeStage as DisputeStage, type DisputeStatus as DisputeStatus, type GetDispute as GetDispute, type DisputeListResponse as DisputeListResponse, type DisputeListResponsesDefaultPageNumberPagination as DisputeListResponsesDefaultPageNumberPagination, type DisputeListParams as DisputeListParams, };
    export { Payouts as Payouts, type PayoutListResponse as PayoutListResponse, type PayoutListResponsesDefaultPageNumberPagination as PayoutListResponsesDefaultPageNumberPagination, type PayoutListParams as PayoutListParams, };
    export { Products as Products, type AddMeterToPrice as AddMeterToPrice, type AttachCreditEntitlement as AttachCreditEntitlement, type AttachProductEntitlement as AttachProductEntitlement, type CbbProrationBehavior as CbbProrationBehavior, type CreditEntitlementMappingResponse as CreditEntitlementMappingResponse, type DigitalProductDelivery as DigitalProductDelivery, type DigitalProductDeliveryFile as DigitalProductDeliveryFile, type LicenseKeyDuration as LicenseKeyDuration, type Price as Price, type Product as Product, type ProductEntitlementSummary as ProductEntitlementSummary, type ProductListResponse as ProductListResponse, type ProductUpdateFilesResponse as ProductUpdateFilesResponse, type ProductListResponsesDefaultPageNumberPagination as ProductListResponsesDefaultPageNumberPagination, type ProductCreateParams as ProductCreateParams, type ProductUpdateParams as ProductUpdateParams, type ProductListParams as ProductListParams, type ProductUpdateFilesParams as ProductUpdateFilesParams, };
    export { Misc as Misc, type CountryCode as CountryCode, type Currency as Currency, type TaxCategory as TaxCategory, type MiscListSupportedCountriesResponse as MiscListSupportedCountriesResponse, };
    export { Discounts as Discounts, type Discount as Discount, type DiscountDetail as DiscountDetail, type DiscountType as DiscountType, type DiscountsDefaultPageNumberPagination as DiscountsDefaultPageNumberPagination, type DiscountCreateParams as DiscountCreateParams, type DiscountUpdateParams as DiscountUpdateParams, type DiscountListParams as DiscountListParams, };
    export { Addons as Addons, type AddonResponse as AddonResponse, type AddonUpdateImagesResponse as AddonUpdateImagesResponse, type AddonResponsesDefaultPageNumberPagination as AddonResponsesDefaultPageNumberPagination, type AddonCreateParams as AddonCreateParams, type AddonUpdateParams as AddonUpdateParams, type AddonListParams as AddonListParams, };
    export { Brands as Brands, type Brand as Brand, type BrandListResponse as BrandListResponse, type BrandUpdateImagesResponse as BrandUpdateImagesResponse, type BrandCreateParams as BrandCreateParams, type BrandUpdateParams as BrandUpdateParams, };
    export { Webhooks as Webhooks, type WebhookDetails as WebhookDetails, type WebhookRetrieveSecretResponse as WebhookRetrieveSecretResponse, type AbandonedCheckoutDetectedWebhookEvent as AbandonedCheckoutDetectedWebhookEvent, type AbandonedCheckoutRecoveredWebhookEvent as AbandonedCheckoutRecoveredWebhookEvent, type CreditAddedWebhookEvent as CreditAddedWebhookEvent, type CreditBalanceLowWebhookEvent as CreditBalanceLowWebhookEvent, type CreditDeductedWebhookEvent as CreditDeductedWebhookEvent, type CreditExpiredWebhookEvent as CreditExpiredWebhookEvent, type CreditManualAdjustmentWebhookEvent as CreditManualAdjustmentWebhookEvent, type CreditOverageChargedWebhookEvent as CreditOverageChargedWebhookEvent, type CreditOverageResetWebhookEvent as CreditOverageResetWebhookEvent, type CreditRolledOverWebhookEvent as CreditRolledOverWebhookEvent, type CreditRolloverForfeitedWebhookEvent as CreditRolloverForfeitedWebhookEvent, type DisputeAcceptedWebhookEvent as DisputeAcceptedWebhookEvent, type DisputeCancelledWebhookEvent as DisputeCancelledWebhookEvent, type DisputeChallengedWebhookEvent as DisputeChallengedWebhookEvent, type DisputeExpiredWebhookEvent as DisputeExpiredWebhookEvent, type DisputeLostWebhookEvent as DisputeLostWebhookEvent, type DisputeOpenedWebhookEvent as DisputeOpenedWebhookEvent, type DisputeWonWebhookEvent as DisputeWonWebhookEvent, type DunningRecoveredWebhookEvent as DunningRecoveredWebhookEvent, type DunningStartedWebhookEvent as DunningStartedWebhookEvent, type EntitlementGrantCreatedWebhookEvent as EntitlementGrantCreatedWebhookEvent, type EntitlementGrantDeliveredWebhookEvent as EntitlementGrantDeliveredWebhookEvent, type EntitlementGrantFailedWebhookEvent as EntitlementGrantFailedWebhookEvent, type EntitlementGrantRevokedWebhookEvent as EntitlementGrantRevokedWebhookEvent, type LicenseKeyCreatedWebhookEvent as LicenseKeyCreatedWebhookEvent, type PaymentCancelledWebhookEvent as PaymentCancelledWebhookEvent, type PaymentFailedWebhookEvent as PaymentFailedWebhookEvent, type PaymentProcessingWebhookEvent as PaymentProcessingWebhookEvent, type PaymentSucceededWebhookEvent as PaymentSucceededWebhookEvent, type RefundFailedWebhookEvent as RefundFailedWebhookEvent, type RefundSucceededWebhookEvent as RefundSucceededWebhookEvent, type SubscriptionActiveWebhookEvent as SubscriptionActiveWebhookEvent, type SubscriptionCancelledWebhookEvent as SubscriptionCancelledWebhookEvent, type SubscriptionExpiredWebhookEvent as SubscriptionExpiredWebhookEvent, type SubscriptionFailedWebhookEvent as SubscriptionFailedWebhookEvent, type SubscriptionOnHoldWebhookEvent as SubscriptionOnHoldWebhookEvent, type SubscriptionPlanChangedWebhookEvent as SubscriptionPlanChangedWebhookEvent, type SubscriptionRenewedWebhookEvent as SubscriptionRenewedWebhookEvent, type SubscriptionUpdatedWebhookEvent as SubscriptionUpdatedWebhookEvent, type UnsafeUnwrapWebhookEvent as UnsafeUnwrapWebhookEvent, type UnwrapWebhookEvent as UnwrapWebhookEvent, type WebhookDetailsCursorPagePagination as WebhookDetailsCursorPagePagination, type WebhookCreateParams as WebhookCreateParams, type WebhookUpdateParams as WebhookUpdateParams, type WebhookListParams as WebhookListParams, };
    export { WebhookEvents as WebhookEvents, type WebhookEventType as WebhookEventType, type WebhookPayload as WebhookPayload, };
    export { UsageEvents as UsageEvents, type Event as Event, type EventInput as EventInput, type UsageEventIngestResponse as UsageEventIngestResponse, type EventsDefaultPageNumberPagination as EventsDefaultPageNumberPagination, type UsageEventListParams as UsageEventListParams, type UsageEventIngestParams as UsageEventIngestParams, };
    export { Meters as Meters, type Conjunction as Conjunction, type FilterOperator as FilterOperator, type FilterType as FilterType, type Meter as Meter, type MeterAggregation as MeterAggregation, type MeterFilter as MeterFilter, type MetersDefaultPageNumberPagination as MetersDefaultPageNumberPagination, type MeterCreateParams as MeterCreateParams, type MeterListParams as MeterListParams, };
    export { Balances as Balances, type BalanceLedgerEntry as BalanceLedgerEntry, type BalanceLedgerEntriesDefaultPageNumberPagination as BalanceLedgerEntriesDefaultPageNumberPagination, type BalanceRetrieveLedgerParams as BalanceRetrieveLedgerParams, };
    export { CreditEntitlements as CreditEntitlements, type CbbOverageBehavior as CbbOverageBehavior, type CreditEntitlement as CreditEntitlement, type CreditEntitlementsDefaultPageNumberPagination as CreditEntitlementsDefaultPageNumberPagination, type CreditEntitlementCreateParams as CreditEntitlementCreateParams, type CreditEntitlementUpdateParams as CreditEntitlementUpdateParams, type CreditEntitlementListParams as CreditEntitlementListParams, };
    export { Entitlements as Entitlements, type Entitlement as Entitlement, type EntitlementIntegrationType as EntitlementIntegrationType, type GitHubPermission as GitHubPermission, type IntegrationConfig as IntegrationConfig, type IntegrationConfigResponse as IntegrationConfigResponse, type EntitlementsDefaultPageNumberPagination as EntitlementsDefaultPageNumberPagination, type EntitlementCreateParams as EntitlementCreateParams, type EntitlementUpdateParams as EntitlementUpdateParams, type EntitlementListParams as EntitlementListParams, };
    export { ProductCollections as ProductCollections, type ProductCollection as ProductCollection, type ProductCollectionListResponse as ProductCollectionListResponse, type ProductCollectionUnarchiveResponse as ProductCollectionUnarchiveResponse, type ProductCollectionUpdateImagesResponse as ProductCollectionUpdateImagesResponse, type ProductCollectionListResponsesDefaultPageNumberPagination as ProductCollectionListResponsesDefaultPageNumberPagination, type ProductCollectionCreateParams as ProductCollectionCreateParams, type ProductCollectionUpdateParams as ProductCollectionUpdateParams, type ProductCollectionListParams as ProductCollectionListParams, type ProductCollectionUpdateImagesParams as ProductCollectionUpdateImagesParams, };
}
//# sourceMappingURL=client.d.ts.map
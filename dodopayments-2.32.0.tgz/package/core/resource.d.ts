import type { DodoPayments } from "../client.js";
export declare abstract class APIResource {
    protected _client: DodoPayments;
    constructor(client: DodoPayments);
}
//# sourceMappingURL=resource.d.ts.map
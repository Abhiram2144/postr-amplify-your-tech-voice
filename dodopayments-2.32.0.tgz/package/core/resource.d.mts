import type { DodoPayments } from "../client.mjs";
export declare abstract class APIResource {
    protected _client: DodoPayments;
    constructor(client: DodoPayments);
}
//# sourceMappingURL=resource.d.mts.map
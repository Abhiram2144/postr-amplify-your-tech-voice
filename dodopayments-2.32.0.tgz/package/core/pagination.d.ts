import { FinalRequestOptions } from "../internal/request-options.js";
import { type DodoPayments } from "../client.js";
import { APIPromise } from "./api-promise.js";
import { type APIResponseProps } from "../internal/parse.js";
export type PageRequestOptions = Pick<FinalRequestOptions, 'query' | 'headers' | 'body' | 'path' | 'method'>;
export declare abstract class AbstractPage<Item> implements AsyncIterable<Item> {
    #private;
    protected options: FinalRequestOptions;
    protected response: Response;
    protected body: unknown;
    constructor(client: DodoPayments, response: Response, body: unknown, options: FinalRequestOptions);
    abstract nextPageRequestOptions(): PageRequestOptions | null;
    abstract getPaginatedItems(): Item[];
    hasNextPage(): boolean;
    getNextPage(): Promise<this>;
    iterPages(): AsyncGenerator<this>;
    [Symbol.asyncIterator](): AsyncGenerator<Item>;
}
/**
 * This subclass of Promise will resolve to an instantiated Page once the request completes.
 *
 * It also implements AsyncIterable to allow auto-paginating iteration on an unawaited list call, eg:
 *
 *    for await (const item of client.items.list()) {
 *      console.log(item)
 *    }
 */
export declare class PagePromise<PageClass extends AbstractPage<Item>, Item = ReturnType<PageClass['getPaginatedItems']>[number]> extends APIPromise<PageClass> implements AsyncIterable<Item> {
    constructor(client: DodoPayments, request: Promise<APIResponseProps>, Page: new (...args: ConstructorParameters<typeof AbstractPage>) => PageClass);
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    [Symbol.asyncIterator](): AsyncGenerator<Item>;
}
export interface DefaultPageNumberPaginationResponse<Item> {
    items: Array<Item>;
}
export interface DefaultPageNumberPaginationParams {
    page_number?: number;
    page_size?: number;
}
export declare class DefaultPageNumberPagination<Item> extends AbstractPage<Item> implements DefaultPageNumberPaginationResponse<Item> {
    items: Array<Item>;
    constructor(client: DodoPayments, response: Response, body: DefaultPageNumberPaginationResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    nextPageRequestOptions(): PageRequestOptions | null;
}
export interface CursorPagePaginationResponse<Item> {
    data: Array<Item>;
    iterator: string;
    done: boolean;
}
export interface CursorPagePaginationParams {
    iterator?: string;
    limit?: number;
}
export declare class CursorPagePagination<Item> extends AbstractPage<Item> implements CursorPagePaginationResponse<Item> {
    data: Array<Item>;
    iterator: string;
    done: boolean;
    constructor(client: DodoPayments, response: Response, body: CursorPagePaginationResponse<Item>, options: FinalRequestOptions);
    getPaginatedItems(): Item[];
    hasNextPage(): boolean;
    nextPageRequestOptions(): PageRequestOptions | null;
}
//# sourceMappingURL=pagination.d.ts.map